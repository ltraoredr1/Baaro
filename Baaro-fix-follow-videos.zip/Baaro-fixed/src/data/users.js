// Fallback vide — les utilisateurs réels viennent de Supabase (table profiles).
// Conservé uniquement pour éviter les erreurs d'import si un ancien fichier
// référence encore STABLE_USERS / getUserById.

export const STABLE_USERS = [];

export function getUserById(_id) {
  return null;
}
