// Compat : réexporte depuis le module centralisé
export { getDeviceId } from "./lib/localStore.js";
