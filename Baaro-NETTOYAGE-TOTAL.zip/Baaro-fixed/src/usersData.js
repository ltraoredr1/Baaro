// DEPRECATED — ne plus utiliser.
// Les utilisateurs reels viennent de Supabase (table profiles).
export const STABLE_USERS = [];
export function getUserById(_id) { return null; }
