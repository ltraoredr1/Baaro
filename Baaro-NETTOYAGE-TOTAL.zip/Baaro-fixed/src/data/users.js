// Fallback vide — profils = Supabase uniquement
export const STABLE_USERS = [];
export function getUserById(_id) { return null; }
