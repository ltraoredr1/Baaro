import { useState, useCallback, useEffect } from "react";
import { supabase } from "./supabaseClient";
import { ToastProvider } from "./components/ToastContext.jsx";
import { Header } from "./components/Header.jsx";
import { Navigation } from "./components/Navigation.jsx";
import { FeedTab } from "./components/FeedTab.jsx";
import { VideosTab } from "./components/VideosTab.jsx";
import { MessagesTab } from "./components/MessagesTab.jsx";
import { WalletTab } from "./components/WalletTab.jsx";
import { CryptoTab } from "./components/CryptoTab.jsx";
import DebatesTab from "./components/DebatesTab.jsx";
import { OfflineTab } from "./components/OfflineTab.jsx";
import { AiAssistantTab } from "./components/AiAssistantTab.jsx";
import { SettingsTab } from "./components/SettingsTab.jsx";
import { ProfileModal } from "./components/ProfileModal.jsx";
import { NotificationDrawer } from "./components/NotificationDrawer.jsx";
import { GlobalSearchModal } from "./components/GlobalSearchModal.jsx";
import { FriendsTab } from "./components/FriendsTab.jsx";
import { COLORS } from "./theme.js";
import { getTheme, setTheme as persistTheme, getLang, setLang as persistLang } from "./lib/localStore.js";
import AuthScreen from "./components/AuthScreen.jsx";
import { Lock, X } from "lucide-react";

const THEME_BG_MAP = {
  midnight: "#0B1220",
  oled: "#000000",
  emerald: "#061A14",
};

/** Onglets accessibles sans compte (invité) */
const GUEST_ALLOWED_TABS = new Set(["feed", "videos"]);

/** Onglets qui exigent un vrai compte */
const ACCOUNT_REQUIRED_TABS = new Set([
  "messages",
  "debates",
  "wallet",
  "crypto",
  "friends",
  "offline",
  "assistant",
  "settings",
]);

const ACCOUNT_REQUIRED_REASONS = {
  messages: "Messagerie et appels",
  debates: "Participer aux débats live",
  wallet: "Portefeuille et gains de points",
  crypto: "BARO Coin et conversions",
  friends: "Communauté et abonnements",
  offline: "Messagerie hors-ligne P2P",
  assistant: "Assistant IA",
  settings: "Paramètres du compte",
};

/** Bannière + modale « compte requis » */
function AccountGateBanner({ reason, onLogin, onClose }) {
  return (
    <div className="fixed inset-0 z-[80] flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div
        className="w-full max-w-md rounded-3xl border p-6 shadow-2xl"
        style={{ background: COLORS.surface, borderColor: COLORS.borderGold }}
      >
        <div className="flex justify-between items-start mb-4">
          <div
            className="w-12 h-12 rounded-2xl flex items-center justify-center"
            style={{ background: `${COLORS.gold}22`, color: COLORS.gold }}
          >
            <Lock size={22} />
          </div>
          <button onClick={onClose} className="p-1" style={{ color: COLORS.muted }}>
            <X size={20} />
          </button>
        </div>
        <h3 className="text-lg font-bold mb-2" style={{ color: COLORS.ivory }}>
          Compte requis
        </h3>
        <p className="text-sm mb-1" style={{ color: COLORS.muted }}>
          Pour <strong style={{ color: COLORS.gold }}>{reason}</strong>, crée un
          compte gratuit (email ou anonyme).
        </p>
        <p className="text-xs mb-5" style={{ color: COLORS.muted }}>
          En invité tu peux déjà regarder les vidéos, liker et partager.
        </p>
        <button
          onClick={onLogin}
          className="w-full py-3 rounded-xl text-sm font-bold"
          style={{ background: COLORS.gold, color: COLORS.bg }}
        >
          Créer un compte / Se connecter
        </button>
        <button
          onClick={onClose}
          className="w-full mt-2 py-2.5 rounded-xl text-xs font-medium"
          style={{ color: COLORS.muted }}
        >
          Continuer en invité
        </button>
      </div>
    </div>
  );
}

function MainAppContent({ session, onRequestAuth }) {
  const isGuest = !session?.user;
  const [activeTab, setActiveTab] = useState("feed");
  const [lang, setLangState] = useState(() => getLang());
  const [pointsBalance, setPointsBalance] = useState(0);
  const [baroBalance, setBaroBalance] = useState(0);
  const [inspectingProfileId, setInspectingProfileId] = useState(null);
  const [notifDrawerOpen, setNotifDrawerOpen] = useState(false);
  const [searchModalOpen, setSearchModalOpen] = useState(false);
  const [currentTheme, setCurrentThemeState] = useState(() => getTheme());
  const setLang = (l) => { setLangState(l); persistLang(l); };
  const setCurrentTheme = (th) => { setCurrentThemeState(th); persistTheme(th); };
  const [userId, setUserId] = useState(null);
  const [userProfile, setUserProfile] = useState({
    display_name: isGuest ? "Invité" : "Membre BAARO",
    handle: isGuest ? "@invite" : "@membre",
    flag: "🌍",
    bio: "",
  });
  const [loadingData, setLoadingData] = useState(!isGuest);
  const [gateReason, setGateReason] = useState(null);

  // Navigation protégée
  const handleSetActiveTab = useCallback(
    (tabId) => {
      if (isGuest && ACCOUNT_REQUIRED_TABS.has(tabId)) {
        setGateReason(ACCOUNT_REQUIRED_REASONS[tabId] || "cette fonctionnalité");
        return;
      }
      setActiveTab(tabId);
    },
    [isGuest]
  );

  // Actions protégées (points, follow, etc.)
  const requireAccount = useCallback(
    (reason = "cette action") => {
      if (isGuest) {
        setGateReason(reason);
        return false;
      }
      return true;
    },
    [isGuest]
  );

  useEffect(() => {
    if (!session?.user) {
      setUserId(null);
      setLoadingData(false);
      setUserProfile({
        display_name: "Invité",
        handle: "@invite",
        flag: "🌍",
        bio: "",
      });
      setPointsBalance(0);
      setBaroBalance(0);
      // Si on était sur un onglet réservé, revenir au fil
      if (ACCOUNT_REQUIRED_TABS.has(activeTab)) {
        setActiveTab("feed");
      }
      return;
    }

    const loadUserData = async () => {
      setLoadingData(true);
      const uid = session.user.id;
      setUserId(uid);

      try {
        const [profileRes, walletRes, cryptoRes] = await Promise.all([
          supabase
            .from("profiles")
            .select("display_name, handle, flag, bio")
            .eq("user_id", uid)
            .maybeSingle(),
          supabase
            .from("wallets")
            .select("balance")
            .eq("user_id", uid)
            .maybeSingle(),
          supabase
            .from("crypto_holdings")
            .select("holdings")
            .eq("user_id", uid)
            .maybeSingle(),
        ]);

        let profile = profileRes.data;

        const meta = session.user.user_metadata || {};
        const email = session.user.email || "";
        const emailName = email.includes("@") ? email.split("@")[0] : "";
        const smartName =
          (meta.display_name && String(meta.display_name).trim()) ||
          (meta.full_name && String(meta.full_name).trim()) ||
          (meta.name && String(meta.name).trim()) ||
          (emailName ? emailName : "") ||
          "Membre BAARO";
        const smartHandle =
          (meta.handle && String(meta.handle).trim()) ||
          (emailName
            ? `@${emailName.slice(0, 20).replace(/[^a-zA-Z0-9_]/g, "")}`
            : "") ||
          `@user_${uid.slice(0, 8)}`;

        if (!profile) {
          const { data: created, error: createErr } = await supabase
            .from("profiles")
            .insert({
              user_id: uid,
              display_name: smartName,
              handle: smartHandle,
              flag: meta.flag || "🌍",
              bio: meta.bio || "",
            })
            .select("display_name, handle, flag, bio")
            .single();

          if (createErr) {
            const { data: again } = await supabase
              .from("profiles")
              .select("display_name, handle, flag, bio")
              .eq("user_id", uid)
              .maybeSingle();
            profile = again;
          } else {
            profile = created;
          }
        } else {
          const generic =
            !profile.display_name ||
            profile.display_name === "Membre BAARO" ||
            profile.display_name === "Nouveau membre";
          if (generic && smartName && smartName !== "Membre BAARO") {
            const { data: updated } = await supabase
              .from("profiles")
              .update({
                display_name: smartName,
                handle:
                  profile.handle?.startsWith("@user_") ||
                  profile.handle === "@membre"
                    ? smartHandle
                    : profile.handle,
              })
              .eq("user_id", uid)
              .select("display_name, handle, flag, bio")
              .single();
            if (updated) profile = updated;
          }
        }

        if (profile) {
          setUserProfile({
            display_name: profile.display_name || smartName || "Membre BAARO",
            handle: profile.handle || smartHandle || "@membre",
            flag: profile.flag || "🌍",
            bio: profile.bio || "",
          });
        }

        if (walletRes.data) {
          setPointsBalance(Number(walletRes.data.balance) || 0);
        } else {
          await supabase.from("wallets").upsert({
            user_id: uid,
            balance: 1284,
          });
          setPointsBalance(1284);
        }

        if (cryptoRes.data) {
          setBaroBalance(Number(cryptoRes.data.holdings) || 0);
        }
      } catch (error) {
        console.error("Erreur chargement données utilisateur:", error);
      } finally {
        setLoadingData(false);
      }
    };

    loadUserData();
  }, [session]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleRewardPoints = useCallback(
    (ptsOrNewBalance) => {
      // Invité : pas de points
      if (isGuest) {
        setGateReason("gagner des points");
        return;
      }
      if (typeof ptsOrNewBalance !== "number") return;
      if (ptsOrNewBalance > 50) {
        setPointsBalance(ptsOrNewBalance);
      } else {
        setPointsBalance((prev) => prev + ptsOrNewBalance);
      }
    },
    [isGuest]
  );

  const themeBg = THEME_BG_MAP[currentTheme] || THEME_BG_MAP.midnight;

  if (loadingData && !isGuest) {
    return (
      <div
        className="min-h-screen flex items-center justify-center"
        style={{ background: themeBg, color: "white" }}
      >
        <div className="text-center">
          <div className="text-4xl mb-4 animate-pulse">⏳</div>
          <p>Chargement de votre espace BAARO...</p>
        </div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen flex flex-col transition-colors duration-500"
      style={{ background: themeBg, color: COLORS.ivory }}
    >
      {/* Bandeau invité */}
      {isGuest && (
        <div
          className="w-full px-3 py-2 text-center text-xs font-medium flex items-center justify-center gap-2"
          style={{ background: `${COLORS.gold}18`, color: COLORS.gold }}
        >
          <span>Mode invité — vidéos, likes & partages libres.</span>
          <button
            onClick={onRequestAuth}
            className="underline font-bold"
            style={{ color: COLORS.gold }}
          >
            Créer un compte
          </button>
        </div>
      )}

      <Header
        lang={lang}
        setLang={setLang}
        pointsBalance={isGuest ? 0 : pointsBalance}
        baroBalance={isGuest ? 0 : baroBalance}
        userProfile={userProfile}
        isGuest={isGuest}
        onOpenNotifs={() => {
          if (!requireAccount("les notifications")) return;
          setNotifDrawerOpen(true);
        }}
        onOpenSearch={() => setSearchModalOpen(true)}
        onOpenAuth={onRequestAuth}
      />

      <div className="max-w-7xl mx-auto w-full px-3 sm:px-6 pt-4 sm:pt-6 flex-1 grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="md:col-span-1">
          <Navigation
            activeTab={activeTab}
            setActiveTab={handleSetActiveTab}
            isGuest={isGuest}
            lockedTabs={ACCOUNT_REQUIRED_TABS}
          />
        </div>

        <main className="md:col-span-3">
          {activeTab === "feed" && (
            <FeedTab
              userId={userId}
              isGuest={isGuest}
              onRequireAccount={requireAccount}
              onOpenProfile={(authorId) => setInspectingProfileId(authorId)}
              onRewardPoints={handleRewardPoints}
            />
          )}

          {activeTab === "friends" && !isGuest && (
            <FriendsTab
              onSelectUser={(id) => setInspectingProfileId(id)}
              onNavigateToMessages={() => setActiveTab("messages")}
            />
          )}

          {activeTab === "videos" && (
            <VideosTab
              userId={userId}
              isGuest={isGuest}
              onRequireAccount={requireAccount}
              onRewardPoints={handleRewardPoints}
            />
          )}

          {activeTab === "messages" && !isGuest && (
            <MessagesTab userId={userId} onRewardPoints={handleRewardPoints} />
          )}

          {activeTab === "wallet" && !isGuest && (
            <WalletTab
              userId={userId}
              pointsBalance={pointsBalance}
              baroBalance={baroBalance}
              onRewardPoints={handleRewardPoints}
            />
          )}

          {activeTab === "crypto" && !isGuest && (
            <CryptoTab
              userId={userId}
              pointsBalance={pointsBalance}
              baroBalance={baroBalance}
              onRewardPoints={handleRewardPoints}
              setPointsBalance={setPointsBalance}
              setBaroBalance={setBaroBalance}
            />
          )}

          {activeTab === "debates" && !isGuest && (
            <DebatesTab
              currentUserId={userId}
              onRewardPoints={handleRewardPoints}
            />
          )}

          {activeTab === "offline" && !isGuest && (
            <OfflineTab onRewardPoints={handleRewardPoints} />
          )}

          {activeTab === "assistant" && !isGuest && (
            <AiAssistantTab
              userId={userId}
              userProfile={userProfile}
              pointsBalance={pointsBalance}
              baroBalance={baroBalance}
              onRewardPoints={handleRewardPoints}
            />
          )}

          {activeTab === "settings" && !isGuest && (
            <SettingsTab
              userId={userId}
              userProfile={userProfile}
              setUserProfile={setUserProfile}
              currentTheme={currentTheme}
              onSelectTheme={setCurrentTheme}
            />
          )}
        </main>
      </div>

      {inspectingProfileId && (
        <ProfileModal
          authorId={inspectingProfileId}
          currentUserId={userId}
          isGuest={isGuest}
          onRequireAccount={requireAccount}
          onClose={() => setInspectingProfileId(null)}
          onNavigateToMessages={() => {
            if (!requireAccount("envoyer un message")) return;
            setActiveTab("messages");
          }}
        />
      )}

      {!isGuest && (
        <NotificationDrawer
          isOpen={notifDrawerOpen}
          onClose={() => setNotifDrawerOpen(false)}
          userId={userId}
        />
      )}

      <GlobalSearchModal
        isOpen={searchModalOpen}
        onClose={() => setSearchModalOpen(false)}
        onSelectUser={(id) => setInspectingProfileId(id)}
        onSelectTab={(tabId) => handleSetActiveTab(tabId)}
      />

      {gateReason && (
        <AccountGateBanner
          reason={gateReason}
          onLogin={() => {
            setGateReason(null);
            onRequestAuth?.();
          }}
          onClose={() => setGateReason(null)}
        />
      )}
    </div>
  );
}

export default function App() {
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showAuth, setShowAuth] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setLoading(false);
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (session) setShowAuth(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  if (loading) {
    return (
      <div
        className="min-h-screen flex items-center justify-center"
        style={{ background: "#0B1220", color: "white" }}
      >
        <div className="text-center">
          <div className="text-4xl mb-4">⏳</div>
          <p>Chargement de BAARO...</p>
        </div>
      </div>
    );
  }

  // Afficher l'écran d'auth uniquement si l'utilisateur le demande
  if (showAuth && !session) {
    return (
      <div className="relative min-h-screen">
        <AuthScreen />
        <button
          onClick={() => setShowAuth(false)}
          className="fixed top-4 left-4 z-50 px-4 py-2 rounded-full text-xs font-bold border"
          style={{
            background: "rgba(11,18,32,0.9)",
            borderColor: "rgba(255,255,255,0.2)",
            color: "#F4EFE3",
          }}
        >
          ← Continuer en invité
        </button>
      </div>
    );
  }

  return (
    <ToastProvider>
      <MainAppContent
        session={session}
        onRequestAuth={() => setShowAuth(true)}
      />
    </ToastProvider>
  );
}
