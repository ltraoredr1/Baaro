import { useState, useEffect } from "react";
import { UserPlus, Check } from "lucide-react";
import { supabase } from "../supabaseClient.js";
import { useToast } from "./ToastContext.jsx";
import { COLORS } from "../theme.js";

/**
 * Bouton d'abonnement / désabonnement.
 * Utilise les colonnes : follower_id, following_id, status.
 */
export function FollowButton({ targetUserId, currentUserId, className = "" }) {
  const [isFollowing, setIsFollowing] = useState(false);
  const [loading, setLoading] = useState(false);
  const { showToast } = useToast();

  useEffect(() => {
    if (!currentUserId || !targetUserId || currentUserId === targetUserId) return;

    const checkFollow = async () => {
      const { data } = await supabase
        .from("follows")
        .select("follower_id")
        .eq("follower_id", currentUserId)
        .eq("following_id", targetUserId)
        .eq("status", "accepted")
        .maybeSingle();

      setIsFollowing(!!data);
    };

    checkFollow();

    // Écoute Realtime des changements sur cette relation
    const channel = supabase
      .channel(`follow-${currentUserId}-${targetUserId}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "follows",
          filter: `following_id=eq.${targetUserId}`,
        },
        () => checkFollow()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [currentUserId, targetUserId]);

  const handleToggle = async () => {
    if (!currentUserId || loading) return;
    setLoading(true);

    try {
      if (isFollowing) {
        const { error } = await supabase
          .from("follows")
          .delete()
          .eq("follower_id", currentUserId)
          .eq("following_id", targetUserId);

        if (error) throw error;
        setIsFollowing(false);
        showToast("Abonnement retiré", "info");
      } else {
        const { error } = await supabase.from("follows").insert({
          follower_id: currentUserId,
          following_id: targetUserId,
          status: "accepted",
          is_friend: false,
        });

        if (error) throw error;
        setIsFollowing(true);
        showToast("Abonné(e) !", "success");
      }
    } catch (err) {
      console.error("Erreur follow:", err);
      showToast("Erreur lors de l'action", "error");
    } finally {
      setLoading(false);
    }
  };

  // Ne pas afficher sur son propre profil
  if (!currentUserId || currentUserId === targetUserId) return null;

  return (
    <button
      onClick={handleToggle}
      disabled={loading}
      className={`px-4 py-2 rounded-full text-xs font-bold flex items-center justify-center gap-1.5 transition ${className}`}
      style={{
        background: isFollowing ? COLORS.surface : COLORS.gold,
        color: isFollowing ? COLORS.gold : COLORS.bg,
        border: isFollowing ? `1px solid ${COLORS.borderGold}` : "none",
        opacity: loading ? 0.7 : 1,
      }}
    >
      {loading ? (
        <span className="animate-pulse">…</span>
      ) : isFollowing ? (
        <>
          <Check size={14} />
          Abonné(e)
        </>
      ) : (
        <>
          <UserPlus size={14} />
          S'abonner
        </>
      )}
    </button>
  );
}

export default FollowButton;
