import { useState, useEffect } from "react";
import {
  Search,
  X,
  User,
  Hash,
  Swords,
  ArrowRight,
  BadgeCheck,
} from "lucide-react";
import { COLORS } from "../theme.js";
import { supabase } from "../supabaseClient.js";

const POPULAR_HASHTAGS = [
  "#GreenTech",
  "#BaroCoin",
  "#AfricaTech",
  "#Web3",
  "#P2PMesh",
  "#Gouvernance",
];

export function GlobalSearchModal({
  isOpen,
  onClose,
  onSelectUser,
  onSelectDebate,
  onSelectTab,
}) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState({ users: [], debates: [] });
  const [loading, setLoading] = useState(false);

  // Réinitialiser à la fermeture
  useEffect(() => {
    if (!isOpen) {
      setQuery("");
      setResults({ users: [], debates: [] });
    }
  }, [isOpen]);

  // Recherche avec debounce
  useEffect(() => {
    if (!isOpen) return;

    if (!query || query.trim().length < 2) {
      setResults({ users: [], debates: [] });
      setLoading(false);
      return;
    }

    const timer = setTimeout(async () => {
      setLoading(true);
      const searchQuery = `%${query.trim()}%`;

      try {
        // 1. Profils
        let profileUsers = [];
        const { data: profiles, error: pErr } = await supabase
          .from("profiles")
          .select(
            "user_id, display_name, handle, flag, bio, avatar_url, is_verified"
          )
          .or(
            `display_name.ilike.${searchQuery},handle.ilike.${searchQuery}`
          )
          .limit(12);

        if (!pErr && profiles) {
          profileUsers = profiles.map((u) => ({
            id: u.user_id,
            user_id: u.user_id,
            display_name: u.display_name || "Membre BAARO",
            handle: u.handle || `@user_${u.user_id?.slice(0, 8)}`,
            flag: u.flag || "🌍",
            bio: u.bio || "",
            avatar: u.avatar_url || null,
            isVerified: !!u.is_verified,
          }));
        }

        // 2. Débats actifs
        let dbDebates = [];
        try {
          const { data: debates, error: dErr } = await supabase
            .from("debates")
            .select("id, title, topic, invite_code, status")
            .eq("status", "live")
            .or(`title.ilike.${searchQuery},topic.ilike.${searchQuery}`)
            .limit(6);

          if (!dErr && debates) dbDebates = debates;
        } catch {
          // Table peut s'appeler autrement selon les migrations
          try {
            const { data: debates2 } = await supabase
              .from("debate_rooms")
              .select("id, title, topic, invite_code, status")
              .or(`title.ilike.${searchQuery},topic.ilike.${searchQuery}`)
              .limit(6);
            if (debates2) dbDebates = debates2;
          } catch {
            /* ignore */
          }
        }

        setResults({ users: profileUsers, debates: dbDebates });
      } catch (error) {
        console.error("Erreur recherche:", error);
        setResults({ users: [], debates: [] });
      } finally {
        setLoading(false);
      }
    }, 320);

    return () => clearTimeout(timer);
  }, [query, isOpen]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-[60] flex items-start justify-center pt-16 sm:pt-24 px-3 bg-black/70 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg rounded-3xl border shadow-2xl overflow-hidden flex flex-col max-h-[80vh]"
        style={{ background: COLORS.surface, borderColor: COLORS.borderGold }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header recherche */}
        <div
          className="flex items-center gap-2 p-3 border-b"
          style={{ borderColor: COLORS.border }}
        >
          <Search size={18} style={{ color: COLORS.gold }} />
          <input
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Rechercher un membre, un débat…"
            className="flex-1 bg-transparent outline-none text-sm"
            style={{ color: COLORS.ivory }}
          />
          {loading && (
            <span className="text-xs animate-pulse" style={{ color: COLORS.muted }}>
              …
            </span>
          )}
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/5"
            style={{ color: COLORS.muted }}
          >
            <X size={18} />
          </button>
        </div>

        <div className="overflow-y-auto p-3 flex flex-col gap-4">
          {/* Hashtags populaires (quand pas de requête) */}
          {query.trim().length < 2 && (
            <div>
              <span
                className="text-[10px] font-bold uppercase tracking-wider mb-2 block"
                style={{ color: COLORS.muted }}
              >
                Hashtags populaires
              </span>
              <div className="flex flex-wrap gap-2">
                {POPULAR_HASHTAGS.map((tag) => (
                  <button
                    key={tag}
                    onClick={() => setQuery(tag.replace("#", ""))}
                    className="px-3 py-1.5 rounded-full text-xs font-medium border"
                    style={{
                      borderColor: COLORS.border,
                      color: COLORS.teal,
                      background: COLORS.surface2,
                    }}
                  >
                    {tag}
                  </button>
                ))}
              </div>
              <p className="text-xs mt-4 text-center" style={{ color: COLORS.muted }}>
                Tapez au moins 2 caractères pour lancer la recherche
              </p>
            </div>
          )}

          {/* Résultats utilisateurs */}
          {results.users.length > 0 && (
            <div>
              <span
                className="text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5 mb-2"
                style={{ color: COLORS.muted }}
              >
                <User size={12} />
                Membres ({results.users.length})
              </span>
              <div className="flex flex-col gap-1.5">
                {results.users.map((u) => (
                  <button
                    key={u.id}
                    type="button"
                    onClick={() => {
                      onClose();
                      onSelectUser?.(u.id);
                    }}
                    className="w-full p-2.5 rounded-2xl border flex items-center gap-3 text-left hover:border-teal-400/40 transition"
                    style={{
                      background: COLORS.surface2,
                      borderColor: COLORS.border,
                    }}
                  >
                    <div
                      className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold shrink-0 overflow-hidden"
                      style={{ background: COLORS.surface, color: COLORS.gold }}
                    >
                      {u.avatar ? (
                        <img
                          src={u.avatar}
                          alt=""
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        (u.display_name?.[0] || "?").toUpperCase()
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div
                        className="text-sm font-bold truncate flex items-center gap-1"
                        style={{ color: COLORS.ivory }}
                      >
                        {u.display_name} {u.flag}
                        {u.isVerified && (
                          <BadgeCheck size={14} style={{ color: COLORS.teal }} />
                        )}
                      </div>
                      <div
                        className="text-xs truncate"
                        style={{ color: COLORS.muted }}
                      >
                        {u.handle}
                      </div>
                    </div>
                    <ArrowRight size={14} style={{ color: COLORS.muted }} />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Résultats débats */}
          {results.debates.length > 0 && (
            <div
              className="border-t pt-3"
              style={{ borderColor: COLORS.border }}
            >
              <span
                className="text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5 mb-2"
                style={{ color: COLORS.muted }}
              >
                <Swords size={12} />
                Débats ({results.debates.length})
              </span>
              <div className="flex flex-col gap-1.5">
                {results.debates.map((debate) => (
                  <button
                    key={debate.id}
                    type="button"
                    onClick={() => {
                      onClose();
                      if (onSelectDebate) {
                        onSelectDebate(debate.invite_code || debate.id);
                      } else if (onSelectTab) {
                        onSelectTab("debates");
                      }
                    }}
                    className="w-full p-2.5 rounded-2xl border flex items-center gap-3 text-left hover:border-teal-400/40 transition"
                    style={{
                      background: COLORS.surface2,
                      borderColor: COLORS.border,
                    }}
                  >
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                      style={{
                        background: `${COLORS.teal}20`,
                        color: COLORS.teal,
                      }}
                    >
                      <Hash size={18} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div
                        className="text-sm font-bold truncate"
                        style={{ color: COLORS.ivory }}
                      >
                        {debate.title}
                      </div>
                      <div
                        className="text-xs truncate"
                        style={{ color: COLORS.muted }}
                      >
                        {debate.topic || "Débat live"}
                      </div>
                    </div>
                    <span className="text-[10px] px-2 py-1 rounded-full font-bold bg-green-500/20 text-green-400">
                      REJOINDRE
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Aucun résultat */}
          {query.trim().length >= 2 &&
            !loading &&
            results.users.length === 0 &&
            results.debates.length === 0 && (
              <p
                className="text-center text-sm py-8"
                style={{ color: COLORS.muted }}
              >
                Aucun résultat pour « {query} »
              </p>
            )}
        </div>
      </div>
    </div>
  );
}

export default GlobalSearchModal;
