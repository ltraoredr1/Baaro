import { useState, useEffect, useCallback } from "react";
import {
  getFollowers,
  getFollowing,
  getFriends,
  getPendingRequests,
  followUser,
  unfollowUser,
  acceptFriendRequest,
  rejectFriendRequest,
} from "../supabaseClient.js";
import { supabase } from "../supabaseClient.js";
import { COLORS } from "../theme.js";
import { useToast } from "./ToastContext.jsx";
import { UserPlus, Check, X, MessageCircle, Users } from "lucide-react";

/**
 * Charge les profils Supabase à partir d'une liste d'IDs utilisateur.
 */
async function fetchProfilesByIds(ids) {
  if (!ids || ids.length === 0) return [];
  const unique = [...new Set(ids.filter(Boolean))];
  if (unique.length === 0) return [];

  const { data, error } = await supabase
    .from("profiles")
    .select("user_id, display_name, handle, flag, bio, avatar_url")
    .in("user_id", unique);

  if (error) {
    console.error("Erreur chargement profils:", error);
    return [];
  }

  // Index par user_id pour un accès rapide
  const map = {};
  (data || []).forEach((p) => {
    map[p.user_id] = {
      id: p.user_id,
      user_id: p.user_id,
      display_name: p.display_name || "Membre BAARO",
      handle: p.handle || `@user_${p.user_id?.slice(0, 8)}`,
      flag: p.flag || "🌍",
      bio: p.bio || "",
      avatar: p.avatar_url || null,
    };
  });

  // Conserver l'ordre des ids d'origine et fournir un fallback
  return unique.map(
    (id) =>
      map[id] || {
        id,
        user_id: id,
        display_name: "Membre BAARO",
        handle: `@user_${id.slice(0, 8)}`,
        flag: "🌍",
        bio: "",
        avatar: null,
      }
  );
}

export function FriendsTab({ onSelectUser, onNavigateToMessages }) {
  const { showToast } = useToast();
  const [activeTab, setActiveTab] = useState("friends");
  const [friends, setFriends] = useState([]);
  const [followers, setFollowers] = useState([]);
  const [following, setFollowing] = useState([]);
  const [pending, setPending] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      if (activeTab === "friends") {
        const { data: ids } = await getFriends();
        const users = await fetchProfilesByIds(ids || []);
        setFriends(users);
      } else if (activeTab === "followers") {
        const { data: ids } = await getFollowers();
        const users = await fetchProfilesByIds(ids || []);
        setFollowers(users);
      } else if (activeTab === "following") {
        const { data: ids } = await getFollowing();
        const users = await fetchProfilesByIds(ids || []);
        setFollowing(users);
      } else if (activeTab === "requests") {
        const { data } = await getPendingRequests();
        const ids = (data || []).map((r) => r.follower_id);
        const profiles = await fetchProfilesByIds(ids);
        const profileMap = {};
        profiles.forEach((p) => {
          profileMap[p.user_id] = p;
        });
        const enriched = (data || []).map((req) => ({
          ...req,
          ...(profileMap[req.follower_id] || {
            id: req.follower_id,
            display_name: "Membre BAARO",
            handle: `@user_${req.follower_id?.slice(0, 8)}`,
            flag: "🌍",
          }),
        }));
        setPending(enriched);
      }
    } catch (error) {
      console.error("Erreur FriendsTab:", error);
      showToast("Erreur de chargement", "error");
    } finally {
      setLoading(false);
    }
  }, [activeTab, showToast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleFollow = async (userId) => {
    try {
      const { error } = await followUser(userId);
      if (error) throw error;
      showToast("Abonné(e) !", "success");
      loadData();
    } catch (e) {
      showToast("Erreur abonnement", "error");
    }
  };

  const handleUnfollow = async (userId) => {
    try {
      const { error } = await unfollowUser(userId);
      if (error) throw error;
      showToast("Abonnement retiré", "info");
      loadData();
    } catch (e) {
      showToast("Erreur désabonnement", "error");
    }
  };

  const handleAccept = async (followId) => {
    try {
      const { error } = await acceptFriendRequest(followId);
      if (error) throw error;
      showToast("Demande acceptée", "success");
      loadData();
    } catch (e) {
      showToast("Erreur", "error");
    }
  };

  const handleReject = async (followId) => {
    try {
      const { error } = await rejectFriendRequest(followId);
      if (error) throw error;
      showToast("Demande refusée", "info");
      loadData();
    } catch (e) {
      showToast("Erreur", "error");
    }
  };

  const tabs = [
    { id: "friends", label: "👫 Amis" },
    { id: "followers", label: "📥 Abonnés" },
    { id: "following", label: "📤 Abonnements" },
    { id: "requests", label: "📩 Demandes" },
  ];

  const renderUser = (user, type) => {
    if (!user) return null;
    const name = user.display_name || "Membre";
    const handle = user.handle || "@utilisateur";
    const flag = user.flag || "🌍";
    const avatar = user.avatar;
    const uid = user.user_id || user.id;

    return (
      <div
        key={uid + (user.id || "")}
        className="flex items-center gap-3 p-3 rounded-2xl border"
        style={{ background: COLORS.surface, borderColor: COLORS.border }}
      >
        <button
          type="button"
          onClick={() => onSelectUser?.(uid)}
          className="w-11 h-11 rounded-full flex items-center justify-center text-sm font-bold shrink-0 overflow-hidden"
          style={{ background: COLORS.surface2, color: COLORS.gold }}
        >
          {avatar ? (
            <img src={avatar} alt="" className="w-full h-full object-cover" />
          ) : (
            (name[0] || "?").toUpperCase()
          )}
        </button>

        <div className="flex-1 min-w-0">
          <div className="text-sm font-bold truncate" style={{ color: COLORS.ivory }}>
            {name} {flag}
          </div>
          <div className="text-xs truncate" style={{ color: COLORS.muted }}>
            {handle}
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {type === "followers" && (
            <button
              onClick={() => handleFollow(uid)}
              className="px-3 py-1.5 rounded-full text-xs font-bold"
              style={{ background: COLORS.gold, color: COLORS.bg }}
            >
              <UserPlus size={14} className="inline mr-1" />
              Suivre
            </button>
          )}
          {type === "following" && (
            <button
              onClick={() => handleUnfollow(uid)}
              className="px-3 py-1.5 rounded-full text-xs font-bold border"
              style={{ borderColor: COLORS.borderGold, color: COLORS.gold }}
            >
              <Check size={14} className="inline mr-1" />
              Abonné
            </button>
          )}
          {type === "requests" && (
            <>
              <button
                onClick={() => handleAccept(user.id)}
                className="w-8 h-8 rounded-full flex items-center justify-center text-green-400 hover:bg-green-500/20 transition"
                title="Accepter"
              >
                <Check size={16} />
              </button>
              <button
                onClick={() => handleReject(user.id)}
                className="w-8 h-8 rounded-full flex items-center justify-center text-red-400 hover:bg-red-500/20 transition"
                title="Refuser"
              >
                <X size={16} />
              </button>
            </>
          )}
          {type === "friends" && (
            <button
              onClick={() => {
                onSelectUser?.(uid);
                onNavigateToMessages?.();
              }}
              className="w-8 h-8 rounded-full flex items-center justify-center"
              style={{ background: COLORS.surface2, color: COLORS.teal }}
              title="Message"
            >
              <MessageCircle size={15} />
            </button>
          )}
        </div>
      </div>
    );
  };

  const renderContent = () => {
    if (loading) {
      return (
        <div className="text-center py-12" style={{ color: COLORS.muted }}>
          <div className="animate-spin text-2xl mb-2">⏳</div>
          Chargement…
        </div>
      );
    }

    let list = [];
    let type = "";
    let emptyMsg = "";

    switch (activeTab) {
      case "friends":
        list = friends;
        type = "friends";
        emptyMsg = "Aucun ami pour le moment.";
        break;
      case "followers":
        list = followers;
        type = "followers";
        emptyMsg = "Aucun abonné.";
        break;
      case "following":
        list = following;
        type = "following";
        emptyMsg = "Vous ne suivez personne.";
        break;
      case "requests":
        list = pending;
        type = "requests";
        emptyMsg = "Aucune demande en attente.";
        break;
      default:
        break;
    }

    if (list.length === 0) {
      return (
        <div className="text-center py-12" style={{ color: COLORS.muted }}>
          <Users size={36} className="mx-auto mb-3 opacity-40" />
          <p className="text-sm">{emptyMsg}</p>
        </div>
      );
    }

    return (
      <div className="space-y-2">
        {list.map((item) => renderUser(item, type))}
      </div>
    );
  };

  return (
    <div className="p-4 pb-24">
      <h2 className="text-xl font-bold mb-4" style={{ color: COLORS.ivory }}>
        👥 Communauté
      </h2>

      <div className="flex gap-2 mb-5 overflow-x-auto pb-1">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className="px-3.5 py-2 rounded-full text-xs font-bold transition whitespace-nowrap"
            style={{
              background: activeTab === tab.id ? COLORS.gold : COLORS.surface,
              color: activeTab === tab.id ? COLORS.bg : COLORS.muted,
              border: `1px solid ${activeTab === tab.id ? COLORS.gold : COLORS.border}`,
            }}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {renderContent()}
    </div>
  );
}

export default FriendsTab;
