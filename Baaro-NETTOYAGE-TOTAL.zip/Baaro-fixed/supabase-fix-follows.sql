-- ============================================================
-- BAARO — Correctif table follows
-- À exécuter dans le SQL Editor de Supabase (une seule fois)
-- ============================================================
-- Problème : le schéma initial utilise "followed_id"
-- alors que le code applicatif utilise "following_id" +
-- les colonnes status / is_friend / id.
-- Ce script aligne la table sur le code.

-- 1. Ajouter les colonnes manquantes si elles n'existent pas
DO $$
BEGIN
  -- Colonne id (clé primaire technique)
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'follows' AND column_name = 'id'
  ) THEN
    ALTER TABLE follows ADD COLUMN id uuid DEFAULT gen_random_uuid();
    -- Remplir les lignes existantes
    UPDATE follows SET id = gen_random_uuid() WHERE id IS NULL;
    ALTER TABLE follows ALTER COLUMN id SET NOT NULL;
  END IF;

  -- Colonne following_id (si on a encore followed_id)
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'follows' AND column_name = 'followed_id'
  ) AND NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'follows' AND column_name = 'following_id'
  ) THEN
    ALTER TABLE follows RENAME COLUMN followed_id TO following_id;
  END IF;

  -- Colonne status
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'follows' AND column_name = 'status'
  ) THEN
    ALTER TABLE follows ADD COLUMN status text NOT NULL DEFAULT 'accepted';
  END IF;

  -- Colonne is_friend
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'follows' AND column_name = 'is_friend'
  ) THEN
    ALTER TABLE follows ADD COLUMN is_friend boolean NOT NULL DEFAULT false;
  END IF;
END $$;

-- 2. S'assurer que la contrainte unique existe sur (follower_id, following_id)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'follows_follower_following_unique'
  ) THEN
    -- Supprimer l'ancienne PK composite si elle existe encore sur (follower_id, followed_id)
    BEGIN
      ALTER TABLE follows DROP CONSTRAINT IF EXISTS follows_pkey;
    EXCEPTION WHEN OTHERS THEN NULL;
    END;

    ALTER TABLE follows
      ADD CONSTRAINT follows_follower_following_unique
      UNIQUE (follower_id, following_id);
  END IF;
END $$;

-- 3. Mettre id en clé primaire si ce n'est pas déjà le cas
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'follows_pkey' AND contype = 'p'
  ) THEN
    ALTER TABLE follows ADD PRIMARY KEY (id);
  END IF;
EXCEPTION WHEN OTHERS THEN
  -- Si id n'est pas encore unique, on force
  NULL;
END $$;

-- 4. Index utiles
CREATE INDEX IF NOT EXISTS idx_follows_follower ON follows (follower_id);
CREATE INDEX IF NOT EXISTS idx_follows_following ON follows (following_id);
CREATE INDEX IF NOT EXISTS idx_follows_status ON follows (status) WHERE status = 'accepted';

-- 5. Politiques RLS (réappliquer proprement)
ALTER TABLE follows ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "follows_read" ON follows;
DROP POLICY IF EXISTS "follows_own" ON follows;
DROP POLICY IF EXISTS "follows_select" ON follows;
DROP POLICY IF EXISTS "follows_insert" ON follows;
DROP POLICY IF EXISTS "follows_update" ON follows;
DROP POLICY IF EXISTS "follows_delete" ON follows;

CREATE POLICY "follows_select" ON follows
  FOR SELECT USING (true);

CREATE POLICY "follows_insert" ON follows
  FOR INSERT WITH CHECK (auth.uid() = follower_id);

CREATE POLICY "follows_update" ON follows
  FOR UPDATE USING (auth.uid() = follower_id OR auth.uid() = following_id);

CREATE POLICY "follows_delete" ON follows
  FOR DELETE USING (auth.uid() = follower_id OR auth.uid() = following_id);

-- Vérification
SELECT column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_name = 'follows'
ORDER BY ordinal_position;
