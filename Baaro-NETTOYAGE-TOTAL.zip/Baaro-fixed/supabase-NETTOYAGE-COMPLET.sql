-- ============================================================
-- BAARO — Nettoyage complet de l'ancien systeme follows
-- A executer dans Supabase SQL Editor (une seule fois)
-- ============================================================

-- 1) Colonnes : s'assurer que following_id existe, pas followed_id
DO $body$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'follows' AND column_name = 'followed_id'
  ) AND NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'follows' AND column_name = 'following_id'
  ) THEN
    ALTER TABLE public.follows RENAME COLUMN followed_id TO following_id;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'follows' AND column_name = 'status'
  ) THEN
    ALTER TABLE public.follows ADD COLUMN status text NOT NULL DEFAULT 'accepted';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'follows' AND column_name = 'is_friend'
  ) THEN
    ALTER TABLE public.follows ADD COLUMN is_friend boolean NOT NULL DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'follows' AND column_name = 'id'
  ) THEN
    ALTER TABLE public.follows ADD COLUMN id uuid DEFAULT gen_random_uuid();
    UPDATE public.follows SET id = gen_random_uuid() WHERE id IS NULL;
  END IF;
END
$body$;

-- 2) Fonctions triggers (plus aucune reference a followed_id)
CREATE OR REPLACE FUNCTION prevent_self_follow()
RETURNS trigger
LANGUAGE plpgsql
AS $body$
BEGIN
  IF NEW.follower_id IS NOT NULL AND NEW.following_id IS NOT NULL
     AND NEW.follower_id = NEW.following_id THEN
    RAISE EXCEPTION 'Impossible de s abonner a soi-meme';
  END IF;
  RETURN NEW;
END;
$body$;

CREATE OR REPLACE FUNCTION notify_on_follow()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $body$
BEGIN
  IF NEW.status IS NULL OR NEW.status = 'accepted' THEN
    BEGIN
      INSERT INTO notifications (user_id, message, read)
      VALUES (NEW.following_id, 'Quelqu un s est abonne a vous', false);
    EXCEPTION WHEN OTHERS THEN
      NULL;
    END;
  END IF;
  RETURN NEW;
END;
$body$;

DROP TRIGGER IF EXISTS trg_prevent_self_follow ON public.follows;
CREATE TRIGGER trg_prevent_self_follow
  BEFORE INSERT ON public.follows
  FOR EACH ROW EXECUTE FUNCTION prevent_self_follow();

DROP TRIGGER IF EXISTS trg_notify_on_follow ON public.follows;
CREATE TRIGGER trg_notify_on_follow
  AFTER INSERT ON public.follows
  FOR EACH ROW EXECUTE FUNCTION notify_on_follow();

-- 3) Supprimer toute autre fonction qui mentionne encore followed_id
DO $body$
DECLARE
  r record;
BEGIN
  FOR r IN
    SELECT p.oid, p.proname
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public'
      AND pg_get_functiondef(p.oid) ILIKE '%followed_id%'
  LOOP
    RAISE NOTICE 'Fonction a revoir manuellement: %', r.proname;
  END LOOP;
END
$body$;

-- 4) Index utiles
CREATE INDEX IF NOT EXISTS idx_follows_follower ON public.follows (follower_id);
CREATE INDEX IF NOT EXISTS idx_follows_following ON public.follows (following_id);

-- 5) Verifier structure finale
SELECT column_name, data_type
FROM information_schema.columns
WHERE table_schema = 'public' AND table_name = 'follows'
ORDER BY ordinal_position;

-- 6) Verifier qu aucune definition de fonction publique ne contient followed_id
SELECT p.proname
FROM pg_proc p
JOIN pg_namespace n ON n.oid = p.pronamespace
WHERE n.nspname = 'public'
  AND pg_get_functiondef(p.oid) ILIKE '%followed_id%';
