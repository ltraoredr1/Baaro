# BAARO database migrations

For a fresh database, apply the existing BAARO schema/migrations in their
documented order, then apply `0010_baaro_unified_repair.sql`.

For an existing BAARO project, `0010_baaro_unified_repair.sql` is designed to
be idempotent and preserve existing tables/data. It adds missing columns,
compatibility fields, indexes, RLS rules, storage buckets and server-only
wallet RPCs.

Do not put `SUPABASE_SERVICE_ROLE_KEY` in any `VITE_*` variable.
