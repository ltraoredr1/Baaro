-- BAARO — Unified repair / compatibility migration
-- Idempotent. Run AFTER the existing BAARO SQL files.
-- Purpose: reconcile the database with the current application without deleting
-- existing tables/data. It only adds missing structures/columns, normalizes
-- compatibility fields, and tightens RLS.

create extension if not exists pgcrypto;

-- ============================================================
-- PROFILES / POSTS
-- ============================================================
alter table if exists profiles add column if not exists bio text default '';
alter table if exists profiles add column if not exists restricted boolean not null default false;
alter table if exists profiles add column if not exists avatar_url text;
alter table if exists profiles add column if not exists public_key jsonb;

alter table if exists posts add column if not exists media_url text;
alter table if exists posts add column if not exists media_type text;

-- ============================================================
-- SOCIAL
-- ============================================================
create table if not exists comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references posts(id) on delete cascade,
  author_id uuid not null references auth.users(id) on delete cascade,
  text text not null check (length(text) <= 5000),
  created_at timestamptz not null default now()
);

create table if not exists notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  message text not null check (length(message) <= 2000),
  read boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists blocks (
  blocker_id uuid not null references auth.users(id) on delete cascade,
  blocked_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id),
  check (blocker_id <> blocked_id)
);

create table if not exists reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references auth.users(id) on delete cascade,
  target_type text not null,
  target_id text not null,
  reason text,
  created_at timestamptz not null default now()
);

-- Keep the old followed_id column if it exists so no existing data is lost.
-- The application uses following_id from now on.
create table if not exists follows (
  follower_id uuid not null references auth.users(id) on delete cascade,
  following_id uuid references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (follower_id, following_id)
);

alter table follows add column if not exists following_id uuid references auth.users(id) on delete cascade;
alter table follows add column if not exists status text not null default 'accepted';
alter table follows add column if not exists is_friend boolean not null default false;
alter table follows add column if not exists id uuid default gen_random_uuid();

-- Legacy schema compatibility.
alter table follows add column if not exists followed_id uuid references auth.users(id) on delete cascade;
update follows
set following_id = coalesce(following_id, followed_id)
where following_id is null;
update follows
set followed_id = coalesce(followed_id, following_id)
where followed_id is null;

create or replace function baaro_sync_follow_columns()
returns trigger
language plpgsql
as $$
begin
  if new.following_id is null and new.followed_id is not null then
    new.following_id := new.followed_id;
  end if;
  if new.followed_id is null and new.following_id is not null then
    new.followed_id := new.following_id;
  end if;
  return new;
end;
$$;

drop trigger if exists baaro_sync_follow_columns on follows;
create trigger baaro_sync_follow_columns
before insert or update on follows
for each row execute function baaro_sync_follow_columns();

create unique index if not exists idx_follows_following_pair
  on follows(follower_id, following_id);
create unique index if not exists idx_follows_id on follows(id);
create index if not exists idx_follows_following on follows(following_id);

-- ============================================================
-- STORIES
-- ============================================================
create table if not exists stories (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references auth.users(id) on delete cascade,
  text text default '',
  media_url text,
  media_type text check (media_type is null or media_type in ('image','video')),
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '24 hours')
);

alter table stories add column if not exists text text default '';
alter table stories add column if not exists text_overlay text;
alter table stories add column if not exists media_url text;
alter table stories add column if not exists media_type text;
alter table stories add column if not exists expires_at timestamptz;
update stories set expires_at = created_at + interval '24 hours' where expires_at is null;
alter table stories alter column expires_at set default (now() + interval '24 hours');

create table if not exists story_views (
  story_id uuid not null references stories(id) on delete cascade,
  viewer_id uuid not null references auth.users(id) on delete cascade,
  viewed_at timestamptz not null default now(),
  primary key (story_id, viewer_id)
);

-- ============================================================
-- VIDEOS
-- ============================================================
alter table videos add column if not exists description text default '';
alter table videos add column if not exists video_url text;
alter table videos add column if not exists thumbnail_url text;
alter table videos add column if not exists likes integer not null default 0;
alter table videos add column if not exists comments_count integer not null default 0;
alter table videos add column if not exists is_repost boolean not null default false;
alter table videos add column if not exists original_author_id uuid references auth.users(id) on delete set null;
alter table videos add column if not exists sound_id text;

create table if not exists video_likes (
  video_id uuid not null references videos(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (video_id, user_id)
);

create table if not exists video_comments (
  id uuid primary key default gen_random_uuid(),
  video_id uuid not null references videos(id) on delete cascade,
  author_id uuid not null references auth.users(id) on delete cascade,
  content text not null check (length(content) <= 5000),
  created_at timestamptz not null default now()
);

create table if not exists sounds (
  id text primary key,
  title text not null,
  artist text,
  url text,
  usage_count integer not null default 0,
  created_at timestamptz not null default now()
);

-- ============================================================
-- MESSAGING / CALLS
-- ============================================================
create table if not exists conversations (
  id uuid primary key default gen_random_uuid(),
  user1_id uuid not null references auth.users(id) on delete cascade,
  user2_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(user1_id, user2_id),
  check(user1_id <> user2_id)
);

alter table messages add column if not exists conversation_id uuid references conversations(id) on delete cascade;
alter table messages add column if not exists sender_id uuid references auth.users(id) on delete cascade;
alter table messages add column if not exists recipient_id uuid references auth.users(id) on delete set null;
alter table messages add column if not exists text text default '';
alter table messages add column if not exists created_at timestamptz default now();
alter table messages alter column conversation_id drop not null;

create index if not exists idx_messages_conversation_created
  on messages(conversation_id, created_at);

create table if not exists calls (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references conversations(id) on delete cascade,
  caller_id uuid not null references auth.users(id) on delete cascade,
  callee_id uuid not null references auth.users(id) on delete cascade,
  type text not null check(type in ('voice','video')),
  status text not null default 'ringing'
    check(status in ('ringing','accepted','rejected','ended','missed')),
  daily_room_name text,
  created_at timestamptz not null default now(),
  ended_at timestamptz
);

-- ============================================================
-- DEBATES / LIVE
-- ============================================================
alter table debate_participants add column if not exists role text not null default 'viewer';
alter table debate_participants add column if not exists left_at timestamptz;

create table if not exists debate_role_requests (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references debate_rooms(id) on delete cascade,
  from_user_id uuid not null references auth.users(id) on delete cascade,
  to_user_id uuid not null references auth.users(id) on delete cascade,
  requested_role text not null default 'co_host' check(requested_role = 'co_host'),
  status text not null default 'pending'
    check(status in ('pending','accepted','refused','cancelled')),
  created_at timestamptz not null default now(),
  responded_at timestamptz
);

-- ============================================================
-- RLS: replace permissive/duplicate policies with explicit policies.
-- ============================================================
alter table comments enable row level security;
alter table notifications enable row level security;
alter table blocks enable row level security;
alter table reports enable row level security;
alter table stories enable row level security;
alter table story_views enable row level security;
alter table video_likes enable row level security;
alter table video_comments enable row level security;
alter table sounds enable row level security;
alter table conversations enable row level security;
alter table messages enable row level security;
alter table calls enable row level security;
alter table debate_role_requests enable row level security;
alter table follows enable row level security;

-- Comments
drop policy if exists comments_read on comments;
drop policy if exists comments_insert on comments;
create policy comments_read on comments for select using (true);
create policy comments_insert on comments for insert with check (auth.uid() = author_id);

-- Notifications
drop policy if exists notif_own on notifications;
create policy notif_own on notifications for all
using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Blocks
drop policy if exists blocks_own on blocks;
create policy blocks_own on blocks for all
using (auth.uid() = blocker_id) with check (auth.uid() = blocker_id);

-- Reports
drop policy if exists reports_insert on reports;
drop policy if exists reports_own_read on reports;
create policy reports_insert on reports for insert with check (auth.uid() = reporter_id);
create policy reports_own_read on reports for select using (auth.uid() = reporter_id);

-- Stories
drop policy if exists stories_read on stories;
drop policy if exists stories_insert on stories;
drop policy if exists stories_update_own on stories;
drop policy if exists stories_delete_own on stories;
create policy stories_read on stories for select
using (expires_at > now() or auth.uid() = author_id);
create policy stories_insert on stories for insert
with check (auth.uid() = author_id);
create policy stories_update_own on stories for update
using (auth.uid() = author_id) with check (auth.uid() = author_id);
create policy stories_delete_own on stories for delete
using (auth.uid() = author_id);

-- Story views: a viewer can create/read their own view; author can read views.
drop policy if exists story_views_insert_own on story_views;
drop policy if exists story_views_read_own_or_author on story_views;
create policy story_views_insert_own on story_views for insert
with check (auth.uid() = viewer_id);
create policy story_views_read_own_or_author on story_views for select
using (
  auth.uid() = viewer_id
  or exists(select 1 from stories s where s.id = story_id and s.author_id = auth.uid())
);

-- Video likes/comments
drop policy if exists video_likes_read on video_likes;
drop policy if exists video_likes_own on video_likes;
create policy video_likes_read on video_likes for select using (true);
create policy video_likes_own on video_likes for all
using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists video_comments_read on video_comments;
drop policy if exists video_comments_insert on video_comments;
create policy video_comments_read on video_comments for select using (true);
create policy video_comments_insert on video_comments for insert
with check (auth.uid() = author_id);

-- Sounds are catalog data.
drop policy if exists sounds_public_read on sounds;
create policy sounds_public_read on sounds for select using (true);

-- Follows
drop policy if exists follows_read on follows;
drop policy if exists follows_own on follows;
create policy follows_read on follows for select using (true);
create policy follows_own on follows for all
using (auth.uid() = follower_id) with check (auth.uid() = follower_id);

-- Conversations/messages
drop policy if exists conversations_read on conversations;
drop policy if exists conversations_insert on conversations;
create policy conversations_read on conversations for select
using (auth.uid() = user1_id or auth.uid() = user2_id);
create policy conversations_insert on conversations for insert
with check (auth.uid() = user1_id or auth.uid() = user2_id);

drop policy if exists messages_read on messages;
drop policy if exists messages_read_own on messages;
drop policy if exists messages_send_own on messages;
drop policy if exists messages_insert on messages;
create policy messages_read on messages for select
using (
  auth.uid() = sender_id
  or auth.uid() = recipient_id
  or exists(
    select 1 from conversations c
    where c.id = messages.conversation_id
      and (c.user1_id = auth.uid() or c.user2_id = auth.uid())
  )
);
create policy messages_send_own on messages for insert
with check (
  auth.uid() = sender_id
  and (
    recipient_id is null
    or recipient_id <> auth.uid()
  )
);

-- Calls
drop policy if exists calls_read_own on calls;
drop policy if exists calls_insert_own on calls;
drop policy if exists calls_update_own on calls;
create policy calls_read_own on calls for select
using (auth.uid() = caller_id or auth.uid() = callee_id);
create policy calls_insert_own on calls for insert
with check (auth.uid() = caller_id);
create policy calls_update_own on calls for update
using (auth.uid() = caller_id or auth.uid() = callee_id)
with check (auth.uid() = caller_id or auth.uid() = callee_id);

-- Role requests: only the requester and recipient can see/respond.
drop policy if exists debate_role_requests_read on debate_role_requests;
drop policy if exists debate_role_requests_insert on debate_role_requests;
drop policy if exists debate_role_requests_update on debate_role_requests;
create policy debate_role_requests_read on debate_role_requests for select
using (auth.uid() = from_user_id or auth.uid() = to_user_id);
create policy debate_role_requests_insert on debate_role_requests for insert
with check (auth.uid() = from_user_id);
create policy debate_role_requests_update on debate_role_requests for update
using (auth.uid() = to_user_id or auth.uid() = from_user_id)
with check (auth.uid() = to_user_id or auth.uid() = from_user_id);

-- Protect live roles from client-side self-promotion.
create or replace function prevent_client_role_change()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.role is distinct from old.role and coalesce(auth.role(), '') <> 'service_role' then
    raise exception 'Le rôle ne peut être modifié que par le serveur';
  end if;
  return new;
end;
$$;

drop trigger if exists debate_participants_role_guard on debate_participants;
create trigger debate_participants_role_guard
before update on debate_participants
for each row execute function prevent_client_role_change();

-- Debate messages: clients may only create user messages. AI/system
-- messages must be created by trusted server code (service_role).
create or replace function baaro_guard_debate_message_sender()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.sender_type in ('ai','system') and coalesce(auth.role(), '') <> 'service_role' then
    raise exception 'Les messages IA/système sont réservés au serveur';
  end if;
  if new.sender_type = 'user' and new.sender_id is distinct from auth.uid()
     and coalesce(auth.role(), '') <> 'service_role' then
    raise exception 'Expéditeur invalide';
  end if;
  return new;
end;
$$;

drop trigger if exists debate_messages_sender_guard on debate_messages;
create trigger debate_messages_sender_guard
before insert on debate_messages
for each row execute function baaro_guard_debate_message_sender();

-- ============================================================
-- WALLET SAFETY
-- ============================================================
alter table wallets enable row level security;
alter table transactions enable row level security;
alter table crypto_holdings enable row level security;

drop policy if exists wallet_own on wallets;
drop policy if exists wallet_read_own on wallets;
create policy wallet_read_own on wallets for select using (auth.uid() = user_id);

drop policy if exists tx_own on transactions;
drop policy if exists tx_read_own on transactions;
create policy tx_read_own on transactions for select using (auth.uid() = user_id);

drop policy if exists crypto_own on crypto_holdings;
drop policy if exists crypto_read_own on crypto_holdings;
create policy crypto_read_own on crypto_holdings for select using (auth.uid() = user_id);


create or replace function baaro_convert_points(
  p_user_id uuid,
  p_points numeric,
  p_baro numeric,
  p_label text
)
returns table(new_balance numeric, new_holdings numeric, transaction_id uuid)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_balance numeric;
  v_holdings numeric;
  v_tx uuid;
begin
  if p_user_id is null or p_points <= 0 or p_baro <= 0 then
    raise exception 'Paramètres de conversion invalides';
  end if;

  select balance into v_balance from wallets where user_id = p_user_id for update;
  if v_balance is null or v_balance < p_points then
    raise exception 'Solde insuffisant';
  end if;

  update wallets
    set balance = balance - p_points, updated_at = now()
    where user_id = p_user_id
    returning balance into v_balance;

  insert into transactions(user_id, label, pts)
  values(p_user_id, left(coalesce(p_label,'Conversion BARO'), 500), -p_points)
  returning id into v_tx;

  insert into crypto_holdings(user_id, holdings)
  values(p_user_id, p_baro)
  on conflict (user_id) do update
    set holdings = crypto_holdings.holdings + excluded.holdings,
        updated_at = now();

  select holdings into v_holdings from crypto_holdings where user_id = p_user_id;

  return query select v_balance, v_holdings, v_tx;
end;
$$;

revoke all on function baaro_convert_points(uuid,numeric,numeric,text) from public;
grant execute on function baaro_convert_points(uuid,numeric,numeric,text) to service_role;

-- ============================================================
-- INDEXES / REALTIME
-- ============================================================
create index if not exists idx_comments_post_created on comments(post_id, created_at);
create index if not exists idx_story_views_story on story_views(story_id);
create index if not exists idx_video_comments_video_created on video_comments(video_id, created_at);
create index if not exists idx_video_likes_user on video_likes(user_id);
create index if not exists idx_calls_conversation_created on calls(conversation_id, created_at);
create index if not exists idx_role_requests_target_status on debate_role_requests(to_user_id, status);

do $$ begin
  alter publication supabase_realtime add table messages;
exception when duplicate_object then null; end $$;
do $$ begin
  alter publication supabase_realtime add table conversations;
exception when duplicate_object then null; end $$;
do $$ begin
  alter publication supabase_realtime add table stories;
exception when duplicate_object then null; end $$;
do $$ begin
  alter publication supabase_realtime add table story_views;
exception when duplicate_object then null; end $$;
do $$ begin
  alter publication supabase_realtime add table video_likes;
exception when duplicate_object then null; end $$;
do $$ begin
  alter publication supabase_realtime add table debate_role_requests;
exception when duplicate_object then null; end $$;

-- ============================================================
-- STORAGE BUCKETS
-- ============================================================
insert into storage.buckets (id, name, public)
values
  ('media','media',true),
  ('stories','stories',true),
  ('videos','videos',true),
  ('chat-media','chat-media',false)
on conflict (id) do nothing;

-- Public media/stories/videos: read public; writes restricted to a user's
-- own top-level folder (<auth.uid()>/filename).
drop policy if exists baaro_media_read on storage.objects;
drop policy if exists baaro_media_insert on storage.objects;
drop policy if exists baaro_stories_insert on storage.objects;
drop policy if exists baaro_videos_insert on storage.objects;
create policy baaro_media_read on storage.objects for select
using (bucket_id in ('media','stories','videos'));
create policy baaro_media_insert on storage.objects for insert
with check (
  bucket_id in ('media','stories','videos')
  and auth.uid() is not null
  and (storage.foldername(name))[1] = auth.uid()::text
);

-- Private chat media: only authenticated users can insert/read their own
-- first-level folder. Conversation-level sharing should be handled by the
-- application if this bucket is used for private attachments.
drop policy if exists baaro_chat_media_read on storage.objects;
drop policy if exists baaro_chat_media_insert on storage.objects;
create policy baaro_chat_media_read on storage.objects for select
using (
  bucket_id = 'chat-media'
  and auth.uid() is not null
  and (storage.foldername(name))[1] = auth.uid()::text
);
create policy baaro_chat_media_insert on storage.objects for insert
with check (
  bucket_id = 'chat-media'
  and auth.uid() is not null
  and (storage.foldername(name))[1] = auth.uid()::text
);

-- ============================================================
-- WALLET ATOMIC RPC
-- ============================================================
create or replace function baaro_wallet_delta(
  p_user_id uuid,
  p_delta numeric,
  p_label text,
  p_enforce_nonnegative boolean default true,
  p_daily_cap numeric default null
)
returns table(new_balance numeric, transaction_id uuid)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_balance numeric;
  v_tx uuid;
begin
  if p_user_id is null or p_delta = 0 then
    raise exception 'Paramètres wallet invalides';
  end if;

  if p_daily_cap is not null and p_delta > 0 then
    if coalesce((select sum(pts) from transactions
                 where user_id = p_user_id
                   and pts > 0
                   and created_at >= date_trunc('day', now())), 0) + p_delta > p_daily_cap then
      raise exception 'Plafond quotidien de gains atteint';
    end if;
  end if;

  select balance into v_balance
  from wallets
  where user_id = p_user_id
  for update;

  if v_balance is null then
    insert into wallets(user_id, balance)
    values(p_user_id, greatest(0, p_delta));
    v_balance := greatest(0, p_delta);
  elsif p_enforce_nonnegative and v_balance + p_delta < 0 then
    raise exception 'Solde insuffisant';
  else
    update wallets
    set balance = v_balance + p_delta, updated_at = now()
    where user_id = p_user_id;
    v_balance := v_balance + p_delta;
  end if;

  insert into transactions(user_id, label, pts)
  values(p_user_id, left(coalesce(p_label,'BAARO'), 500), p_delta)
  returning id into v_tx;

  return query select v_balance, v_tx;
end;
$$;

revoke all on function baaro_wallet_delta(uuid,numeric,text,boolean,numeric) from public;
grant execute on function baaro_wallet_delta(uuid,numeric,text,boolean,numeric) to service_role;

-- Ensure service-role only writes wallet tables.
revoke insert, update, delete on wallets, transactions, crypto_holdings from anon, authenticated;
