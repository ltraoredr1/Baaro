# BAARO AI Agent v3 – Mémoire + Outils + RAG Vectoriel

Package **complet** intégrant une **base de données vectorielle** (RAG) dans l’assistant IA de BAARO via n8n + Supabase pgvector.

---

## Nouveautés v3

| Fonctionnalité | Description |
|---|---|
| **Base vectorielle (pgvector)** | Table `knowledge_documents` + fonction `match_knowledge` |
| **Outil `search_knowledge`** | Recherche sémantique dans la FAQ / règles / features BAARO |
| **Workflow d’ingestion** | Endpoint pour ajouter de nouveaux documents + générer les embeddings |
| **Mémoire conversationnelle** | Conservée (12 messages) |
| **Outils portefeuille / profil** | Conservés |

L’agent peut maintenant répondre précisément aux questions du type :
- « Comment gagner des points ? »
- « C’est quoi le BARO Coin ? »
- « La messagerie est-elle chiffrée ? »
- « Comment fonctionne le parrainage ? »

… en s’appuyant sur ta base de connaissances plutôt que sur les connaissances générales du modèle.

---

## Contenu du package

```
baaro-n8n-ai-v3/
├── sql/
│   └── supabase-vector-setup.sql     ← À exécuter dans Supabase
├── workflow/
│   ├── BAARO-AI-Agent-v3-RAG.json    ← Agent principal
│   └── BAARO-Ingest-Knowledge.json   ← Ingestion de documents
├── integration/
│   └── chat-n8n-v3.js
└── docs/
    └── README.md
```

---

## 1. Préparer Supabase (pgvector)

1. Va dans **SQL Editor** de ton projet Supabase
2. Colle et exécute le contenu de `sql/supabase-vector-setup.sql`
3. Vérifie que la table `knowledge_documents` existe et contient les 7 documents d’exemple

> **Important** : les documents d’exemple n’ont **pas encore d’embedding**.  
> Il faut les indexer via le workflow d’ingestion (étape 3).

---

## 2. Variables d’environnement dans n8n

```env
SUPABASE_URL=https://xxxxx.supabase.co
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOi...
OPENAI_API_KEY=sk-...                    # pour les embeddings (text-embedding-3-small)
```

Credentials nécessaires :
- **Anthropic** (Claude) pour l’agent
- **OpenAI** (ou header auth) pour les embeddings

---

## 3. Importer les workflows

### A. Agent principal
1. Importe `BAARO-AI-Agent-v3-RAG.json`
2. Configure la credential Anthropic
3. Active → copie l’URL du webhook (`/webhook/baaro-ai`)

### B. Ingestion (recommandé)
1. Importe `BAARO-Ingest-Knowledge.json`
2. Configure l’auth OpenAI (header `Authorization: Bearer sk-...`)
3. Active → note l’URL (`/webhook/baaro-ingest`)

---

## 4. Indexer les documents existants

Les documents d’exemple n’ont pas d’embedding. Tu dois les indexer une fois.

### Option A – Via le webhook d’ingestion (recommandé)

Pour chaque document :

```bash
curl -X POST https://TON-N8N/webhook/baaro-ingest \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Comment gagner des points sur BAARO",
    "content": "Sur BAARO tu gagnes des points en : publier une pensée...",
    "category": "faq"
  }'
```

### Option B – Script rapide (tous les documents d’exemple)

Tu peux aussi créer un petit script Node qui lit les documents de la table et appelle le webhook d’ingestion pour chacun.

### Vérification

```sql
select title, category, embedding is not null as has_embedding
from knowledge_documents;
```

Tous doivent avoir `has_embedding = true`.

---

## 5. Intégration dans BAARO

1. Remplace `api/chat.js` par `integration/chat-n8n-v3.js`
2. Variables Vercel / `.env` :
   ```env
   N8N_BAARO_WEBHOOK_URL=https://ton-n8n.../webhook/baaro-ai
   ```
3. (Recommandé) Stocke le `sessionId` dans `localStorage` côté front
4. Redéploie

---

## 6. Architecture v3

```
Question utilisateur
       ↓
   Webhook n8n
       ↓
Préparer Prompt + SessionId
       ↓
┌──────────────────────────────────────┐
│         Agent IA (Claude)            │
│  ├── Mémoire (12 messages)           │
│  ├── search_knowledge (RAG)  ←───────┼── pgvector / Supabase
│  ├── get_wallet                      │
│  ├── get_profile                     │
│  └── get_recent_activity             │
└──────────────────────────────────────┘
       ↓
Réponse enrichie → BAARO
```

Le flux RAG :
1. L’agent décide d’appeler `search_knowledge`
2. OpenAI génère l’embedding de la question
3. Supabase exécute `match_knowledge` (similarité cosinus)
4. Les documents les plus pertinents sont renvoyés à l’agent
5. L’agent génère la réponse à partir de ces documents

---

## 7. Enrichir la base de connaissances

Tu peux ajouter autant de documents que tu veux :

```bash
curl -X POST https://TON-N8N/webhook/baaro-ingest \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Comment convertir des points en BARO",
    "content": "Pour convertir : va dans l’onglet Portefeuille → Convertir. Le taux est de X points = 1 BARO. Minimum Y points.",
    "category": "tutorial",
    "source": "docs internes"
  }'
```

Catégories suggérées : `faq`, `rules`, `feature`, `tutorial`, `changelog`.

---

## 8. Coûts approximatifs

| Élément | Coût |
|---|---|
| Embeddings (`text-embedding-3-small`) | ~0,02 $ / 1M tokens |
| Stockage pgvector | Inclus dans Supabase free/pro |
| Claude (agent) | Selon ton usage |

Pour une FAQ de quelques centaines de documents, le coût d’embedding est négligeable.

---

## 9. Alternatives possibles

Si tu préfères une autre base vectorielle plus tard :
- **Pinecone** (nœud natif n8n)
- **Qdrant** (nœud natif)
- **Weaviate**
- **Chroma**

Le code de l’outil `search_knowledge` est isolé → facile à remplacer.

---

**Package v3 créé le 6 août 2026 – prêt pour production avec RAG.**
