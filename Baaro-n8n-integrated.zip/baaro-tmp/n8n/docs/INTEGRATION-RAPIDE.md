# BAARO AI v3 (RAG) – Intégration rapide

## 1. Supabase
Exécute `sql/supabase-vector-setup.sql` dans le SQL Editor.

## 2. Variables n8n
```
SUPABASE_URL=...
SUPABASE_SERVICE_ROLE_KEY=...
OPENAI_API_KEY=...          # pour les embeddings
```

## 3. Workflows
- Importe `BAARO-AI-Agent-v3-RAG.json` → active → copie l’URL webhook
- Importe `BAARO-Ingest-Knowledge.json` → active

## 4. Indexer les documents
Pour chaque document d’exemple (ou nouveaux) :
```bash
curl -X POST https://TON-N8N/webhook/baaro-ingest \
  -H "Content-Type: application/json" \
  -d '{"title":"...","content":"...","category":"faq"}'
```

## 5. BAARO
- Remplace `api/chat.js` par `chat-n8n-v3.js`
- Ajoute `N8N_BAARO_WEBHOOK_URL=...`
- Redéploie

L’agent utilise maintenant la base vectorielle.
