// api/chat.js
// Assistant IA BAARO
// Mode 1 (recommandé) : N8N_BAARO_WEBHOOK_URL défini → agent n8n (mémoire + outils + RAG)
// Mode 2 (fallback)   : appel direct à Claude (comportement historique)

export default async function handler(req, res) {
  // CORS
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Session-Id");

  if (req.method === "OPTIONS") {
    return res.status(200).end();
  }

  if (req.method !== "POST") {
    return res.status(405).json({ error: "Méthode non autorisée" });
  }

  const body = req.body || {};
  const { messages, context, max_tokens, mode, system: customSystem } = body;

  if (!Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: "messages doit être un tableau non vide" });
  }

  // ─── Mode n8n (agent avancé : mémoire + outils Supabase + RAG) ───
  const n8nUrl = process.env.N8N_BAARO_WEBHOOK_URL;
  if (n8nUrl) {
    try {
      const sessionId =
        req.headers["x-session-id"] ||
        body.sessionId ||
        context?.user_id ||
        context?.handle ||
        `session-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;

      const response = await fetch(n8nUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Session-Id": sessionId,
          ...(process.env.N8N_WEBHOOK_SECRET
            ? { "X-N8N-Secret": process.env.N8N_WEBHOOK_SECRET }
            : {}),
        },
        body: JSON.stringify({
          messages,
          context: context || {},
          max_tokens: max_tokens || 1200,
          mode: mode || "default",
          system: customSystem || null,
          sessionId,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        console.error("Erreur n8n BAARO AI:", data);
        return res.status(response.status).json({
          error: data.error || data.message || "Erreur agent n8n",
        });
      }

      const replyText =
        data.reply ||
        data.content?.[0]?.text ||
        data.content?.find?.((c) => c.type === "text")?.text ||
        "Désolé, je n'ai pas pu générer une réponse.";

      res.setHeader("X-Session-Id", data.sessionId || sessionId);

      return res.status(200).json({
        ...data,
        reply: replyText,
        sessionId: data.sessionId || sessionId,
        provider: "n8n",
      });
    } catch (err) {
      console.error("Erreur /api/chat (n8n) :", err);
      return res.status(500).json({ error: "Erreur serveur lors de l'appel à l'agent n8n" });
    }
  }

  // ─── Mode fallback : appel direct Anthropic (comportement historique) ───
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(500).json({
      error:
        "Ni N8N_BAARO_WEBHOOK_URL ni ANTHROPIC_API_KEY ne sont configurés. " +
        "Configure au moins l'une des deux variables d'environnement.",
    });
  }

  try {
    const safeMaxTokens = Math.min(Number(max_tokens) || 1200, 2000);

    let systemPrompt =
      customSystem ||
      `Tu es l'assistant officiel de BAARO, un réseau social mondial avec portefeuille de points, crypto interne BARO Coin, messagerie chiffrée et débats live.
Tu es bienveillant, concis, actionnable et expert en engagement communautaire.
Réponds toujours en français, de façon claire, motivante et utile.
Tu peux proposer des actions concrètes (créer un débat, publier, gagner des points, etc.).`;

    if (context && typeof context === "object") {
      systemPrompt += `\n\nContexte utilisateur actuel :
- Nom : ${context.display_name || "Membre"}
- Handle : ${context.handle || "non renseigné"}
- Solde points : ${context.points ?? 0}
- Solde BARO : ${context.baro ?? 0}
- Bio : ${context.bio || "non renseignée"}
- Débats récents : ${context.recent_debates || "aucun"}`;
    }

    if (mode === "cohost") {
      systemPrompt += `\n\nTu es actuellement la co-animatrice IA d'un débat live.
Sois dynamique, pose des questions pertinentes, relance le débat, félicite les bons arguments et reste neutre.
Réponds en 1 à 3 phrases maximum pour ne pas monopoliser le chat.`;
    }

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: safeMaxTokens,
        system: systemPrompt,
        messages: messages.map((m) => ({
          role: m.role === "assistant" ? "assistant" : "user",
          content: typeof m.content === "string" ? m.content : m.text || "",
        })),
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      console.error("Erreur Anthropic:", data);
      return res.status(response.status).json({
        error: data.error?.message || "Erreur lors de l'appel à Claude",
      });
    }

    const replyText =
      data.content?.[0]?.text ||
      data.content?.find?.((c) => c.type === "text")?.text ||
      "Désolé, je n'ai pas pu générer une réponse.";

    return res.status(200).json({
      ...data,
      reply: replyText,
      provider: "anthropic-direct",
    });
  } catch (err) {
    console.error("Erreur /api/chat (Anthropic) :", err);
    return res.status(500).json({ error: "Erreur serveur lors de l'appel à Claude" });
  }
}
