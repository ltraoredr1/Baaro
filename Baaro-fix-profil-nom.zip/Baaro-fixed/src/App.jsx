import { useState, useCallback, useEffect } from "react";
import { supabase } from "./supabaseClient";
import { ToastProvider } from "./components/ToastContext.jsx";
import { Header } from "./components/Header.jsx";
import { Navigation } from "./components/Navigation.jsx";
import { FeedTab } from "./components/FeedTab.jsx";
import { VideosTab } from "./components/VideosTab.jsx";
import { MessagesTab } from "./components/MessagesTab.jsx";
import { WalletTab } from "./components/WalletTab.jsx";
import { CryptoTab } from "./components/CryptoTab.jsx";
import DebatesTab from "./components/DebatesTab.jsx";
import { OfflineTab } from "./components/OfflineTab.jsx";
import { AiAssistantTab } from "./components/AiAssistantTab.jsx";
import { SettingsTab } from "./components/SettingsTab.jsx";
import { ProfileModal } from "./components/ProfileModal.jsx";
import { NotificationDrawer } from "./components/NotificationDrawer.jsx";
import { GlobalSearchModal } from "./components/GlobalSearchModal.jsx";
import { FriendsTab } from "./components/FriendsTab.jsx";
import { COLORS } from "./theme.js";
import AuthScreen from "./components/AuthScreen.jsx";

const THEME_BG_MAP = {
  midnight: "#0B1220",
  oled: "#000000",
  emerald: "#061A14",
};

function MainAppContent({ session }) {
  const [activeTab, setActiveTab] = useState("feed");
  const [lang, setLang] = useState("fr");
  const [pointsBalance, setPointsBalance] = useState(0);
  const [baroBalance, setBaroBalance] = useState(0);
  const [inspectingProfileId, setInspectingProfileId] = useState(null);
  const [notifDrawerOpen, setNotifDrawerOpen] = useState(false);
  const [searchModalOpen, setSearchModalOpen] = useState(false);
  const [currentTheme, setCurrentTheme] = useState("midnight");
  const [userId, setUserId] = useState(null);
  const [userProfile, setUserProfile] = useState({
    display_name: "Membre BAARO",
    handle: "@membre",
    flag: "🌍",
    bio: "",
  });
  const [loadingData, setLoadingData] = useState(true);

  useEffect(() => {
    if (!session?.user) return;

    const loadUserData = async () => {
      setLoadingData(true);
      const uid = session.user.id;
      setUserId(uid);

      try {
        // ===== 3 REQUÊTES EN PARALLÈLE (au lieu de séquentielles) =====
        const [profileRes, walletRes, cryptoRes] = await Promise.all([
          supabase
            .from("profiles")
            .select("display_name, handle, flag, bio")
            .eq("user_id", uid)
            .maybeSingle(),
          supabase
            .from("wallets")
            .select("balance")
            .eq("user_id", uid)
            .maybeSingle(),
          supabase
            .from("crypto_holdings")
            .select("holdings")
            .eq("user_id", uid)
            .maybeSingle(),
        ]);

        let profile = profileRes.data;

        // Métadonnées auth (email / OAuth) pour un vrai nom dès la 1re connexion
        const meta = session.user.user_metadata || {};
        const email = session.user.email || "";
        const emailName = email.includes("@") ? email.split("@")[0] : "";
        const smartName =
          (meta.display_name && String(meta.display_name).trim()) ||
          (meta.full_name && String(meta.full_name).trim()) ||
          (meta.name && String(meta.name).trim()) ||
          (emailName ? emailName : "") ||
          "Membre BAARO";
        const smartHandle =
          (meta.handle && String(meta.handle).trim()) ||
          (emailName ? `@${emailName.slice(0, 20).replace(/[^a-zA-Z0-9_]/g, "")}` : "") ||
          `@user_${uid.slice(0, 8)}`;

        if (!profile) {
          // Création UNIQUEMENT si le profil n'existe pas (pas d'écrasement)
          const { data: created, error: createErr } = await supabase
            .from("profiles")
            .insert({
              user_id: uid,
              display_name: smartName,
              handle: smartHandle,
              flag: meta.flag || "🌍",
              bio: meta.bio || "",
            })
            .select("display_name, handle, flag, bio")
            .single();

          if (createErr) {
            // Race condition : un autre onglet a déjà créé le profil
            const { data: again } = await supabase
              .from("profiles")
              .select("display_name, handle, flag, bio")
              .eq("user_id", uid)
              .maybeSingle();
            profile = again;
          } else {
            profile = created;
          }
        } else {
          // Profil existant : ne JAMAIS écraser un vrai nom par "Membre BAARO"
          // Si le nom est encore générique et qu'on a un meilleur nom auth → mettre à jour une fois
          const generic = !profile.display_name ||
            profile.display_name === "Membre BAARO" ||
            profile.display_name === "Nouveau membre";
          if (generic && smartName && smartName !== "Membre BAARO") {
            const { data: updated } = await supabase
              .from("profiles")
              .update({
                display_name: smartName,
                handle: profile.handle?.startsWith("@user_") || profile.handle === "@membre"
                  ? smartHandle
                  : profile.handle,
              })
              .eq("user_id", uid)
              .select("display_name, handle, flag, bio")
              .single();
            if (updated) profile = updated;
          }
        }

        if (profile) {
          setUserProfile({
            display_name: profile.display_name || smartName || "Membre BAARO",
            handle: profile.handle || smartHandle || "@membre",
            flag: profile.flag || "🌍",
            bio: profile.bio || "",
          });
        }

        if (walletRes.data) {
          setPointsBalance(Number(walletRes.data.balance) || 0);
        } else {
          await supabase.from("wallets").upsert({
            user_id: uid,
            balance: 1284,
          });
          setPointsBalance(1284);
        }

        if (cryptoRes.data) {
          setBaroBalance(Number(cryptoRes.data.holdings) || 0);
        }
      } catch (error) {
        console.error("Erreur chargement données utilisateur:", error);
      } finally {
        setLoadingData(false);
      }
    };

    loadUserData();
  }, [session]);

  const handleRewardPoints = useCallback((ptsOrNewBalance) => {
    if (typeof ptsOrNewBalance !== "number") return;

    if (ptsOrNewBalance > 50) {
      setPointsBalance(ptsOrNewBalance);
    } else {
      setPointsBalance((prev) => prev + ptsOrNewBalance);
    }
  }, []);

  const themeBg = THEME_BG_MAP[currentTheme] || THEME_BG_MAP.midnight;

  if (loadingData) {
    return (
      <div
        className="min-h-screen flex items-center justify-center"
        style={{ background: themeBg, color: "white" }}
      >
        <div className="text-center">
          <div className="text-4xl mb-4 animate-pulse">⏳</div>
          <p>Chargement de votre espace BAARO...</p>
        </div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen flex flex-col transition-colors duration-500"
      style={{ background: themeBg, color: COLORS.ivory }}
    >
      <Header
        lang={lang}
        setLang={setLang}
        pointsBalance={pointsBalance}
        baroBalance={baroBalance}
        userProfile={userProfile}
        onOpenProfile={() => setInspectingProfileId(userId)}
        onOpenNotifications={() => setNotifDrawerOpen(true)}
        onOpenSearch={() => setSearchModalOpen(true)}
      />

      <div className="max-w-7xl mx-auto w-full px-3 sm:px-6 pt-4 sm:pt-6 flex-1 grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="md:col-span-1">
          <Navigation activeTab={activeTab} setActiveTab={setActiveTab} />
        </div>

        <main className="md:col-span-3">
          {activeTab === "feed" && (
            <FeedTab
              userId={userId}
              onOpenProfile={(authorId) => setInspectingProfileId(authorId)}
              onRewardPoints={handleRewardPoints}
            />
          )}

          {activeTab === "friends" && (
            <FriendsTab
              onSelectUser={(id) => setInspectingProfileId(id)}
              onNavigateToMessages={() => setActiveTab("messages")}
            />
          )}

          {activeTab === "videos" && (
            <VideosTab userId={userId} onRewardPoints={handleRewardPoints} />
          )}

          {activeTab === "messages" && (
            <MessagesTab userId={userId} onRewardPoints={handleRewardPoints} />
          )}

          {activeTab === "wallet" && (
            <WalletTab
              userId={userId}
              pointsBalance={pointsBalance}
              baroBalance={baroBalance}
              onRewardPoints={handleRewardPoints}
              onNavigateToCrypto={() => setActiveTab("crypto")}
            />
          )}

          {activeTab === "crypto" && (
            <CryptoTab
              userId={userId}
              pointsBalance={pointsBalance}
              baroBalance={baroBalance}
              onRewardPoints={handleRewardPoints}
              setPointsBalance={setPointsBalance}
              setBaroBalance={setBaroBalance}
            />
          )}

          {activeTab === "debates" && (
            <DebatesTab
              currentUserId={userId}
              onRewardPoints={handleRewardPoints}
            />
          )}

          {activeTab === "offline" && (
            <OfflineTab onRewardPoints={handleRewardPoints} />
          )}

          {activeTab === "assistant" && (
            <AiAssistantTab
              userId={userId}
              userProfile={userProfile}
              pointsBalance={pointsBalance}
              baroBalance={baroBalance}
              onRewardPoints={handleRewardPoints}
            />
          )}

          {activeTab === "settings" && (
            <SettingsTab
              userId={userId}
              userProfile={userProfile}
              setUserProfile={setUserProfile}
              currentTheme={currentTheme}
              onSelectTheme={setCurrentTheme}
            />
          )}
        </main>
      </div>

      {inspectingProfileId && (
        <ProfileModal
          authorId={inspectingProfileId}
          currentUserId={userId}
          onClose={() => setInspectingProfileId(null)}
          onNavigateToMessages={() => setActiveTab("messages")}
        />
      )}

      <NotificationDrawer
        isOpen={notifDrawerOpen}
        onClose={() => setNotifDrawerOpen(false)}
        userId={userId}
      />

      <GlobalSearchModal
        isOpen={searchModalOpen}
        onClose={() => setSearchModalOpen(false)}
        onSelectUser={(id) => setInspectingProfileId(id)}
        onSelectTab={(tabId) => setActiveTab(tabId)}
      />
    </div>
  );
}

export default function App() {
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setLoading(false);
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });

    return () => subscription.unsubscribe();
  }, []);

  if (loading) {
    return (
      <div
        className="min-h-screen flex items-center justify-center"
        style={{ background: "#0B1220", color: "white" }}
      >
        <div className="text-center">
          <div className="text-4xl mb-4">⏳</div>
          <p>Chargement de BAARO...</p>
        </div>
      </div>
    );
  }

  if (!session) {
    return <AuthScreen />;
  }

  return (
    <ToastProvider>
      <MainAppContent session={session} />
    </ToastProvider>
  );
}
