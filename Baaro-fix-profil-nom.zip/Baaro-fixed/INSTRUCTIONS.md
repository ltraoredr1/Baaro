# BAARO — Corrections (abonnement + vidéos)

## Fichiers à remplacer dans ton projet

| Fichier corrigé | Destination |
|-----------------|-------------|
| `src/components/FollowButton.jsx` | `src/components/FollowButton.jsx` |
| `src/components/FriendsTab.jsx` | `src/components/FriendsTab.jsx` |
| `src/components/GlobalSearchModal.jsx` | `src/components/GlobalSearchModal.jsx` |
| `src/components/VideosTab.jsx` | `src/components/VideosTab.jsx` |
| `src/hooks/useSocial.js` | `src/hooks/useSocial.js` |
| `src/hooks/useProfile.js` | `src/hooks/useProfile.js` |
| `src/data/users.js` | `src/data/users.js` |
| `src/App.jsx` | `src/App.jsx` |

## Ce qui est corrigé

1. **Erreur `followed_id`** — tous les inserts/selects utilisent maintenant `following_id` + `status`.
2. **S'abonner depuis une vidéo** — bouton "S'abonner" / "Abonné" à côté de l'auteur.
3. **Caméra** — dans "Publier une vidéo" :
   - **Caméra + son**
   - **Caméra sans son**
   - Enregistrement → puis publication classique (titre, description, son optionnel).

## Déploiement

```bash
# Après avoir remplacé les fichiers
git add .
git commit -m "fix: follows following_id + follow on videos + camera record"
git push
```

Vercel redéploiera automatiquement. Ensuite teste sur https://baaro-xi.vercel.app

## Rappel SQL

La table `follows` doit avoir les colonnes :
id, follower_id, following_id, status, is_friend, created_at
(déjà validé de ton côté)
