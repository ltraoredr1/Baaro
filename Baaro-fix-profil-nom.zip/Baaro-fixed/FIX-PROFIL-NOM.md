# Correctif : le nom redevient « Membre BAARO / Nouveau membre »

## Cause
À chaque connexion, si le profil manquait (ou était générique), `App.jsx` le créait avec le nom fixe « Membre BAARO », sans lire l'email ni les métadonnées auth.

## Fichiers à remplacer
1. `src/App.jsx`
2. `src/components/AuthScreen.jsx`

## Comportement après correctif
- Connexion **email** → le nom = partie avant @ (ex. `lassinetraoredr`)
- Handle = `@lassinetraoredr`
- Si le profil existe déjà avec un vrai nom → **il n'est plus écrasé**
- Si le profil est encore « Nouveau membre » / « Membre BAARO » → il est mis à jour une fois avec le nom de l'email

## Après déploiement
1. Déconnecte-toi
2. Reconnecte-toi avec ton email
3. Ton nom doit s'afficher correctement
4. Tu peux le personnaliser dans **Paramètres**
