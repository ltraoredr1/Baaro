import { S3Client, PutObjectCommand, HeadObjectCommand, GetObjectCommand, DeleteObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { applyCors, getAdminClient, requireUser, rateLimitAsync } from "./_shared.js";
import { detectStoryMediaType, isCompatibleStoryMime } from "./_lib/story-media-signature.js";
import crypto from "node:crypto";

const MAX_BYTES = 500 * 1024 * 1024;
const MAX_STORY_BYTES = 100 * 1024 * 1024;
const maxBytesForFolder = (folder) => folder === "stories" ? MAX_STORY_BYTES : MAX_BYTES;
// Les dossiers utilisés par les uploads média doivent être explicitement autorisés.
const FOLDERS = new Set([
  "profiles",
  "posts",
  "videos",
  "stories",
  "comments",
  "chat",
  "shop",
  "misc",
]);

function getR2() {
  const accountId = process.env.R2_ACCOUNT_ID;
  const accessKeyId = process.env.R2_ACCESS_KEY_ID;
  const secretAccessKey = process.env.R2_SECRET_ACCESS_KEY;
  const bucket = process.env.R2_BUCKET_NAME || "baaro-media";
  if (!accountId || !accessKeyId || !secretAccessKey) throw new Error("R2 non configuré");
  return {
    bucket,
    publicBase: String(process.env.R2_PUBLIC_BASE_URL || "").replace(/\/+$/, ""),
    client: new S3Client({
      region: "auto",
      endpoint: `https://${accountId}.r2.cloudflarestorage.com`,
      credentials: { accessKeyId, secretAccessKey },
      // Évite des URLs signées refusées par R2 avec les SDK récents
      requestChecksumCalculation: "WHEN_REQUIRED",
      responseChecksumValidation: "WHEN_REQUIRED",
    }),
  };
}

function safeExt(value) {
  const ext = String(value || "bin").toLowerCase().replace(/[^a-z0-9]/g, "");
  return ext.slice(0, 10) || "bin";
}

// Seuls html et svg sont bloqués (contenu actif servi depuis le domaine du bucket)
const BLOCKED_MIME = new Set(["text/html", "application/xhtml+xml", "image/svg+xml"]);
const BLOCKED_EXT = new Set(["html", "htm", "xhtml", "svg", "svgz"]);

function isBlocked(contentType, ext) {
  const mime = String(contentType || "").split(";")[0].trim().toLowerCase();
  return BLOCKED_MIME.has(mime) || BLOCKED_EXT.has(safeExt(ext));
}

export default async function handler(req, res) {
  if (applyCors(req, res)) return;
  if (req.method !== "POST") return res.status(405).json({ ok: false, error: "Méthode non autorisée" });

  const limiter = await rateLimitAsync(req, { key: "media", max: 30, windowMs: 60_000 });
  if (!limiter.ok) {
    Object.entries(limiter.headers || {}).forEach(([k, v]) => res.setHeader(k, v));
    return res.status(limiter.status).json(limiter.body);
  }

  let admin;
  try { admin = getAdminClient(); } catch { return res.status(500).json({ ok: false, error: "Configuration serveur indisponible" }); }

  let user;
  try { user = await requireUser(req, admin); }
  catch (e) { return res.status(e.status || 401).json({ ok: false, error: e.message || "Non authentifié" }); }

  const body = req.body || {};
  if (!["prepare", "finalize", "discard"].includes(body.action)) {
    return res.status(400).json({ ok: false, error: "Action invalide" });
  }

  // Nettoyage compensatoire : le fichier est sur R2 mais la publication n'a pas été créée.
  if (body.action === "discard") {
    const objectKey = String(body.path || "").replace(/^\/+/, "");
    const folder = objectKey.split("/")[0];
    if (!FOLDERS.has(folder) || objectKey.includes("..") || !objectKey.startsWith(`${folder}/${user.id}/`)) {
      return res.status(400).json({ ok: false, error: "Chemin média invalide" });
    }
    try {
      const r2 = getR2();
      const publicUrl = r2.publicBase ? `${r2.publicBase}/${objectKey}` : null;

      // Garde-fou : on ne supprime jamais un fichier déjà référencé par une vidéo
      // (ex. insertion réussie mais réponse perdue côté réseau).
      if (publicUrl) {
        const { data: refs, error: refError } = await admin
          .from("videos").select("id").eq("video_url", publicUrl).limit(1);
        if (refError) throw refError;
        if (refs?.length) return res.status(200).json({ ok: true, discarded: false, reason: "referenced" });
      }

      await r2.client.send(new DeleteObjectCommand({ Bucket: r2.bucket, Key: objectKey }));
      await admin.from("media_assets").delete()
        .eq("bucket", r2.bucket).eq("object_key", objectKey).eq("owner_id", user.id);
      return res.status(200).json({ ok: true, discarded: true });
    } catch (e) {
      console.error("[media:discard]", e);
      return res.status(500).json({ ok: false, error: "Nettoyage média impossible" });
    }
  }

  if (body.action === "finalize") {
    const objectKey = String(body.path || "").replace(/^\/+/, "");
    const publicUrl = String(body.publicUrl || "");
    const folder = String(body.folder || objectKey.split("/")[0] || "misc");
    const size = Number(body.size);
    const mime = String(body.contentType || "application/octet-stream").slice(0, 150);
    let storageMime = mime;
    const fileName = String(body.fileName || "upload").slice(0, 255);
    if (!FOLDERS.has(folder) || !objectKey.startsWith(`${folder}/${user.id}/`) || !Number.isSafeInteger(size) || size <= 0 || size > maxBytesForFolder(folder)) {
      return res.status(400).json({ ok: false, error: "Métadonnées média invalides" });
    }
    if (isBlocked(mime, objectKey.split(".").pop())) {
      return res.status(415).json({ ok: false, error: "Les fichiers HTML et SVG ne sont pas autorisés." });
    }
    try {
      const r2 = getR2();
      if (!r2.publicBase) throw new Error("R2_PUBLIC_BASE_URL manquante");
      const expectedUrl = `${r2.publicBase}/${objectKey}`;
      if (publicUrl !== expectedUrl) return res.status(400).json({ ok: false, error: "URL média invalide" });

      // La taille réelle R2 est autoritaire : ne pas se fier au poids déclaré par le client.
      let realSize = size;
      try {
        const head = await r2.client.send(new HeadObjectCommand({ Bucket: r2.bucket, Key: objectKey }));
        if (Number.isSafeInteger(Number(head.ContentLength)) && Number(head.ContentLength) > 0) {
          realSize = Number(head.ContentLength);
        }
      } catch {
        return res.status(404).json({ ok: false, error: "Fichier introuvable : envoi non terminé." });
      }
      if (realSize > maxBytesForFolder(folder)) {
        await r2.client.send(new DeleteObjectCommand({ Bucket: r2.bucket, Key: objectKey }));
        return res.status(413).json({ ok: false, error: "Fichier trop volumineux pour ce type de média." });
      }
      if (folder === "stories") {
        const prefixResult = await r2.client.send(new GetObjectCommand({
          Bucket: r2.bucket,
          Key: objectKey,
          Range: "bytes=0-63",
        }));
        const prefix = prefixResult.Body
          ? Buffer.from(await prefixResult.Body.transformToByteArray())
          : Buffer.alloc(0);
        const detectedType = detectStoryMediaType(prefix);
        if (!isCompatibleStoryMime(detectedType, mime)) {
          await r2.client.send(new DeleteObjectCommand({ Bucket: r2.bucket, Key: objectKey }));
          return res.status(415).json({ ok: false, error: "Le contenu du fichier ne correspond pas à un format Story pris en charge." });
        }
        if (mime.toLowerCase() === "application/octet-stream") storageMime = detectedType;
      }

      const row = {
        owner_id: user.id, provider: "cloudflare-r2", bucket: r2.bucket, folder, object_key: objectKey,
        public_url: expectedUrl, mime_type: storageMime, byte_size: realSize, original_name: fileName,
        status: "ready", updated_at: new Date().toISOString(),
      };
      const ASSET_COLUMNS = "id,owner_id,provider,bucket,folder,object_key,public_url,mime_type,byte_size,original_name,status,created_at,updated_at";
      // insert (et non upsert) : ne dépend d'aucun index unique (bucket, object_key).
      // Si finalize est rejoué et qu'une contrainte unique existe (23505), on relit la ligne.
      let { data, error } = await admin.from("media_assets").insert(row).select(ASSET_COLUMNS).single();
      if (error && error.code === "23505") {
        const existing = await admin.from("media_assets").select(ASSET_COLUMNS)
          .eq("bucket", r2.bucket).eq("object_key", objectKey).eq("owner_id", user.id).maybeSingle();
        if (existing.error || !existing.data) throw error;
        data = existing.data;
        error = null;
      }
      if (error) throw error;
      return res.status(200).json({ ok: true, asset: data });
    } catch (e) {
      console.error("[media:finalize]", e);
      return res.status(500).json({ ok: false, error: "Impossible d'enregistrer les métadonnées média", code: e?.code || null });
    }
  }

  const folder = String(body.folder || "misc");
  const size = Number(body.size);
  if (!FOLDERS.has(folder) || !Number.isSafeInteger(size) || size <= 0 || size > maxBytesForFolder(folder)) {
    return res.status(400).json({ ok: false, error: "Paramètres média invalides" });
  }

  if (isBlocked(body.contentType, body.extension)) {
    return res.status(415).json({ ok: false, error: "Les fichiers HTML et SVG ne sont pas autorisés." });
  }

  try {
    const r2 = getR2();
    if (!r2.publicBase) throw new Error("R2_PUBLIC_BASE_URL manquante");
    const ext = safeExt(body.extension);
    const key = `${folder}/${user.id}/${crypto.randomUUID()}.${ext}`;
    const command = new PutObjectCommand({
      Bucket: r2.bucket,
      Key: key,
      Metadata: { "baaro-user-id": user.id },
    });
    // Lien valable plus longtemps pour les gros fichiers (connexion lente = envoi long).
    const expiresIn = size > 50 * 1024 * 1024 ? 3600 : 900;
    const uploadUrl = await getSignedUrl(r2.client, command, { expiresIn });
    return res.status(200).json({
      ok: true,
      uploadUrl,
      path: key,
      publicUrl: `${r2.publicBase}/${key}`,
    });
  } catch (e) {
    console.error("[media]", e);
    return res.status(500).json({ ok: false, error: "Service média indisponible" });
  }
}
