import { useState, useEffect, useCallback } from "react";
import {
  Users,
  UserPlus,
  UserCheck,
  Inbox,
  Check,
  X,
  MessageSquare,
  Loader2,
} from "lucide-react";
import { COLORS } from "../theme.js";
import { useToast } from "./ToastContext.jsx";
import {
  supabase,
  getFriends,
  getFollowers,
  getFollowing,
  getPendingRequests,
  acceptFriendRequest,
  rejectFriendRequest,
  unfollowUser,
} from "../supabaseClient.js";

/**
 * FriendsTab — Systeme d'amis complet
 * Onglets : Amis | Abonnes | Abonnements | Demandes
 */
export function FriendsTab({ currentUserId, onOpenProfile, onNavigateToMessages }) {
  const { showToast } = useToast();
  const [activeTab, setActiveTab] = useState("friends");
  const [friends, setFriends] = useState([]);
  const [followers, setFollowers] = useState([]);
  const [following, setFollowing] = useState([]);
  const [pending, setPending] = useState([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(null);

  const fetchProfiles = async (ids) => {
    if (!ids || ids.length === 0) return [];
    const { data, error } = await supabase
      .from("profiles")
      .select("user_id, display_name, handle, flag, bio")
      .in("user_id", ids);

    if (error) {
      console.error("fetchProfiles error:", error);
      return [];
    }
    return data || [];
  };

  const loadData = useCallback(async () => {
    if (!currentUserId) return;
    setLoading(true);

    try {
      if (activeTab === "friends") {
        const { data: ids } = await getFriends();
        const profiles = await fetchProfiles(ids || []);
        setFriends(profiles);
      } else if (activeTab === "followers") {
        const { data: ids } = await getFollowers();
        const profiles = await fetchProfiles(ids || []);
        setFollowers(profiles);
      } else if (activeTab === "following") {
        const { data: ids } = await getFollowing();
        const profiles = await fetchProfiles(ids || []);
        setFollowing(profiles);
      } else if (activeTab === "requests") {
        const { data: requests } = await getPendingRequests();
        if (!requests || requests.length === 0) {
          setPending([]);
        } else {
          const ids = requests.map((r) => r.follower_id);
          const profiles = await fetchProfiles(ids);
          const merged = requests.map((req) => {
            const profile = profiles.find((p) => p.user_id === req.follower_id) || {};
            return {
              ...profile,
              followId: req.id,
              follower_id: req.follower_id,
            };
          });
          setPending(merged);
        }
      }
    } catch (err) {
      console.error("Erreur chargement amis:", err);
      showToast("Erreur de chargement", "error");
    } finally {
      setLoading(false);
    }
  }, [activeTab, currentUserId, showToast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleAccept = async (followId) => {
    setActionLoading(followId);
    try {
      const { error } = await acceptFriendRequest(followId);
      if (error) throw error;
      showToast("Demande acceptee !", "success");
      loadData();
    } catch (err) {
      console.error(err);
      showToast("Erreur lors de l'acceptation", "error");
    } finally {
      setActionLoading(null);
    }
  };

  const handleReject = async (followId) => {
    setActionLoading(followId);
    try {
      const { error } = await rejectFriendRequest(followId);
      if (error) throw error;
      showToast("Demande refusee", "info");
      loadData();
    } catch (err) {
      console.error(err);
      showToast("Erreur lors du refus", "error");
    } finally {
      setActionLoading(null);
    }
  };

  const handleUnfollow = async (userId) => {
    setActionLoading(userId);
    try {
      const { error } = await unfollowUser(userId);
      if (error) throw error;
      showToast("Desabonne", "info");
      loadData();
    } catch (err) {
      console.error(err);
      showToast("Erreur", "error");
    } finally {
      setActionLoading(null);
    }
  };

  const tabs = [
    { id: "friends", label: "Amis", icon: Users },
    { id: "followers", label: "Abonnes", icon: Inbox },
    { id: "following", label: "Abonnements", icon: UserCheck },
    { id: "requests", label: "Demandes", icon: UserPlus },
  ];

  const renderUserCard = (user, type) => {
    if (!user) return null;

    const name = user.display_name || "Membre BAARO";
    const handle = user.handle || "@membre";
    const flag = user.flag || "🌍";
    const userId = user.user_id || user.follower_id;
    const isActionLoading = actionLoading === (user.followId || userId);

    return (
      <div
        key={user.followId || userId}
        className="flex items-center justify-between gap-3 p-3 rounded-2xl border transition hover:border-opacity-80"
        style={{
          background: COLORS.surface,
          borderColor: COLORS.border,
        }}
      >
        <div
          className="flex items-center gap-3 flex-1 min-w-0 cursor-pointer"
          onClick={() => onOpenProfile?.(userId)}
        >
          <div
            className="w-11 h-11 rounded-full flex items-center justify-center text-sm font-bold shrink-0"
            style={{ background: COLORS.bg, color: COLORS.gold }}
          >
            {name[0]?.toUpperCase() || "?"}
          </div>
          <div className="min-w-0">
            <div className="font-semibold text-sm truncate" style={{ color: COLORS.ivory }}>
              {name} {flag}
            </div>
            <div className="text-xs truncate" style={{ color: COLORS.muted }}>
              {handle}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {type === "requests" && (
            <>
              <button
                onClick={() => handleAccept(user.followId)}
                disabled={isActionLoading}
                className="p-2 rounded-full transition hover:opacity-80 disabled:opacity-50"
                style={{ background: "rgba(34,197,94,0.2)", color: "#4ade80" }}
                title="Accepter"
              >
                {isActionLoading ? (
                  <Loader2 size={16} className="animate-spin" />
                ) : (
                  <Check size={16} />
                )}
              </button>
              <button
                onClick={() => handleReject(user.followId)}
                disabled={isActionLoading}
                className="p-2 rounded-full transition hover:opacity-80 disabled:opacity-50"
                style={{ background: "rgba(239,68,68,0.2)", color: "#f87171" }}
                title="Refuser"
              >
                <X size={16} />
              </button>
            </>
          )}

          {type === "friends" && (
            <button
              onClick={() => onNavigateToMessages?.()}
              className="p-2 rounded-full transition hover:opacity-80"
              style={{ background: COLORS.bg, color: COLORS.teal }}
              title="Message"
            >
              <MessageSquare size={16} />
            </button>
          )}

          {(type === "following" || type === "followers") && (
            <button
              onClick={() => handleUnfollow(userId)}
              disabled={isActionLoading}
              className="px-3 py-1.5 rounded-full text-xs font-medium transition disabled:opacity-50"
              style={{
                background: COLORS.bg,
                color: COLORS.muted,
                border: `1px solid ${COLORS.border}`,
              }}
            >
              {isActionLoading ? "..." : type === "following" ? "Se desabonner" : "Retirer"}
            </button>
          )}
        </div>
      </div>
    );
  };

  const getList = () => {
    switch (activeTab) {
      case "friends":
        return { list: friends, type: "friends", empty: "Aucun ami pour le moment." };
      case "followers":
        return { list: followers, type: "followers", empty: "Aucun abonne." };
      case "following":
        return { list: following, type: "following", empty: "Vous ne suivez personne." };
      case "requests":
        return { list: pending, type: "requests", empty: "Aucune demande en attente." };
      default:
        return { list: [], type: "", empty: "" };
    }
  };

  const { list, type, empty } = getList();

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold" style={{ color: COLORS.ivory }}>
        Communaute
      </h2>

      <div className="flex gap-2 overflow-x-auto pb-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-full text-xs font-semibold whitespace-nowrap transition"
              style={{
                background: isActive ? COLORS.gold : COLORS.surface,
                color: isActive ? COLORS.bg : COLORS.muted,
                border: isActive ? "none" : `1px solid ${COLORS.border}`,
              }}
            >
              <Icon size={14} />
              {tab.label}
              {tab.id === "requests" && pending.length > 0 && (
                <span
                  className="ml-1 px-1.5 py-0.5 rounded-full text-[10px] font-bold"
                  style={{ background: "#ef4444", color: "white" }}
                >
                  {pending.length}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-16 gap-3">
          <Loader2 size={28} className="animate-spin" style={{ color: COLORS.gold }} />
          <p className="text-sm" style={{ color: COLORS.muted }}>
            Chargement...
          </p>
        </div>
      ) : list.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 gap-2">
          <p className="text-4xl">👀</p>
          <p className="text-sm" style={{ color: COLORS.muted }}>
            {empty}
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {list.map((item) => renderUserCard(item, type))}
        </div>
      )}
    </div>
  );
}

export default FriendsTab;
