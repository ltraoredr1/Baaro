BAARO - Systeme d'amis complet
==============================

Date : 09 aout 2026

FICHIERS
--------
1. FriendsTab.jsx      -> src/components/
2. ProfileModal.jsx    -> src/components/
3. supabaseClient.js   -> src/  (deja corrige precedemment, a garder)

MODIFICATION DANS App.jsx
-------------------------
Remplace la ligne :

  {activeTab === "friends" && <FriendsTab currentUserId={userId} />}

Par :

  {activeTab === "friends" && (
    <FriendsTab
      currentUserId={userId}
      onOpenProfile={(id) => setInspectingProfileId(id)}
      onNavigateToMessages={() => setActiveTab("messages")}
    />
  )}

FONCTIONNALITES
---------------
- Onglets : Amis / Abonnes / Abonnements / Demandes
- Demande d'ami depuis le profil (bouton "Demander en ami")
- Accepter / Refuser une demande
- Liste d'amis reelle (profils Supabase)
- Badge rouge sur l'onglet Demandes si demandes en attente
