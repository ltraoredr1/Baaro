# BAARO

Réseau social mondial avec portefeuille de points, crypto interne (**BARO Coin**), messagerie, débats live, abonnements et assistant IA.

Les données (points, transactions, avoirs crypto, profils, follows) sont stockées dans **PostgreSQL via Supabase**.

---

## Fonctionnalités

| Module | Description |
|--------|-------------|
| **Mode invité** | Regarder les vidéos, liker et partager **sans compte** |
| **Compte** | Requis pour messagerie, débats, points, portefeuille, s’abonner, publier |
| **Fil** | Publications, likes, commentaires, médias |
| **Vidéos** | Feed type short-form, stories, caméra avec/sans son, s’abonner depuis une vidéo |
| **Communauté** | Abonnés, abonnements, demandes d’amis |
| **Messagerie** | Conversations ; chiffrement E2E si clé publique disponible |
| **Débats / Lives** | Rooms + flux via Daily.co |
| **Portefeuille** | Points réseau, missions, parrainage |
| **BARO Coin** | Avoirs crypto internes, conversion points → BARO |
| **Assistant IA** | Relais API Claude (clé secrète côté serveur) |
| **PWA** | Installable sur mobile / bureau |
| **Capacitor** | Coque Android / iOS + plugin Nearby (hors-ligne) |

---

## Stack

- **Frontend** : React 18, Vite, Tailwind CSS  
- **Backend data** : Supabase (Auth, Postgres, Realtime, Storage)  
- **API** : fonctions serverless Vercel (`/api/*`)  
- **Lives** : Daily.co  
- **Mobile** : Capacitor 6  

---

## Démarrage rapide

### 1. Supabase

1. Crée un projet sur [supabase.com](https://supabase.com)  
2. **SQL Editor** — exécute dans l’ordre :
   - `supabase-schema.sql`
   - `supabase-security-fix.sql`
   - `supabase-add-*.sql` (debates, media, social, messages, multihost…)
   - Correctifs follows (colonnes `following_id`, `status`, `is_friend` + triggers)
3. **Authentication → Providers** : active **Anonymous** + **Email**  
4. **Storage** : bucket public `media` (et `videos` / `stories` si utilisés)  
5. Note **Project URL** et clé **anon public**

### 2. Variables d’environnement

Fichier `.env.local` (et mêmes clés sur Vercel) :

```env
VITE_SUPABASE_URL=https://xxxx.supabase.co
VITE_SUPABASE_ANON_KEY=eyJ...
SUPABASE_SERVICE_ROLE_KEY=eyJ...          # jamais préfixée VITE_
ANTHROPIC_API_KEY=sk-ant-...
VITE_TURNSTILE_SITE_KEY=...               # optionnel CAPTCHA
DAILY_API_KEY=...                         # lives
DAILY_DOMAIN=ton-sous-domaine
VITE_API_BASE_URL=                        # vide en web ; URL Vercel en app native
```

### 3. Installation & local

```bash
npm install
npm run dev
```

Ouvre `http://localhost:5173`.

### 4. Déploiement Vercel

1. Importe le dépôt GitHub  
2. Ajoute les variables d’environnement  
3. Deploy (Vite détecté automatiquement)

---

## Structure du projet

```
src/
  App.jsx                 # Shell app + mode invité + auth
  components/             # UI (Feed, Videos, Messages, Wallet…)
  hooks/                  # useSocial, useMessaging, useProfile…
  lib/                    # crypto E2E, walletApi, localStore, webrtc
  contexts/               # AppContext (optionnel / legacy)
  supabaseClient.js
api/
  wallet.js               # gains / rachats / conversion (service role)
  chat.js                 # proxy Claude
  create-room.js          # Daily.co
  register-device.js      # anti multi-comptes
supabase-*.sql            # schémas et correctifs
```

---

## Règles métier importantes

### Follows

Table `follows` :

- `follower_id`, `following_id` (pas `followed_id`)
- `status` (`accepted` | `pending` | …)
- `is_friend`

Triggers : `prevent_self_follow`, `notify_on_follow` (utilisent `following_id`).

### Mode invité

Autorisé : fil, vidéos, likes locaux, partage.  
Compte obligatoire : chat, débats, wallet, crypto, communauté, points, publication.

### Sécurité portefeuille

Écritures `wallets` / `transactions` / `crypto_holdings` **uniquement** via `/api/wallet` + `SUPABASE_SERVICE_ROLE_KEY`. Le client est en lecture seule.

### Stockage local (navigateur)

Géré par `src/lib/localStore.js` :

- thème, langue, device id, likes invité  
- clés E2E dans IndexedDB (`baaro-crypto`)

---

## Scripts npm

| Commande | Rôle |
|----------|------|
| `npm run dev` | Dev local |
| `npm run build` | Build production |
| `npm run cap:sync` | Build + sync Capacitor |
| `npm run cap:android` | Ouvrir Android Studio |

---

## Dépannage

| Symptôme | Action |
|----------|--------|
| `followed_id` / record "new" has no field | Vérifier colonnes + fonctions SQL triggers |
| Nom « Nouveau membre » | Profil créé avec défauts ; se reconnecter ou UPDATE `profiles` |
| Crash Portefeuille / BARO | Utiliser les composants sans `useApp` obligatoires (props depuis App) |
| Ancien comportement sur téléphone | Vider le cache du site (Redmi / Chrome) |
| Likes invité perdus | Normal après « Effacer cache invité » dans Paramètres |

---

## Licence

Projet privé — usage selon les conditions du propriétaire du dépôt.

---

**BAARO** — Réseau social mondial, points & BARO Coin.
