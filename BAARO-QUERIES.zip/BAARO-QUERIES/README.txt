BAARO — Gestion centralisée des requêtes Supabase
=================================================

Date : 09 aout 2026

FICHIERS A PLACER
-----------------
1. queries.js          -> src/lib/queries.js
2. useSupabaseQuery.js -> src/hooks/useSupabaseQuery.js

(Assure-toi que src/lib/dbErrors.js existe deja)

CE QUE CA APPORTE
-----------------
1. Couche queries.js
   - Toutes les requetes (profils, follows, amis, wallet, posts)
   - Gestion d'erreur uniforme via handleDbError
   - getProfileWithStats() : charge profil + compteurs + etat follow en parallele

2. Hooks React
   - useSupabaseQuery(queryFn, deps)  -> data / loading / error / reload
   - useSupabaseMutation(mutationFn)  -> mutate / loading / error

EXEMPLE D'UTILISATION
---------------------
import { useSupabaseQuery, useSupabaseMutation } from "../hooks/useSupabaseQuery";
import { getFriends, followUser } from "../lib/queries";

// Lecture
const { data: friendIds, loading, error, reload } = useSupabaseQuery(
  () => getFriends(userId),
  [userId]
);

// Ecriture
const { mutate: doFollow, loading: followLoading } = useSupabaseMutation(
  (targetId) => followUser(userId, targetId, { showToast })
);

await doFollow(targetUserId);
reload();

AVANTAGES
---------
- Plus de requetes copiees-collees dans chaque composant
- Loading / error geres partout de la meme facon
- Messages d'erreur en francais (via dbErrors.js)
- Facile a tester et a faire evoluer
