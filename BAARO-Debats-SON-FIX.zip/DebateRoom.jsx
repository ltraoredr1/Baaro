import { useState, useEffect, useRef, useCallback } from "react";
import {
  ArrowLeft,
  Send,
  Users,
  Hash,
  MessageSquare,
  Mic,
  MicOff,
  Video,
  VideoOff,
  PhoneOff,
  Volume2,
  Star,
  Loader2,
  Sparkles,
  Pause,
  Play,
  Copy,
  Check,
  Hand,
} from "lucide-react";
import { COLORS } from "../theme.js";
import { supabase } from "../supabaseClient.js";
import { API_BASE } from "../config.js";
import {
  joinLiveByCode,
  leaveLive,
  enableMic,
  enableCamera,
  subscribeToEvents,
  getParticipants,
  upgradeLocalRole,
  requestCoHost,
  respondCoHostRequest,
  demoteToViewer,
  findParticipantSessionId,
  attachRemoteAudio,
  detachRemoteAudio,
  detachAllRemoteAudio,
  unlockAllRemoteAudio,
  pauseRoom,
  resumeRoom,
} from "../lib/webrtc.js";

function getVideoTrack(participant) {
  if (!participant?.tracks?.video) return null;
  const v = participant.tracks.video;
  return v.persistentTrack || v.track || null;
}

/** Tuile vidéo / avatar d'un participant */
function ParticipantTile({
  participant,
  isVideoMode,
  isLocal,
  videoTrack,
  isSpeaking = false,
  compact = false,
}) {
  const videoRef = useRef(null);
  const track = videoTrack || getVideoTrack(participant);
  const hasVideo =
    isVideoMode && !!track && track.readyState !== "ended";

  useEffect(() => {
    const videoEl = videoRef.current;
    if (!videoEl) return;

    if (hasVideo && track) {
      const stream = new MediaStream([track]);
      const current = videoEl.srcObject;
      const currentTrack = current?.getVideoTracks?.()?.[0];
      if (currentTrack !== track) {
        videoEl.srcObject = stream;
      }
      const p = videoEl.play();
      if (p && typeof p.catch === "function") p.catch(() => {});
    } else {
      videoEl.srcObject = null;
    }
  }, [hasVideo, track]);

  const name = isLocal ? "Vous" : participant?.user_name || "Participant";

  return (
    <div
      className="relative rounded-2xl overflow-hidden border flex items-center justify-center transition-all"
      style={{
        background: COLORS.surface2,
        borderColor: isSpeaking ? COLORS.gold : COLORS.border,
        boxShadow: isSpeaking ? `0 0 0 2px ${COLORS.gold}55` : "none",
        minHeight: compact ? 80 : isLocal ? 160 : 140,
        aspectRatio: compact ? "4/3" : "16/10",
      }}
    >
      {hasVideo ? (
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted={!!isLocal}
          className="absolute inset-0 w-full h-full object-cover"
          style={{ transform: isLocal ? "scaleX(-1)" : undefined }}
        />
      ) : (
        <div className="flex flex-col items-center gap-1 z-10">
          <div
            className={`rounded-full flex items-center justify-center font-bold border ${
              compact ? "w-10 h-10 text-sm" : "w-14 h-14 text-xl"
            }`}
            style={{
              background: COLORS.surface,
              borderColor: isSpeaking ? COLORS.gold : COLORS.borderGold,
              color: COLORS.gold,
            }}
          >
            {(name || "?")[0].toUpperCase()}
          </div>
          {!isVideoMode && !compact && (
            <Volume2 size={14} style={{ color: COLORS.muted }} />
          )}
        </div>
      )}

      <div
        className="absolute bottom-0 left-0 right-0 px-2 py-1.5 flex items-center gap-1.5 text-[11px] font-bold"
        style={{
          background: "linear-gradient(transparent, rgba(0,0,0,0.75))",
          color: "#fff",
        }}
      >
        <span className="truncate">{name}</span>
        {isLocal && (
          <span className="text-[9px] opacity-70 shrink-0">MOI</span>
        )}
        {isSpeaking && (
          <span className="ml-auto text-[9px] shrink-0" style={{ color: COLORS.gold }}>
            ● parle
          </span>
        )}
      </div>
    </div>
  );
}

export function DebateRoom({
  inviteCode,
  currentUserId: currentUserIdProp,
  onBack,
}) {
  const [resolvedUserId, setResolvedUserId] = useState(
    currentUserIdProp || null
  );
  const currentUserId = resolvedUserId || currentUserIdProp;

  useEffect(() => {
    if (currentUserIdProp) {
      setResolvedUserId(currentUserIdProp);
      return;
    }
    (async () => {
      const { data } = await supabase.auth.getUser();
      if (data?.user?.id) setResolvedUserId(data.user.id);
    })();
  }, [currentUserIdProp]);

  const [room, setRoom] = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [isVoiceMode, setIsVoiceMode] = useState(false);
  const [micOn, setMicOn] = useState(false);
  const [camOn, setCamOn] = useState(false);
  const [voiceConnecting, setVoiceConnecting] = useState(false);
  const [participants, setParticipants] = useState({});
  const [videoTracks, setVideoTracks] = useState({});
  const [voiceError, setVoiceError] = useState(null);
  const [dailyRoomName, setDailyRoomName] = useState(null);
  const [myRole, setMyRole] = useState("viewer");
  const [participantRoles, setParticipantRoles] = useState({});
  const [roleActionLoading, setRoleActionLoading] = useState(null);
  const [roleActionError, setRoleActionError] = useState(null);
  const [pendingRequest, setPendingRequest] = useState(null);
  const [aiLoading, setAiLoading] = useState(false);
  const [roomStatus, setRoomStatus] = useState("active");
  const [pauseLoading, setPauseLoading] = useState(false);
  const [activeSpeakerId, setActiveSpeakerId] = useState(null);
  const [speakRequestSent, setSpeakRequestSent] = useState(false);
  const [speakRequestLoading, setSpeakRequestLoading] = useState(false);
  const [codeCopied, setCodeCopied] = useState(false);
  const [needAudioUnlock, setNeedAudioUnlock] = useState(false);

  const isRoomOwner = !!(currentUserId && room?.host_id === currentUserId);
  const dbRole = currentUserId ? participantRoles[currentUserId] : null;
  const canBroadcast =
    isRoomOwner ||
    myRole === "host" ||
    myRole === "co_host" ||
    dbRole === "host" ||
    dbRole === "co_host";

  const messagesEndRef = useRef(null);
  const profilesCache = useRef({});
  const voiceStarted = useRef(false);

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, scrollToBottom]);

  useEffect(() => {
    let wakeLock = null;
    const requestWakeLock = async () => {
      try {
        if (document.visibilityState === "visible" && "wakeLock" in navigator) {
          wakeLock = await navigator.wakeLock.request("screen");
        }
      } catch (_) {}
    };
    const onVisibility = () => {
      if (document.visibilityState === "visible") requestWakeLock();
    };
    document.addEventListener("visibilitychange", onVisibility);
    requestWakeLock();
    return () => {
      document.removeEventListener("visibilitychange", onVisibility);
      try {
        wakeLock?.release?.();
      } catch (_) {}
    };
  }, []);

  useEffect(() => {
    let isMounted = true;
    let messagesChannel = null;
    let participantsChannel = null;
    let roleReqChannel = null;
    let roomChannel = null;

    const loadDebate = async () => {
      try {
        const { data: roomData, error: roomError } = await supabase
          .from("debate_rooms")
          .select(
            "id, title, topic, mode, invite_code, status, created_at, host_id, daily_room_name"
          )
          .ilike("invite_code", inviteCode)
          .in("status", ["active", "paused"])
          .maybeSingle();

        if (roomError || !roomData) {
          if (isMounted) {
            setError("Salle introuvable");
            setLoading(false);
          }
          return;
        }

        if (isMounted) {
          setRoom(roomData);
          setRoomStatus(roomData.status || "active");
          setIsVoiceMode(
            roomData.mode === "audio" ||
              roomData.mode === "video" ||
              !!roomData.daily_room_name
          );
          if (roomData.daily_room_name) {
            setDailyRoomName(roomData.daily_room_name);
          }
        }

        const { data: msgsData } = await supabase
          .from("debate_messages")
          .select("id, text, created_at, sender_id, sender_type")
          .eq("room_id", roomData.id)
          .order("created_at", { ascending: true })
          .limit(200);

        if (msgsData && isMounted) {
          const uniqueUserIds = [
            ...new Set(msgsData.map((m) => m.sender_id).filter(Boolean)),
          ];
          let profilesMap = { ...profilesCache.current };

          if (uniqueUserIds.length > 0) {
            const missing = uniqueUserIds.filter((id) => !profilesMap[id]);
            if (missing.length > 0) {
              const { data: profiles } = await supabase
                .from("profiles")
                .select("user_id, display_name, avatar_url, flag")
                .in("user_id", missing);
              (profiles || []).forEach((p) => {
                profilesMap[p.user_id] = p;
              });
              profilesCache.current = profilesMap;
            }
          }

          setMessages(
            msgsData.map((m) => ({
              ...m,
              profile: profilesMap[m.sender_id] || {
                display_name: "Membre",
                flag: "🌍",
              },
            }))
          );
        }

        const { data: rolesData } = await supabase
          .from("debate_participants")
          .select("user_id, role")
          .eq("room_id", roomData.id)
          .is("left_at", null);

        if (isMounted) {
          const rolesMap = {};
          (rolesData || []).forEach((p) => {
            rolesMap[p.user_id] = p.role;
          });
          setParticipantRoles(rolesMap);
          const myDbRole = currentUserId ? rolesMap[currentUserId] : null;
          if (myDbRole === "host" || myDbRole === "co_host") {
            setMyRole(myDbRole);
          } else if (roomData.host_id === currentUserId) {
            setMyRole("host");
          }
        }

        if (currentUserId) {
          const { data: myReq } = await supabase
            .from("debate_role_requests")
            .select("*")
            .eq("room_id", roomData.id)
            .eq("to_user_id", currentUserId)
            .eq("status", "pending")
            .maybeSingle();
          if (myReq && isMounted) setPendingRequest(myReq);
        }

        try {
          const msgChName = `room_msgs_${roomData.id}`;
          try {
            supabase.removeChannel(supabase.channel(msgChName));
          } catch (_) {}
          messagesChannel = supabase
            .channel(msgChName)
            .on(
              "postgres_changes",
              {
                event: "INSERT",
                schema: "public",
                table: "debate_messages",
                filter: `room_id=eq.${roomData.id}`,
              },
              async (payload) => {
                let profile = profilesCache.current[payload.new.sender_id];
                if (!profile && payload.new.sender_id) {
                  const { data } = await supabase
                    .from("profiles")
                    .select("display_name, avatar_url, flag")
                    .eq("user_id", payload.new.sender_id)
                    .maybeSingle();
                  profile = data || { display_name: "Membre", flag: "🌍" };
                  profilesCache.current[payload.new.sender_id] = profile;
                }
                if (isMounted) {
                  setMessages((prev) => [
                    ...prev,
                    {
                      ...payload.new,
                      profile: profile || {
                        display_name: "Membre",
                        flag: "🌍",
                      },
                    },
                  ]);
                }
              }
            );
          messagesChannel.subscribe();
        } catch (e) {
          console.warn("Realtime messages:", e);
        }

        try {
          const partChName = `room_parts_${roomData.id}`;
          try {
            supabase.removeChannel(supabase.channel(partChName));
          } catch (_) {}
          participantsChannel = supabase
            .channel(partChName)
            .on(
              "postgres_changes",
              {
                event: "*",
                schema: "public",
                table: "debate_participants",
                filter: `room_id=eq.${roomData.id}`,
              },
              (payload) => {
                const row =
                  payload.new && Object.keys(payload.new).length
                    ? payload.new
                    : payload.old;
                if (!row?.user_id) return;

                if (payload.eventType === "DELETE") {
                  setParticipantRoles((prev) => {
                    const copy = { ...prev };
                    delete copy[row.user_id];
                    return copy;
                  });
                  return;
                }

                setParticipantRoles((prev) => ({
                  ...prev,
                  [row.user_id]: row.role,
                }));

                if (
                  row.user_id === currentUserId &&
                  payload.eventType === "UPDATE" &&
                  row.role !== "host"
                ) {
                  upgradeLocalRole(row.role);
                  setMyRole(row.role);
                  const shouldBroadcast = row.role === "co_host";
                  enableMic(shouldBroadcast);
                  setMicOn(shouldBroadcast);
                  if (roomData.mode === "video" || roomData.daily_room_name) {
                    enableCamera(shouldBroadcast);
                    setCamOn(shouldBroadcast);
                  }
                  if (shouldBroadcast) setSpeakRequestSent(false);
                }
              }
            );
          participantsChannel.subscribe();
        } catch (e) {
          console.warn("Realtime participants:", e);
        }

        try {
          const roleChName = `role_req_${roomData.id}`;
          try {
            supabase.removeChannel(supabase.channel(roleChName));
          } catch (_) {}
          roleReqChannel = supabase
            .channel(roleChName)
            .on(
              "postgres_changes",
              {
                event: "*",
                schema: "public",
                table: "debate_role_requests",
                filter: `room_id=eq.${roomData.id}`,
              },
              (payload) => {
                const row = payload.new;
                if (!row) return;
                if (
                  row.to_user_id === currentUserId &&
                  row.status === "pending"
                ) {
                  setPendingRequest(row);
                }
                if (
                  row.to_user_id === currentUserId &&
                  row.status !== "pending"
                ) {
                  setPendingRequest(null);
                }
              }
            );
          roleReqChannel.subscribe();
        } catch (e) {
          console.warn("Realtime role_requests:", e);
        }

        try {
          const metaChName = `room_meta_${roomData.id}`;
          try {
            supabase.removeChannel(supabase.channel(metaChName));
          } catch (_) {}
          roomChannel = supabase
            .channel(metaChName)
            .on(
              "postgres_changes",
              {
                event: "UPDATE",
                schema: "public",
                table: "debate_rooms",
                filter: `id=eq.${roomData.id}`,
              },
              (payload) => {
                const st = payload.new?.status;
                if (st) setRoomStatus(st);
              }
            );
          roomChannel.subscribe();
        } catch (e) {
          console.warn("Realtime room meta:", e);
        }
      } catch (err) {
        if (isMounted) setError(err.message);
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    loadDebate();

    return () => {
      isMounted = false;
      if (messagesChannel) supabase.removeChannel(messagesChannel);
      if (participantsChannel) supabase.removeChannel(participantsChannel);
      if (roleReqChannel) supabase.removeChannel(roleReqChannel);
      if (roomChannel) supabase.removeChannel(roomChannel);
    };
  }, [inviteCode, currentUserId]);

  useEffect(() => {
    if (!room || !isVoiceMode || voiceStarted.current || !inviteCode) return;

    let pollTimer = null;

    const startVoice = async () => {
      setVoiceConnecting(true);
      setVoiceError(null);
      voiceStarted.current = true;

      try {
        const userName =
          profilesCache.current[currentUserId]?.display_name || "Participant";

        const audioOnly =
          room.mode === "audio" ||
          (room.mode !== "video" && !room.daily_room_name);
        const { role: apiRole } = await joinLiveByCode({
          inviteCode: room.invite_code,
          userName,
          audioOnly,
        });

        const isHostUser = !!(
          currentUserId && room.host_id === currentUserId
        );
        const dbRoleNow = currentUserId
          ? participantRoles[currentUserId]
          : null;
        let role = apiRole || "viewer";
        if (isHostUser) role = "host";
        else if (dbRoleNow === "host" || dbRoleNow === "co_host")
          role = dbRoleNow;
        else if (apiRole === "host" || apiRole === "co_host") role = apiRole;

        setMyRole(role);
        upgradeLocalRole(role);

        const shouldStartMedia = role === "host" || role === "co_host";

        await enableMic(shouldStartMedia);
        setMicOn(shouldStartMedia);

        if (room.mode === "video") {
          await enableCamera(shouldStartMedia);
          setCamOn(shouldStartMedia);
        }

        const updateParticipants = () => {
          setParticipants({ ...getParticipants() });
        };
        updateParticipants();

        subscribeToEvents({
          onParticipantJoined: updateParticipants,
          onParticipantLeft: (ev) => {
            updateParticipants();
            const sid = ev?.participant?.session_id;
            if (sid) {
              setVideoTracks((prev) => {
                const n = { ...prev };
                delete n[sid];
                return n;
              });
              detachRemoteAudio(sid);
            }
          },
          onParticipantUpdated: updateParticipants,
          onTrackStarted: (ev) => {
            updateParticipants();
            const { track, participant } = ev || {};
            if (!track || !participant?.session_id) return;

            if (track.kind === "video") {
              setVideoTracks((prev) => ({
                ...prev,
                [participant.session_id]: track,
              }));
            }

            if (track.kind === "audio" && !participant.local) {
              attachRemoteAudio(participant.session_id, track);
              setNeedAudioUnlock(true);
            }
          },
          onTrackStopped: (ev) => {
            updateParticipants();
            const { track, participant } = ev || {};
            if (!track || !participant?.session_id) return;

            if (track.kind === "video") {
              setVideoTracks((prev) => {
                const n = { ...prev };
                delete n[participant.session_id];
                return n;
              });
            }
            if (track.kind === "audio" && !participant.local) {
              detachRemoteAudio(participant.session_id);
            }
          },
          onActiveSpeakerChange: (ev) => {
            setActiveSpeakerId(ev?.activeSpeaker?.peerId || null);
          },
          onError: (e) => {
            console.error("Daily error:", e);
            const msg =
              e?.errorMsg ||
              e?.error?.msg ||
              JSON.stringify(e, Object.getOwnPropertyNames(e)) ||
              String(e);
            if (/permission|NotAllowed|denied|blocked/i.test(msg)) {
              setVoiceError(
                "Autorisez le micro et la caméra dans les paramètres du navigateur / de l’application, puis réessayez."
              );
            } else {
              setVoiceError(msg);
            }
          },
        });

        const existing = getParticipants();
        const initialVideo = {};
        Object.values(existing).forEach((p) => {
          const t = getVideoTrack(p);
          if (t && p.session_id) initialVideo[p.session_id] = t;

          const audioTrack =
            p?.tracks?.audio?.persistentTrack || p?.tracks?.audio?.track;
          if (audioTrack && !p.local && p.session_id) {
            attachRemoteAudio(p.session_id, audioTrack);
            setNeedAudioUnlock(true);
          }
        });
        if (Object.keys(initialVideo).length) {
          setVideoTracks((prev) => ({ ...prev, ...initialVideo }));
        }

        pollTimer = setInterval(updateParticipants, 2000);
      } catch (err) {
        console.error("Erreur vocal:", err);
        setVoiceError(
          JSON.stringify(err, Object.getOwnPropertyNames(err)) || String(err)
        );
        voiceStarted.current = false;
      } finally {
        setVoiceConnecting(false);
      }
    };

    startVoice();

    return () => {
      if (pollTimer) clearInterval(pollTimer);
    };
  }, [room, isVoiceMode, inviteCode, currentUserId]);

  useEffect(() => {
    return () => {
      detachAllRemoteAudio();
      leaveLive({ roomName: dailyRoomName, isHost: isRoomOwner }).catch(
        () => {}
      );
    };
  }, [dailyRoomName, isRoomOwner]);

  const toggleMic = async () => {
    if (!canBroadcast || roomStatus === "paused") return;
    const next = !micOn;
    try {
      await enableMic(next);
      setMicOn(next);
      setTimeout(() => setParticipants({ ...getParticipants() }), 250);
    } catch (e) {
      console.warn("toggleMic", e);
      setVoiceError("Impossible d’activer/désactiver le micro");
    }
  };

  const toggleCam = async () => {
    if (!canBroadcast || roomStatus === "paused" || room?.mode !== "video")
      return;
    const next = !camOn;
    try {
      await enableCamera(next);
      setCamOn(next);
      setTimeout(() => {
        setParticipants({ ...getParticipants() });
        const parts = getParticipants();
        const local = Object.values(parts).find((p) => p.local);
        if (local) {
          const t = getVideoTrack(local);
          if (t) {
            setVideoTracks((prev) => ({
              ...prev,
              [local.session_id]: t,
            }));
          }
        }
      }, 350);
    } catch (e) {
      console.warn("toggleCam", e);
      setVoiceError("Impossible d’activer/désactiver la caméra");
    }
  };

  const handleCopyCode = async () => {
    if (!room?.invite_code) return;
    try {
      await navigator.clipboard.writeText(room.invite_code);
      setCodeCopied(true);
      setTimeout(() => setCodeCopied(false), 2000);
    } catch (_) {
      try {
        const ta = document.createElement("textarea");
        ta.value = room.invite_code;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand("copy");
        ta.remove();
        setCodeCopied(true);
        setTimeout(() => setCodeCopied(false), 2000);
      } catch (e) {
        console.warn("copy failed", e);
      }
    }
  };

  const handleUnlockAudio = () => {
    unlockAllRemoteAudio();
    setNeedAudioUnlock(false);
  };

  const handleRequestToSpeak = async () => {
    if (!room || !currentUserId || speakRequestSent || speakRequestLoading)
      return;
    setSpeakRequestLoading(true);
    setRoleActionError(null);
    try {
      const displayName =
        profilesCache.current[currentUserId]?.display_name || "Un spectateur";
      const { error } = await supabase.from("debate_messages").insert({
        room_id: room.id,
        sender_id: currentUserId,
        sender_type: "user",
        text: `🙋 ${displayName} demande à parler`,
      });
      if (error) throw error;
      setSpeakRequestSent(true);
    } catch (err) {
      setRoleActionError(
        err.message || "Impossible d’envoyer la demande"
      );
    } finally {
      setSpeakRequestLoading(false);
    }
  };

  const handleLeaveVoice = async () => {
    await leaveLive({ roomName: dailyRoomName, isHost: isRoomOwner });
    voiceStarted.current = false;
    setMicOn(false);
    setCamOn(false);
    setMyRole("viewer");
    setParticipants({});
    setVideoTracks({});
    setActiveSpeakerId(null);
    setSpeakRequestSent(false);
    onBack();
  };

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim() || !room || !currentUserId) return;

    const text = newMessage.trim();
    setNewMessage("");

    try {
      const { error } = await supabase.from("debate_messages").insert({
        room_id: room.id,
        sender_id: currentUserId,
        sender_type: "user",
        text,
      });
      if (error) throw error;
    } catch (err) {
      console.error("Erreur envoi:", err);
      setNewMessage(text);
    }
  };

  const handleRespondRequest = async (accept) => {
    if (!pendingRequest || !room) return;
    setRoleActionLoading("respond");
    setRoleActionError(null);
    try {
      const sessionId = findParticipantSessionId(currentUserId);
      await respondCoHostRequest({
        requestId: pendingRequest.id,
        accept,
        targetSessionId: sessionId,
        dailyRoomName: room.daily_room_name || dailyRoomName,
      });
      setPendingRequest(null);
    } catch (err) {
      setRoleActionError(err.message || "Erreur");
    } finally {
      setRoleActionLoading(null);
    }
  };

  const handlePauseToggle = async () => {
    if (!room || !isRoomOwner || pauseLoading) return;
    setPauseLoading(true);
    setRoleActionError(null);
    try {
      if (roomStatus === "paused") {
        const data = await resumeRoom(room.id);
        setRoomStatus(data.status || "active");
      } else {
        const data = await pauseRoom(room.id);
        setRoomStatus(data.status || "paused");
        enableMic(false);
        setMicOn(false);
        if (room.mode === "video") {
          enableCamera(false);
          setCamOn(false);
        }
      }
    } catch (err) {
      setRoleActionError(err.message || "Erreur pause/reprise");
    } finally {
      setPauseLoading(false);
    }
  };

  const handleAskAI = async () => {
    if (!room || !newMessage.trim() || aiLoading || !currentUserId) return;
    const q = newMessage.trim();
    setNewMessage("");
    setAiLoading(true);
    setRoleActionError(null);
    try {
      await supabase.from("debate_messages").insert({
        room_id: room.id,
        sender_id: currentUserId,
        sender_type: "user",
        text: "🤖 " + q,
      });
    } catch (e) {
      console.error(e);
    }
    try {
      const { data: sess } = await supabase.auth.getSession();
      const token = sess?.session?.access_token;
      const res = await fetch((API_BASE || "") + "/api/debate-ai", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: "Bearer " + token } : {}),
        },
        body: JSON.stringify({ roomId: room.id, question: q }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Erreur IA");
    } catch (err) {
      console.error(err);
      setRoleActionError(err.message || "Erreur IA");
    } finally {
      setAiLoading(false);
    }
  };

  const handleToggleCoHost = async (targetUserId, currentRole) => {
    if (!room || roleActionLoading) return;
    setRoleActionLoading(targetUserId);
    setRoleActionError(null);

    try {
      const dailyName = room.daily_room_name || dailyRoomName;
      if (currentRole === "co_host") {
        await demoteToViewer(room.id, targetUserId, dailyName);
      } else {
        await requestCoHost(room.id, targetUserId);
      }
    } catch (err) {
      setRoleActionError(err.message || "Erreur lors du changement de rôle");
    } finally {
      setRoleActionLoading(null);
    }
  };

  if (error) {
    return (
      <div
        className="flex flex-col items-center justify-center h-full p-6"
        style={{ background: COLORS.surface }}
      >
        <p className="text-red-400 font-bold text-lg mb-2">⚠️ {error}</p>
        <button
          onClick={onBack}
          className="px-6 py-3 rounded-xl font-bold"
          style={{ background: COLORS.gold, color: "#000" }}
        >
          Retour
        </button>
      </div>
    );
  }

  if (loading) {
    return (
      <div
        className="flex flex-col items-center justify-center h-full"
        style={{ background: COLORS.surface }}
      >
        <div className="animate-spin w-10 h-10 border-4 border-blue-500 border-t-transparent rounded-full mb-4" />
        <p style={{ color: COLORS.ivory }}>Chargement de la salle...</p>
      </div>
    );
  }

  const participantList = Object.values(participants);
  const localParticipant = participantList.find((p) => p.local);
  const remoteParticipants = participantList.filter((p) => !p.local);
  const isVideoMode =
    room?.mode === "video" ||
    (!!room?.daily_room_name && room?.mode !== "audio");
  const otherForRoles = remoteParticipants.filter(
    (p) => p.user_id && p.user_id !== currentUserId
  );
  const usePipLayout = remoteParticipants.length === 1;

  return (
    <div className="flex flex-col h-full" style={{ background: COLORS.surface }}>
      <div
        className="flex items-center gap-3 p-4 border-b"
        style={{ borderColor: COLORS.border }}
      >
        <button
          onClick={handleLeaveVoice}
          className="p-2 rounded-full hover:bg-white/10"
          style={{ color: COLORS.ivory }}
        >
          <ArrowLeft size={20} />
        </button>
        <div className="flex-1 min-w-0">
          <h2
            className="font-bold text-sm flex items-center gap-2 flex-wrap"
            style={{ color: COLORS.ivory }}
          >
            <span className="truncate">{room?.title}</span>
            <span
              className={`text-[10px] px-2 py-0.5 rounded-full font-normal shrink-0 ${
                roomStatus === "paused"
                  ? "bg-amber-500/20 text-amber-400"
                  : "bg-green-500/20 text-green-400"
              }`}
            >
              {roomStatus === "paused" ? "PAUSE" : "LIVE"}
            </span>
            {isVoiceMode && (
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 font-normal flex items-center gap-1 shrink-0">
                <Volume2 size={10} />
                {isVideoMode ? "VIDÉO" : "VOCAL"}
              </span>
            )}
            {myRole === "co_host" && (
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-300 font-normal flex items-center gap-1 shrink-0">
                <Star size={10} /> CO-HÔTE
              </span>
            )}
          </h2>
          <div
            className="text-xs flex items-center gap-1 flex-wrap mt-0.5"
            style={{ color: COLORS.muted }}
          >
            <Hash size={12} /> {room?.topic}
            {room?.invite_code && (
              <button
                type="button"
                onClick={handleCopyCode}
                className="ml-1 inline-flex items-center gap-1 px-2 py-0.5 rounded-lg border text-[11px] font-bold"
                style={{
                  borderColor: codeCopied ? COLORS.teal : COLORS.border,
                  color: codeCopied ? COLORS.teal : COLORS.gold,
                  background: "rgba(255,255,255,0.03)",
                }}
              >
                {codeCopied ? (
                  <>
                    <Check size={12} /> Copié
                  </>
                ) : (
                  <>
                    <Copy size={12} /> {room.invite_code}
                  </>
                )}
              </button>
            )}
          </div>
        </div>
        <div
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full shrink-0"
          style={{ background: COLORS.surface2 }}
        >
          <Users size={14} style={{ color: COLORS.gold }} />
          <span className="text-xs" style={{ color: COLORS.ivory }}>
            {participantList.length || "–"}
          </span>
        </div>
      </div>

      {pendingRequest && (
        <div
          className="mx-4 mt-3 p-4 rounded-2xl border flex flex-col gap-3"
          style={{
            background: "rgba(45,191,166,0.12)",
            borderColor: "rgba(45,191,166,0.4)",
          }}
        >
          <p className="text-sm font-bold" style={{ color: COLORS.ivory }}>
            L’hôte te propose de devenir co-hôte
          </p>
          <p className="text-xs" style={{ color: COLORS.muted }}>
            Tu pourras activer micro et caméra. Accepter ?
          </p>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => handleRespondRequest(true)}
              disabled={roleActionLoading === "respond"}
              className="flex-1 py-2 rounded-xl font-bold text-sm disabled:opacity-50"
              style={{ background: COLORS.gold, color: "#000" }}
            >
              Accepter
            </button>
            <button
              type="button"
              onClick={() => handleRespondRequest(false)}
              disabled={roleActionLoading === "respond"}
              className="flex-1 py-2 rounded-xl font-bold text-sm border disabled:opacity-50"
              style={{ borderColor: COLORS.border, color: COLORS.ivory }}
            >
              Refuser
            </button>
          </div>
        </div>
      )}

      {roleActionError && !isRoomOwner && (
        <p className="px-4 pt-2 text-xs text-red-400">{roleActionError}</p>
      )}

      {roomStatus === "paused" && (
        <div
          className="mx-4 mt-3 p-3 rounded-xl border flex items-center gap-2 flex-wrap"
          style={{
            background: "rgba(245,158,11,0.12)",
            borderColor: "rgba(245,158,11,0.35)",
          }}
        >
          <Pause size={16} style={{ color: COLORS.gold }} />
          <p className="text-xs font-bold" style={{ color: COLORS.gold }}>
            Débat en pause
          </p>
          <p className="text-[11px]" style={{ color: COLORS.muted }}>
            — le live continue en arrière-plan, les messages restent actifs
          </p>
        </div>
      )}

      {isVoiceMode && (
        <div
          className="px-4 py-3 border-b"
          style={{ borderColor: COLORS.border }}
        >
          {voiceConnecting ? (
            <div
              className="flex flex-col items-center justify-center gap-3 py-10 rounded-2xl border"
              style={{
                background: COLORS.surface2,
                borderColor: COLORS.border,
              }}
            >
              <Loader2
                className="animate-spin"
                size={32}
                style={{ color: COLORS.gold }}
              />
              <p className="text-sm font-bold" style={{ color: COLORS.ivory }}>
                Connexion au live…
              </p>
              <p className="text-xs" style={{ color: COLORS.muted }}>
                Autorisez le micro
                {isVideoMode ? " et la caméra" : ""} si demandé
              </p>
            </div>
          ) : voiceError ? (
            <div className="p-4 rounded-xl bg-red-500/15 border border-red-500/40">
              <p className="text-xs text-red-400 break-all">{voiceError}</p>
            </div>
          ) : (
            <>
              {needAudioUnlock && (
                <button
                  type="button"
                  onClick={handleUnlockAudio}
                  className="w-full mb-3 py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2"
                  style={{ background: COLORS.gold, color: "#000" }}
                >
                  <Volume2 size={18} />
                  Appuyer pour activer le son
                </button>
              )}
              {usePipLayout ? (
                <div className="relative mb-3 rounded-2xl overflow-hidden" style={{ minHeight: 220 }}>
                  <ParticipantTile
                    participant={remoteParticipants[0]}
                    isVideoMode={isVideoMode}
                    isLocal={false}
                    videoTrack={videoTracks[remoteParticipants[0].session_id]}
                    isSpeaking={
                      activeSpeakerId === remoteParticipants[0].session_id
                    }
                  />
                  {localParticipant && (
                    <div
                      className="absolute bottom-2 right-2 w-[30%] max-w-[120px] shadow-lg rounded-xl overflow-hidden border"
                      style={{ borderColor: COLORS.borderGold }}
                    >
                      <ParticipantTile
                        participant={localParticipant}
                        isVideoMode={isVideoMode}
                        isLocal
                        videoTrack={videoTracks[localParticipant.session_id]}
                        isSpeaking={
                          activeSpeakerId === localParticipant.session_id
                        }
                        compact
                      />
                    </div>
                  )}
                </div>
              ) : (
                <div
                  className={`grid gap-2 mb-3 ${
                    remoteParticipants.length === 0
                      ? "grid-cols-1"
                      : "grid-cols-2 sm:grid-cols-3"
                  }`}
                >
                  {localParticipant && (
                    <ParticipantTile
                      participant={localParticipant}
                      isVideoMode={isVideoMode}
                      isLocal
                      videoTrack={videoTracks[localParticipant.session_id]}
                      isSpeaking={
                        activeSpeakerId === localParticipant.session_id
                      }
                    />
                  )}
                  {remoteParticipants.map((p) => (
                    <ParticipantTile
                      key={p.session_id}
                      participant={p}
                      isVideoMode={isVideoMode}
                      isLocal={false}
                      videoTrack={videoTracks[p.session_id]}
                      isSpeaking={activeSpeakerId === p.session_id}
                    />
                  ))}
                </div>
              )}

              {remoteParticipants.length === 0 && (
                <div
                  className="text-center py-3 mb-2 rounded-xl border"
                  style={{
                    background: "rgba(245,158,11,0.08)",
                    borderColor: "rgba(245,158,11,0.25)",
                  }}
                >
                  <p
                    className="text-xs font-bold mb-1"
                    style={{ color: COLORS.gold }}
                  >
                    Personne d’autre pour l’instant
                  </p>
                  <p className="text-[11px] mb-2" style={{ color: COLORS.muted }}>
                    Partage le code pour inviter
                  </p>
                  {room?.invite_code && (
                    <button
                      type="button"
                      onClick={handleCopyCode}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold"
                      style={{ background: COLORS.gold, color: "#000" }}
                    >
                      {codeCopied ? (
                        <>
                          <Check size={14} /> Code copié
                        </>
                      ) : (
                        <>
                          <Copy size={14} /> {room.invite_code}
                        </>
                      )}
                    </button>
                  )}
                </div>
              )}

              <div className="flex items-center justify-center gap-3 flex-wrap">
                {canBroadcast && roomStatus !== "paused" ? (
                  <>
                    <button
                      onClick={toggleMic}
                      className="p-3 rounded-full"
                      style={{
                        background: micOn
                          ? COLORS.gold
                          : "rgba(239,68,68,0.25)",
                        color: micOn ? "#000" : "#ef4444",
                      }}
                      title={micOn ? "Couper le micro" : "Activer le micro"}
                    >
                      {micOn ? <Mic size={18} /> : <MicOff size={18} />}
                    </button>
                    {isVideoMode && (
                      <button
                        onClick={toggleCam}
                        className="p-3 rounded-full"
                        style={{
                          background: camOn
                            ? COLORS.gold
                            : "rgba(239,68,68,0.25)",
                          color: camOn ? "#000" : "#ef4444",
                        }}
                        title={
                          camOn ? "Couper la caméra" : "Activer la caméra"
                        }
                      >
                        {camOn ? <Video size={18} /> : <VideoOff size={18} />}
                      </button>
                    )}
                  </>
                ) : roomStatus === "paused" ? (
                  <p className="text-[11px]" style={{ color: COLORS.muted }}>
                    En pause — micro et caméra désactivés
                  </p>
                ) : (
                  <div className="flex flex-col items-center gap-1.5">
                    <button
                      type="button"
                      onClick={handleRequestToSpeak}
                      disabled={speakRequestSent || speakRequestLoading}
                      className="px-5 py-2.5 rounded-xl font-bold text-sm disabled:opacity-60 flex items-center gap-2"
                      style={{ background: COLORS.gold, color: "#000" }}
                    >
                      <Hand size={16} />
                      {speakRequestLoading
                        ? "Envoi…"
                        : speakRequestSent
                          ? "Demande envoyée ✓"
                          : "Demander à parler"}
                    </button>
                    <p className="text-[11px]" style={{ color: COLORS.muted }}>
                      L’hôte verra ta demande dans le chat
                    </p>
                  </div>
                )}

                {isRoomOwner && (
                  <button
                    type="button"
                    onClick={handlePauseToggle}
                    disabled={pauseLoading}
                    className="p-3 rounded-full disabled:opacity-50"
                    style={{
                      background:
                        roomStatus === "paused"
                          ? "rgba(34,197,94,0.25)"
                          : "rgba(245,158,11,0.25)",
                      color:
                        roomStatus === "paused" ? "#22c55e" : COLORS.gold,
                    }}
                    title={
                      roomStatus === "paused"
                        ? "Reprendre le débat"
                        : "Mettre en pause"
                    }
                  >
                    {roomStatus === "paused" ? (
                      <Play size={18} />
                    ) : (
                      <Pause size={18} />
                    )}
                  </button>
                )}

                <button
                  onClick={handleLeaveVoice}
                  className="p-3 rounded-full"
                  style={{
                    background: "rgba(239,68,68,0.25)",
                    color: "#ef4444",
                  }}
                  title="Quitter le live"
                >
                  <PhoneOff size={18} />
                </button>
              </div>
            </>
          )}
        </div>
      )}

      {isRoomOwner && isVoiceMode && !voiceConnecting && (
        <div
          className="px-4 py-3 border-b"
          style={{ borderColor: COLORS.border }}
        >
          <p
            className="text-[10px] font-bold uppercase tracking-wider mb-2"
            style={{ color: COLORS.muted }}
          >
            Participants — proposer co-hôte
          </p>
          {roleActionError && (
            <p className="text-xs text-red-400 mb-2">{roleActionError}</p>
          )}
          {otherForRoles.length === 0 ? (
            <p className="text-xs" style={{ color: COLORS.muted }}>
              Personne d’autre n’est encore connecté.
            </p>
          ) : (
            <div className="flex flex-col gap-2 max-h-36 overflow-y-auto">
              {otherForRoles.map((p) => {
                const role = participantRoles[p.user_id] || "viewer";
                const isLoadingThis = roleActionLoading === p.user_id;
                return (
                  <div
                    key={p.session_id}
                    className="flex items-center justify-between gap-2 text-xs"
                  >
                    <span
                      className="flex items-center gap-1.5 truncate"
                      style={{ color: COLORS.ivory }}
                    >
                      {role === "co_host" && (
                        <Star size={12} style={{ color: COLORS.teal }} />
                      )}
                      {p.user_name || "Participant"}
                    </span>
                    <button
                      onClick={() => handleToggleCoHost(p.user_id, role)}
                      disabled={isLoadingThis}
                      className="px-2.5 py-1.5 rounded-lg font-bold shrink-0 disabled:opacity-50"
                      style={{
                        background:
                          role === "co_host"
                            ? "rgba(239,68,68,0.15)"
                            : COLORS.gold,
                        color: role === "co_host" ? "#ef4444" : "#000",
                      }}
                    >
                      {isLoadingThis
                        ? "…"
                        : role === "co_host"
                          ? "Rétrograder"
                          : "Proposer co-hôte"}
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.length === 0 ? (
          <div className="text-center py-10" style={{ color: COLORS.muted }}>
            <MessageSquare size={48} className="mx-auto mb-3 opacity-50" />
            <p className="text-sm">Soyez le premier à donner votre avis !</p>
          </div>
        ) : (
          messages.map((msg) => {
            const isMe = msg.sender_id === currentUserId;
            const isAI = msg.sender_type === "ai";
            const isSpeakRequest =
              typeof msg.text === "string" &&
              msg.text.includes("demande à parler");
            const profile = isMe
              ? { display_name: "Moi", flag: "🌍" }
              : msg.profile || { display_name: "Membre", flag: "🌍" };

            return (
              <div
                key={msg.id}
                className={`flex gap-2 ${isMe ? "flex-row-reverse" : "flex-row"}`}
              >
                {!isMe && (
                  <div
                    className="w-8 h-8 rounded-full flex items-center justify-center text-xs shrink-0 border overflow-hidden"
                    style={{
                      borderColor: isAI
                        ? "rgba(167,139,250,0.5)"
                        : isSpeakRequest
                          ? COLORS.gold
                          : COLORS.borderGold,
                      background: COLORS.surface2,
                    }}
                  >
                    {isAI ? (
                      "✨"
                    ) : isSpeakRequest ? (
                      "🙋"
                    ) : profile.avatar_url ? (
                      <img
                        src={profile.avatar_url}
                        className="w-full h-full object-cover"
                        alt=""
                      />
                    ) : (
                      profile.flag
                    )}
                  </div>
                )}
                <div
                  className={`max-w-[75%] px-4 py-2.5 rounded-2xl text-sm ${
                    isMe ? "rounded-tr-sm" : "rounded-tl-sm"
                  }`}
                  style={{
                    background: isMe
                      ? COLORS.gold
                      : isAI
                        ? "rgba(167,139,250,0.15)"
                        : isSpeakRequest
                          ? "rgba(217,174,82,0.15)"
                          : COLORS.surface2,
                    color: isMe ? "#000" : COLORS.ivory,
                    border: isAI
                      ? "1px solid rgba(167,139,250,0.4)"
                      : isSpeakRequest
                        ? `1px solid ${COLORS.gold}55`
                        : undefined,
                  }}
                >
                  {!isMe && (
                    <p
                      className="text-[10px] font-bold mb-1"
                      style={{
                        color: isAI
                          ? "#a78bfa"
                          : COLORS.gold,
                      }}
                    >
                      {isAI
                        ? "✨ IA BAARO"
                        : `${profile.display_name || "Membre"} ${profile.flag || ""}`}
                    </p>
                  )}
                  <p>{msg.text}</p>
                  <p
                    className={`text-[10px] mt-1.5 ${
                      isMe ? "text-black/60" : "text-gray-400"
                    }`}
                  >
                    {new Date(msg.created_at).toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </p>
                </div>
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      <form
        onSubmit={handleSendMessage}
        className="p-4 border-t flex gap-2"
        style={{ borderColor: COLORS.border }}
      >
        <input
          type="text"
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          placeholder="Message ou question pour l'IA…"
          className="flex-1 px-4 py-3 rounded-xl border text-sm outline-none"
          style={{
            background: COLORS.surface2,
            borderColor: COLORS.border,
            color: COLORS.ivory,
          }}
        />
        <button
          type="button"
          onClick={handleAskAI}
          disabled={!newMessage.trim() || aiLoading}
          title="Demander à l'IA"
          className="p-3 rounded-xl disabled:opacity-50"
          style={{
            background: "rgba(167,139,250,0.25)",
            color: "#a78bfa",
          }}
        >
          <Sparkles size={18} className={aiLoading ? "animate-spin" : ""} />
        </button>
        <button
          type="submit"
          disabled={!newMessage.trim()}
          className="p-3 rounded-xl disabled:opacity-50"
          style={{ background: COLORS.gold, color: "#000" }}
        >
          <Send size={18} />
        </button>
      </form>
    </div>
  );
}
