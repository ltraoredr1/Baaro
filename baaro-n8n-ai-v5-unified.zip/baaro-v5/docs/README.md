# BAARO AI Agent v5 – Unifié

**Tout-en-un :** Grok · Claude · GPT-4o · Gemini + Mémoire + Outils Supabase + RAG vectoriel

---

## Fonctionnalités

| Feature | Détail |
|---------|--------|
| **Grok (xAI)** | Modèle par défaut |
| **Claude** | Anthropic Sonnet 4 |
| **GPT-4o** | OpenAI |
| **Gemini** | Google Gemini 2.0 Flash |
| **RAG** | Recherche sémantique pgvector (Supabase) |
| **Outils** | Lecture portefeuille, profil, transactions |
| **Mémoire** | Via `sessionId` (le front renvoie l’historique) |
| **Mode cohost** | Co-animatrice des lives |
| **Fallback** | Si un modèle échoue → Grok puis Claude |

---

## Contenu du package

```
baaro-v5/
├── sql/supabase-vector-setup.sql
├── workflow/
│   ├── BAARO-AI-Agent-v5-Unified.json   ← Agent principal
│   └── BAARO-Ingest-Knowledge.json      ← Ingestion documents
├── integration/chat-v5.js
└── docs/
```

---

## 1. Supabase

Exécute `sql/supabase-vector-setup.sql` dans le SQL Editor.

Puis **indexe** les documents d’exemple via le webhook d’ingestion (voir étape 3).

---

## 2. Variables n8n

```env
# Modèles (au moins une)
XAI_API_KEY=xai-...                 # Grok (recommandé)
ANTHROPIC_API_KEY=sk-ant-...
OPENAI_API_KEY=sk-...               # GPT + embeddings RAG
GOOGLE_API_KEY=...                  # ou GEMINI_API_KEY

# Supabase (outils + RAG)
SUPABASE_URL=https://xxx.supabase.co
SUPABASE_SERVICE_ROLE_KEY=eyJ...

# Optionnel
BAARO_AI_MODEL=grok
```

---

## 3. Workflows n8n

1. Importe `BAARO-AI-Agent-v5-Unified.json` → Active → copie l’URL
2. Importe `BAARO-Ingest-Knowledge.json` → Active

### Indexer les documents

```bash
curl -X POST https://TON-N8N/webhook/baaro-ingest \
  -H "Content-Type: application/json" \
  -d '{"title":"Comment gagner des points sur BAARO","content":"...","category":"faq"}'
```

Répète pour chaque document (ou écris un petit script).

---

## 4. BAARO / Vercel

```env
N8N_BAARO_WEBHOOK_URL=https://ton-n8n.../webhook/baaro-ai
BAARO_AI_MODEL=grok
```

Remplace `api/chat.js` par `integration/chat-v5.js`.

### Mémoire côté front (recommandé)

```js
let sessionId = localStorage.getItem('baaro_ai_session');

const res = await fetch('/api/chat', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    ...(sessionId ? { 'X-Session-Id': sessionId } : {})
  },
  body: JSON.stringify({
    messages: historiqueComplet,  // important pour la mémoire
    context,
    model: 'grok'                 // optionnel
  })
});

const data = await res.json();
if (data.sessionId) {
  localStorage.setItem('baaro_ai_session', data.sessionId);
}
```

> La mémoire repose sur le **tableau `messages`** envoyé à chaque requête (historique de conversation). Le `sessionId` sert au tracking et aux headers.

---

## 5. Choisir le modèle

| Méthode | Exemple |
|---------|---------|
| Requête | `"model": "grok"` |
| Env | `BAARO_AI_MODEL=claude` |
| Défaut | `grok` |

---

## Architecture

```
BAARO Front
    ↓  messages + context + model + sessionId
api/chat.js
    ↓
n8n Webhook
    ↓
┌─────────────────────────────────────────┐
│  1. RAG (embedding + match_knowledge)   │
│  2. Outils (wallet, profile, txs)       │
│  3. System prompt enrichi               │
│  4. Appel modèle choisi                 │
│     Grok / Claude / GPT / Gemini        │
│  5. Fallback auto si erreur             │
└─────────────────────────────────────────┘
    ↓
Réponse { reply, model, provider, sessionId, rag_hits }
```

---

## Test rapide

```bash
curl -X POST https://TON-N8N/webhook/baaro-ai \
  -H "Content-Type: application/json" \
  -d '{
    "messages": [{"role":"user","content":"Comment gagner des points ?"}],
    "model": "grok",
    "context": {"display_name":"Alice","user_id":"uuid-si-dispo","points":10}
  }'
```

Tu devrais voir `rag_hits > 0` si les documents sont indexés.

---

**v5 Unifiée – 6 août 2026 – Prêt pour production**
