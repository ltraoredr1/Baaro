# BAARO AI v5 Unifiée – 5 minutes

## 1. Supabase
Exécute `sql/supabase-vector-setup.sql`

## 2. n8n – Variables
```
XAI_API_KEY=...
OPENAI_API_KEY=...          # embeddings RAG
SUPABASE_URL=...
SUPABASE_SERVICE_ROLE_KEY=...
BAARO_AI_MODEL=grok
# optionnel : ANTHROPIC_API_KEY, GOOGLE_API_KEY
```

## 3. n8n – Workflows
- Importe `BAARO-AI-Agent-v5-Unified.json` → Active → copie URL
- Importe `BAARO-Ingest-Knowledge.json` → Active
- Indexe les docs via `/webhook/baaro-ingest`

## 4. BAARO
- Remplace `api/chat.js` par `chat-v5.js`
- Vercel :
  ```
  N8N_BAARO_WEBHOOK_URL=https://.../webhook/baaro-ai
  BAARO_AI_MODEL=grok
  ```
- Redéploie

## Modèles
`grok` (défaut) | `claude` | `gpt` | `gemini`
