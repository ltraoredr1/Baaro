-- ============================================================
-- BAARO – pgvector + base de connaissances (RAG)
-- À exécuter dans le SQL Editor de Supabase
-- ============================================================

create extension if not exists vector;

create table if not exists knowledge_documents (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  content text not null,
  category text default 'general',
  source text,
  metadata jsonb default '{}'::jsonb,
  embedding vector(1536),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create index if not exists knowledge_documents_embedding_idx
  on knowledge_documents using hnsw (embedding vector_cosine_ops);

create index if not exists knowledge_documents_category_idx
  on knowledge_documents (category);

create or replace function match_knowledge(
  query_embedding vector(1536),
  match_threshold float default 0.65,
  match_count int default 5,
  filter_category text default null
)
returns table (
  id uuid,
  title text,
  content text,
  category text,
  similarity float
)
language plpgsql
as $$
begin
  return query
  select
    kd.id,
    kd.title,
    kd.content,
    kd.category,
    1 - (kd.embedding <=> query_embedding) as similarity
  from knowledge_documents kd
  where
    (filter_category is null or kd.category = filter_category)
    and 1 - (kd.embedding <=> query_embedding) > match_threshold
  order by kd.embedding <=> query_embedding
  limit match_count;
end;
$$;

alter table knowledge_documents enable row level security;

drop policy if exists "Lecture publique knowledge" on knowledge_documents;
create policy "Lecture publique knowledge"
  on knowledge_documents for select using (true);

drop policy if exists "Écriture service_role uniquement" on knowledge_documents;
create policy "Écriture service_role uniquement"
  on knowledge_documents for all using (auth.role() = 'service_role');

-- Documents d'exemple (embeddings à générer via le workflow d'ingestion)
insert into knowledge_documents (title, content, category) values
(
  'Comment gagner des points sur BAARO',
  'Sur BAARO tu gagnes des points en : publier une pensée ou un article (+5 pts), donner un J''aime (+2 pts), commenter (+1 pt), participer à un débat (+5 pts), inviter un ami via le programme de parrainage. Il existe aussi un bonus quotidien. Les points peuvent être convertis en BARO Coin.',
  'faq'
),
(
  'Qu''est-ce que le BARO Coin',
  'Le BARO Coin est la crypto interne de BAARO. Tu peux convertir tes points en BARO Coin. Le solde est stocké de façon sécurisée côté serveur. Les rachats à valeur réelle (carte cadeau, virement) sont soumis à des conditions (âge du compte, plafond quotidien).',
  'faq'
),
(
  'Messagerie chiffrée de bout en bout',
  'La messagerie BAARO est chiffrée de bout en bout. Chaque appareil génère une paire de clés RSA. La clé publique est stockée dans le profil, la clé privée ne quitte jamais l''appareil. Le serveur ne voit jamais le contenu des messages en clair.',
  'feature'
),
(
  'Règles de la communauté',
  'Respecte les autres membres. Pas de spam, pas de harcèlement, pas de contenu illégal. Les comptes restreignés perdent l''accès aux rachats. En cas de problème, contacte le support via l''assistant IA ou les canaux officiels.',
  'rules'
),
(
  'Mode Live et co-animatrice IA',
  'Dans les lives (texte, vocal ou vidéo) tu peux inviter l''assistant IA comme co-animatrice. Elle pose des questions, relance le débat et reste neutre. Elle répond en 1 à 3 phrases pour ne pas monopoliser le chat.',
  'feature'
),
(
  'Parrainage',
  'Chaque membre a un code de parrainage unique. Quand un ami s''inscrit avec ton lien, tu gagnes des points. Le lien ressemble à https://baaro.app/register?ref=TON-CODE.',
  'faq'
),
(
  'Protection anti-fraude',
  'BAARO limite les comptes par appareil, applique un plafond de gains quotidien, et impose un délai minimum avant les rachats à valeur réelle. Un CAPTCHA (Turnstile) est demandé à la création de compte.',
  'rules'
)
on conflict do nothing;
