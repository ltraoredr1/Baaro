-- ============================================================
-- BAARO — Indexes de performance
-- À exécuter dans le SQL Editor de Supabase (après les migrations précédentes)
-- ============================================================

-- Posts (fil d'actualité)
CREATE INDEX IF NOT EXISTS idx_posts_created_at
  ON posts (created_at DESC);

CREATE INDEX IF NOT EXISTS idx_posts_author
  ON posts (author_id);

-- Stories
CREATE INDEX IF NOT EXISTS idx_stories_expires
  ON stories (expires_at);

CREATE INDEX IF NOT EXISTS idx_stories_author
  ON stories (author_id);

-- Transactions (historique portefeuille + plafond quotidien)
CREATE INDEX IF NOT EXISTS idx_transactions_user_created
  ON transactions (user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_transactions_user_pts
  ON transactions (user_id, pts)
  WHERE pts > 0;

-- Follows / amis
CREATE INDEX IF NOT EXISTS idx_follows_follower_status
  ON follows (follower_id, status);

CREATE INDEX IF NOT EXISTS idx_follows_following_status
  ON follows (following_id, status);

CREATE INDEX IF NOT EXISTS idx_follows_friend_pending
  ON follows (following_id, is_friend, status)
  WHERE is_friend = true AND status = 'pending';

-- Messages
CREATE INDEX IF NOT EXISTS idx_messages_conversation
  ON messages (conversation_id, created_at DESC);

-- Profiles (recherche)
CREATE INDEX IF NOT EXISTS idx_profiles_handle
  ON profiles (handle);

CREATE INDEX IF NOT EXISTS idx_profiles_display_name
  ON profiles (display_name);

-- Wallets / crypto (déjà indexés par user_id en PK, mais on s'assure)
CREATE INDEX IF NOT EXISTS idx_wallets_user
  ON wallets (user_id);

CREATE INDEX IF NOT EXISTS idx_crypto_holdings_user
  ON crypto_holdings (user_id);
