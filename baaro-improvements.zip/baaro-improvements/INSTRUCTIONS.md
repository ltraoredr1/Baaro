# BAARO — Fichiers d'amélioration (v1.9)

Ces fichiers corrigent et améliorent la base actuelle du projet.
Remplace (ou fusionne) les fichiers correspondants dans ton dépôt.

## Fichiers fournis

| Fichier | Action | Description |
|---------|--------|-------------|
| `src/main.jsx` | **Remplacer** | Ajoute AppProvider + ErrorBoundary + ToastProvider |
| `src/App.jsx` | **Remplacer** | Version nettoyée, utilise le contexte, lazy loading |
| `src/contexts/AppContext.jsx` | **Remplacer** | Source unique de vérité (soldes, earn, auth…) |
| `src/hooks/useWallet.js` | **Remplacer** | Hook prêt à l'emploi |
| `src/components/ErrorBoundary.jsx` | **Créer** | Empêche les crashes d'onglet |
| `api/_rateLimit.js` | **Remplacer** | Bug template literal corrigé |
| `api/wallet.js` | **Remplacer** | Solde initial = 0, rate-limit intégré |
| `vite.config.js` | **Remplacer** | Code splitting (vendor / supabase / daily) |
| `supabase/011_performance_indexes.sql` | **Exécuter** | Indexes pour accélérer les requêtes |

## Ordre d'intégration recommandé

1. **Sauvegarde** ton dépôt (commit ou branche).
2. Copie les fichiers un par un.
3. Exécute `011_performance_indexes.sql` dans le SQL Editor Supabase.
4. `npm install` (rien de nouveau, mais au cas où).
5. `npm run dev` et teste :
   - Connexion anonyme
   - Gain de points (doit passer par le serveur)
   - Conversion BARO
   - Navigation entre onglets (lazy)

## Changements importants

### Sécurité portefeuille
- Le client **ne crée plus** de wallet avec 1284 points.
- Solde initial = **0** (créé uniquement côté serveur).
- Toute écriture passe par `/api/wallet`.

### Architecture
- `AppContext` = unique source de vérité.
- `App.jsx` ne gère plus les soldes ni l'auth.
- Tabs lourds (Debates, Offline, Assistant) en lazy loading.

### Robustesse
- ErrorBoundary global + par zone de contenu.
- Rate-limit corrigé et activé sur `/api/wallet`.

## Notes

- Si un composant (`WalletTab`, `CryptoTab`…) attend encore des props `setPointsBalance` / `setBaroBalance`, tu peux les retirer progressivement et utiliser `useWallet()` à la place.
- `WELCOME_BONUS` est à 0 dans `api/wallet.js`. Mets 50 (ou autre) si tu veux un bonus de bienvenue **serveur**.
- CORS reste en `*` pour le développement. En production, remplace par ton domaine Vercel.

Bon courage !
