-- BAARO — Vidéos + bibliothèque de sons (style TikTok)
-- À exécuter dans le SQL Editor Supabase

-- 1) Colonnes manquantes sur videos
alter table videos add column if not exists description text;
alter table videos add column if not exists video_url text;
alter table videos add column if not exists thumbnail_url text;
alter table videos add column if not exists likes int not null default 0;
alter table videos add column if not exists comments_count int not null default 0;
alter table videos add column if not exists is_repost boolean not null default false;
alter table videos add column if not exists original_author_id uuid references auth.users(id) on delete set null;
alter table videos add column if not exists sound_id uuid;
alter table videos add column if not exists duration text default '00:00';

-- 2) Table des sons
create table if not exists sounds (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  artist text default 'BAARO',
  audio_url text not null,
  cover_url text,
  duration_sec int default 30,
  usage_count int not null default 0,
  created_at timestamptz not null default now()
);

alter table sounds enable row level security;
drop policy if exists "sounds_read" on sounds;
create policy "sounds_read" on sounds for select using (true);
-- insertion réservée au service_role / admin (pas de policy insert pour anon)

-- FK soft (si sound_id pointe vers sounds)
do $$
begin
  if not exists (
    select 1 from information_schema.table_constraints
    where constraint_name = 'videos_sound_id_fkey'
  ) then
    alter table videos
      add constraint videos_sound_id_fkey
      foreign key (sound_id) references sounds(id) on delete set null;
  end if;
exception when others then
  raise notice 'FK sound_id déjà présente ou non applicable';
end $$;

-- 3) Likes / commentaires vidéo
create table if not exists video_likes (
  video_id uuid not null references videos(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (video_id, user_id)
);
alter table video_likes enable row level security;
drop policy if exists "video_likes_read" on video_likes;
drop policy if exists "video_likes_own" on video_likes;
create policy "video_likes_read" on video_likes for select using (true);
create policy "video_likes_own" on video_likes for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create table if not exists video_comments (
  id uuid primary key default gen_random_uuid(),
  video_id uuid not null references videos(id) on delete cascade,
  author_id uuid not null references auth.users(id) on delete cascade,
  text text not null,
  created_at timestamptz not null default now()
);
alter table video_comments enable row level security;
drop policy if exists "video_comments_read" on video_comments;
drop policy if exists "video_comments_insert" on video_comments;
create policy "video_comments_read" on video_comments for select using (true);
create policy "video_comments_insert" on video_comments for insert with check (auth.uid() = author_id);

-- 4) Policies videos (si absentes)
alter table videos enable row level security;
drop policy if exists "videos_read" on videos;
drop policy if exists "videos_insert" on videos;
create policy "videos_read" on videos for select using (true);
create policy "videos_insert" on videos for insert with check (auth.uid() = author_id);

-- 5) Sons de démonstration (URLs publiques libres de droits / samples courts)
-- Remplace par tes propres fichiers dans le bucket Storage "sounds" si besoin.
insert into sounds (title, artist, audio_url, duration_sec, usage_count)
select * from (values
  ('Afro Beat Pulse', 'BAARO Sounds', 'https://cdn.pixabay.com/download/audio/2022/03/24/audio_c8c8a73467.mp3?filename=afro-beat-112199.mp3', 30, 120),
  ('Chill Lo-Fi', 'BAARO Sounds', 'https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3?filename=lofi-study-112191.mp3', 30, 89),
  ('Energy Drop', 'BAARO Sounds', 'https://cdn.pixabay.com/download/audio/2021/08/04/audio_0625c1539c.mp3?filename=energetic-indie-rock.mp3', 30, 56),
  ('Sunset Vibes', 'BAARO Sounds', 'https://cdn.pixabay.com/download/audio/2022/10/25/audio_4c9b6d0b0e.mp3?filename=calm-background.mp3', 30, 41)
) as v(title, artist, audio_url, duration_sec, usage_count)
where not exists (select 1 from sounds limit 1);

-- Bucket Storage à créer manuellement dans Supabase :
--  - Nom : videos  (public)
--  - Nom : sounds  (public)  — optionnel si tu héberges les mp3 ailleurs

-- Compteur d'utilisation des sons (optionnel)
create or replace function increment_sound_usage(sid uuid)
returns void
language sql
security definer
as $$
  update sounds set usage_count = usage_count + 1 where id = sid;
$$;

-- Filtre utilisé lors de l'enregistrement (info)
alter table videos add column if not exists filter_used text;

-- ============================================================
-- Storage buckets policies (idempotent)
-- ============================================================
-- Si tu as l'erreur "policy already exists", ce bloc est sûr à relancer.

-- Bucket videos
insert into storage.buckets (id, name, public)
values ('videos', 'videos', true)
on conflict (id) do update set public = true;

drop policy if exists "videos_public_read" on storage.objects;
create policy "videos_public_read"
  on storage.objects for select
  using (bucket_id = 'videos');

drop policy if exists "videos_auth_upload" on storage.objects;
create policy "videos_auth_upload"
  on storage.objects for insert
  with check (bucket_id = 'videos' and auth.role() = 'authenticated');

drop policy if exists "videos_auth_update" on storage.objects;
create policy "videos_auth_update"
  on storage.objects for update
  using (bucket_id = 'videos' and auth.role() = 'authenticated');

drop policy if exists "videos_auth_delete" on storage.objects;
create policy "videos_auth_delete"
  on storage.objects for delete
  using (bucket_id = 'videos' and auth.uid()::text = (storage.foldername(name))[1]);

-- Bucket stories (si utilisé)
insert into storage.buckets (id, name, public)
values ('stories', 'stories', true)
on conflict (id) do update set public = true;

drop policy if exists "stories_public_read" on storage.objects;
create policy "stories_public_read"
  on storage.objects for select
  using (bucket_id = 'stories');

drop policy if exists "stories_auth_upload" on storage.objects;
create policy "stories_auth_upload"
  on storage.objects for insert
  with check (bucket_id = 'stories' and auth.role() = 'authenticated');

-- Bucket media (posts)
insert into storage.buckets (id, name, public)
values ('media', 'media', true)
on conflict (id) do update set public = true;

drop policy if exists "media_public_read" on storage.objects;
create policy "media_public_read"
  on storage.objects for select
  using (bucket_id = 'media');

drop policy if exists "media_auth_upload" on storage.objects;
create policy "media_auth_upload"
  on storage.objects for insert
  with check (bucket_id = 'media' and auth.role() = 'authenticated');
