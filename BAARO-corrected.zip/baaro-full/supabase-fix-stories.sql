-- BAARO — Alignement table stories (média + expiration)
-- À exécuter dans le SQL Editor Supabase

-- Colonnes attendues par l'app
alter table stories add column if not exists media_url text;
alter table stories add column if not exists media_type text default 'image';
alter table stories add column if not exists text_overlay text;
alter table stories add column if not exists filter_used text;
alter table stories add column if not exists expires_at timestamptz default (now() + interval '24 hours');

-- text n'est plus obligatoire (on utilise text_overlay ou media)
do $$
begin
  alter table stories alter column text drop not null;
exception when others then
  null;
end $$;

-- Si d'anciennes lignes n'ont pas expires_at
update stories set expires_at = created_at + interval '24 hours'
where expires_at is null;

-- RLS
alter table stories enable row level security;
drop policy if exists "stories_read" on stories;
drop policy if exists "stories_insert" on stories;
drop policy if exists "stories_delete_own" on stories;
create policy "stories_read" on stories for select using (true);
create policy "stories_insert" on stories for insert with check (auth.uid() = author_id);
create policy "stories_delete_own" on stories for delete using (auth.uid() = author_id);

-- Index
create index if not exists idx_stories_expires on stories (expires_at);
create index if not exists idx_stories_author on stories (author_id);

-- Bucket Storage stories
insert into storage.buckets (id, name, public)
values ('stories', 'stories', true)
on conflict (id) do update set public = true;

drop policy if exists "stories_public_read" on storage.objects;
create policy "stories_public_read"
  on storage.objects for select
  using (bucket_id = 'stories');

drop policy if exists "stories_auth_upload" on storage.objects;
create policy "stories_auth_upload"
  on storage.objects for insert
  with check (bucket_id = 'stories' and auth.role() = 'authenticated');

drop policy if exists "stories_auth_delete" on storage.objects;
create policy "stories_auth_delete"
  on storage.objects for delete
  using (bucket_id = 'stories' and auth.uid()::text = (storage.foldername(name))[1]);
