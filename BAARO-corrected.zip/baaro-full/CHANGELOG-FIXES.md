# BAARO — Correctifs appliqués (pack corrigé)

Date : 2026-08-14

## Corrections critiques

### 1. Sécurité du portefeuille
- **Avant** : `AppContext.jsx` et l’ancien `App.jsx` écrivaient directement dans `wallets` côté client (upsert balance: 1284).
- **Après** : lecture seule côté client. Création et modification du solde uniquement via `/api/wallet` (service_role + optimistic locking).
- Fichier : `src/contexts/AppContext.jsx`

### 2. Table `follows` alignée
- **Avant** : schéma SQL utilisait `followed_id`, le code JS utilisait `following_id` (+ `status`, `is_friend`).
- **Après** :
  - `supabase-schema.sql` crée directement `following_id`, `status`, `is_friend`.
  - Migration `supabase-fix-follows.sql` pour les projets déjà déployés (rename + colonnes).
  - Tous les fichiers JS/JSX mis à jour (`FollowButton`, `useSocial`, `useProfile`, etc.).

### 3. Architecture App
- `App.jsx` utilise maintenant `AppProvider` + `useApp()`.
- Suppression de la duplication de logique d’auth / chargement de soldes.

### 4. Communauté (FriendsTab)
- **Avant** : s’appuyait sur `getUserById` mock qui renvoyait `null` → listes vides.
- **Après** : récupération réelle des profils via Supabase (`profiles`).

### 5. Données mock
- `src/usersData.js` et `src/data/users.js` vidés (plus de faux utilisateurs injectés).
- `GlobalSearchModal` : recherche prioritaire sur la table `profiles` uniquement.

## Fichiers SQL à exécuter (ordre)

1. `supabase-schema.sql` (déjà corrigé pour les nouvelles installs)
2. `supabase-security-fix.sql`
3. `supabase-add-social-features.sql` + autres `supabase-add-*.sql`
4. **`supabase-fix-follows.sql`** ← obligatoire si la base existait déjà avec `followed_id`
5. Autres migrations (media, debates, performance…)

## Vérifications recommandées après déploiement

- [ ] Console navigateur : plus d’erreur RLS sur `wallets`
- [ ] Like / publier → points crédités via API
- [ ] Follow / unfollow / demandes d’amis fonctionnent
- [ ] Compte anonyme ne reçoit pas de points
- [ ] Recherche globale trouve les vrais profils

## Non modifié (volontairement)

- Logique serveur `api/wallet.js` (déjà solide)
- Daily.co / débats live
- Chiffrement E2E messagerie
- Plugin Nearby / Capacitor
