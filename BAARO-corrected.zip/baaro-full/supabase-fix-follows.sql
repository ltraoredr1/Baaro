-- ============================================================
-- BAARO — Alignement de la table follows
-- À exécuter dans le SQL Editor de Supabase
-- ============================================================
-- Problème : supabase-schema.sql crée "followed_id"
--            mais le code client (supabaseClient.js) utilise "following_id"
--            + colonnes status / is_friend.
-- Solution : renommer + ajouter les colonnes manquantes de façon idempotente.

-- 1. Renommer la colonne si elle existe encore sous l'ancien nom
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'follows' AND column_name = 'followed_id'
  ) AND NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'follows' AND column_name = 'following_id'
  ) THEN
    ALTER TABLE follows RENAME COLUMN followed_id TO following_id;
  END IF;
END $$;

-- 2. Ajouter les colonnes utilisées par le code social
ALTER TABLE follows
  ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'accepted',
  ADD COLUMN IF NOT EXISTS is_friend boolean NOT NULL DEFAULT false;

-- 3. S'assurer que la PK est cohérente (follower_id, following_id)
--    (on ne droppe pas la contrainte existante pour éviter de casser les données)
DO $$
BEGIN
  -- Optionnel : créer un index utile pour les requêtes "mes abonnés"
  IF NOT EXISTS (
    SELECT 1 FROM pg_indexes WHERE indexname = 'idx_follows_following_id'
  ) THEN
    CREATE INDEX idx_follows_following_id ON follows (following_id);
  END IF;
END $$;

-- 4. Mettre à jour les policies si besoin (elles utilisent déjà follower_id)
--    On s'assure qu'elles existent toujours
DROP POLICY IF EXISTS "follows_read" ON follows;
DROP POLICY IF EXISTS "follows_own" ON follows;

CREATE POLICY "follows_read" ON follows FOR SELECT USING (true);
CREATE POLICY "follows_own" ON follows
  FOR ALL
  USING (auth.uid() = follower_id)
  WITH CHECK (auth.uid() = follower_id);

-- 5. Vérification rapide (à regarder dans les résultats)
SELECT column_name, data_type
FROM information_schema.columns
WHERE table_name = 'follows'
ORDER BY ordinal_position;
