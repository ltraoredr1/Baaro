import { Component } from "react";
import { COLORS } from "../theme.js";

export class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, message: "" };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, message: error?.message || String(error) };
  }

  componentDidCatch(error, info) {
    console.error("ErrorBoundary:", error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div
          className="rounded-2xl border p-6 text-center"
          style={{
            background: COLORS.surface,
            borderColor: "rgba(239,68,68,0.4)",
            color: COLORS.ivory,
          }}
        >
          <p className="text-2xl mb-2">⚠️</p>
          <p className="font-bold mb-1">Erreur d’affichage</p>
          <p className="text-sm mb-4" style={{ color: COLORS.muted }}>
            {this.state.message}
          </p>
          <button
            onClick={() => this.setState({ hasError: false, message: "" })}
            className="px-4 py-2 rounded-xl text-sm font-bold"
            style={{ background: COLORS.gold, color: COLORS.bg }}
          >
            Réessayer
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
