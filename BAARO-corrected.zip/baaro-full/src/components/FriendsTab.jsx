import { useState, useEffect, useCallback } from "react";
import {
  getFollowers,
  getFollowing,
  getFriends,
  getPendingRequests,
  followUser,
  unfollowUser,
  acceptFriendRequest,
  rejectFriendRequest,
  getUserById,
} from "../supabaseClient.js";
import { COLORS } from "../theme.js";
import { useToast } from "./ToastContext.jsx";
import { Users, UserPlus, UserMinus, Check, X } from "lucide-react";

export function FriendsTab({ currentUserId }) {
  const { showToast } = useToast();
  const [activeSubTab, setActiveSubTab] = useState("friends");
  const [friends, setFriends] = useState([]);
  const [followers, setFollowers] = useState([]);
  const [following, setFollowing] = useState([]);
  const [pending, setPending] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchProfiles = useCallback(async (ids) => {
    if (!ids?.length) return [];
    const results = await Promise.all(
      ids.map(async (id) => {
        const { data } = await getUserById(id);
        return data
          ? {
              user_id: data.user_id || id,
              display_name: data.display_name || "Membre BAARO",
              handle: data.handle || `@user_${String(id).slice(0, 8)}`,
              flag: data.flag || "🌍",
              bio: data.bio || "",
            }
          : {
              user_id: id,
              display_name: "Membre BAARO",
              handle: `@user_${String(id).slice(0, 8)}`,
              flag: "🌍",
              bio: "",
            };
      })
    );
    return results;
  }, []);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      if (activeSubTab === "friends") {
        const { data: ids } = await getFriends();
        setFriends(await fetchProfiles(ids || []));
      } else if (activeSubTab === "followers") {
        const { data: ids } = await getFollowers();
        setFollowers(await fetchProfiles(ids || []));
      } else if (activeSubTab === "following") {
        const { data: ids } = await getFollowing();
        setFollowing(await fetchProfiles(ids || []));
      } else if (activeSubTab === "requests") {
        const { data } = await getPendingRequests();
        const rows = data || [];
        const profiles = await fetchProfiles(rows.map((r) => r.follower_id));
        setPending(
          rows.map((req, i) => ({
            followId: req.id,
            follower_id: req.follower_id,
            ...profiles[i],
          }))
        );
      }
    } catch (error) {
      console.error(error);
      showToast("Erreur de chargement de la communauté", "error");
    } finally {
      setLoading(false);
    }
  }, [activeSubTab, fetchProfiles, showToast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleFollow = async (userId) => {
    const { error } = await followUser(userId);
    if (error) showToast("Impossible de suivre", "error");
    else {
      showToast("Abonnement réussi", "success");
      loadData();
    }
  };

  const handleUnfollow = async (userId) => {
    const { error } = await unfollowUser(userId);
    if (error) showToast("Impossible de se désabonner", "error");
    else {
      showToast("Désabonnement effectué", "info");
      loadData();
    }
  };

  const handleAccept = async (followId) => {
    const { error } = await acceptFriendRequest(followId);
    if (error) showToast("Erreur", "error");
    else {
      showToast("Demande acceptée", "success");
      loadData();
    }
  };

  const handleReject = async (followId) => {
    const { error } = await rejectFriendRequest(followId);
    if (error) showToast("Erreur", "error");
    else {
      showToast("Demande refusée", "info");
      loadData();
    }
  };

  const tabs = [
    { id: "friends", label: "Amis", icon: Users },
    { id: "followers", label: "Abonnés", icon: UserPlus },
    { id: "following", label: "Abonnements", icon: UserMinus },
    { id: "requests", label: "Demandes", icon: UserPlus },
  ];

  const renderUser = (user, type) => {
    if (!user) return null;
    const name = user.display_name || "Membre";
    const handle = user.handle || "";
    const flag = user.flag || "🌍";
    const uid = user.user_id || user.follower_id;

    return (
      <div
        key={uid || user.followId}
        className="flex items-center justify-between p-3 rounded-2xl border"
        style={{
          background: "rgba(255,255,255,0.03)",
          borderColor: COLORS.border,
        }}
      >
        <div className="flex items-center gap-3 min-w-0">
          <div
            className="w-11 h-11 rounded-full flex items-center justify-center text-lg shrink-0"
            style={{ background: "rgba(217,174,82,0.2)" }}
          >
            {flag}
          </div>
          <div className="min-w-0">
            <p className="font-semibold text-sm truncate" style={{ color: COLORS.ivory }}>
              {name}
            </p>
            <p className="text-xs truncate" style={{ color: COLORS.muted }}>
              {handle}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {type === "following" && (
            <button
              onClick={() => handleUnfollow(uid)}
              className="px-3 py-1.5 rounded-full text-xs font-medium border transition hover:border-red-400"
              style={{ borderColor: COLORS.border, color: COLORS.muted }}
            >
              Se désabonner
            </button>
          )}
          {type === "followers" && (
            <button
              onClick={() => handleFollow(uid)}
              className="px-3 py-1.5 rounded-full text-xs font-medium transition"
              style={{
                background: "rgba(217,174,82,0.2)",
                color: COLORS.gold,
              }}
            >
              Suivre
            </button>
          )}
          {type === "requests" && (
            <>
              <button
                onClick={() => handleAccept(user.followId)}
                className="p-2 rounded-full transition hover:bg-green-500/20"
                style={{ color: "#4ade80" }}
                title="Accepter"
              >
                <Check size={18} />
              </button>
              <button
                onClick={() => handleReject(user.followId)}
                className="p-2 rounded-full transition hover:bg-red-500/20"
                style={{ color: "#f87171" }}
                title="Refuser"
              >
                <X size={18} />
              </button>
            </>
          )}
        </div>
      </div>
    );
  };

  const renderContent = () => {
    if (loading) {
      return (
        <div className="text-center py-12" style={{ color: COLORS.muted }}>
          <div className="text-3xl mb-3 animate-pulse">⏳</div>
          Chargement...
        </div>
      );
    }

    let list = [];
    let type = "";
    let emptyMsg = "";

    switch (activeSubTab) {
      case "friends":
        list = friends;
        type = "friends";
        emptyMsg = "Aucun ami pour le moment. Envoyez des demandes !";
        break;
      case "followers":
        list = followers;
        type = "followers";
        emptyMsg = "Aucun abonné pour le moment.";
        break;
      case "following":
        list = following;
        type = "following";
        emptyMsg = "Vous ne suivez personne encore.";
        break;
      case "requests":
        list = pending;
        type = "requests";
        emptyMsg = "Aucune demande en attente.";
        break;
      default:
        break;
    }

    if (list.length === 0) {
      return (
        <div className="text-center py-16" style={{ color: COLORS.muted }}>
          <Users size={40} className="mx-auto mb-3 opacity-40" />
          <p>{emptyMsg}</p>
        </div>
      );
    }

    return (
      <div className="space-y-2">
        {list.map((item) => renderUser(item, type))}
      </div>
    );
  };

  return (
    <div className="flex flex-col gap-5 max-w-2xl mx-auto w-full pb-20">
      <h2 className="text-xl font-bold" style={{ color: COLORS.ivory }}>
        Communauté
      </h2>

      <div className="flex gap-2 overflow-x-auto pb-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const active = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id)}
              className="flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-medium transition whitespace-nowrap border"
              style={{
                background: active ? "rgba(217,174,82,0.2)" : "rgba(255,255,255,0.03)",
                borderColor: active ? COLORS.borderGold : COLORS.border,
                color: active ? COLORS.gold : COLORS.muted,
              }}
            >
              <Icon size={14} />
              {tab.label}
            </button>
          );
        })}
      </div>

      {renderContent()}
    </div>
  );
}
