import { useState, useRef, useEffect, useCallback } from "react";
import {
  X,
  Camera,
  SwitchCamera,
  Square,
  Music,
  Check,
  RotateCcw,
  Mic,
  MicOff,
  Sparkles,
} from "lucide-react";
import { COLORS } from "../theme.js";
import { useToast } from "./ToastContext.jsx";

const MAX_DURATION_SEC = 60;
const COUNTDOWN_FROM = 3;

/** Filtres visuels (CSS filter) — appliqués à l’aperçu et gravés dans l’enregistrement via canvas */
export const VIDEO_FILTERS = [
  { id: "none", label: "Normal", css: "none", emoji: "○" },
  { id: "clarte", label: "Clarté", css: "contrast(1.15) brightness(1.05) saturate(1.1)", emoji: "✨" },
  { id: "chaud", label: "Chaud", css: "sepia(0.25) saturate(1.3) brightness(1.05)", emoji: "🌅" },
  { id: "froid", label: "Froid", css: "saturate(0.85) hue-rotate(15deg) brightness(1.05)", emoji: "❄️" },
  { id: "vintage", label: "Vintage", css: "sepia(0.45) contrast(1.1) brightness(0.95)", emoji: "📷" },
  { id: "noirblanc", label: "N&B", css: "grayscale(1) contrast(1.15)", emoji: "⬛" },
  { id: "cinema", label: "Cinéma", css: "contrast(1.25) saturate(0.9) brightness(0.95)", emoji: "🎬" },
  { id: "neon", label: "Néon", css: "contrast(1.3) saturate(1.6) brightness(1.1)", emoji: "💜" },
  { id: "doux", label: "Doux", css: "brightness(1.1) contrast(0.9) saturate(0.95)", emoji: "☁️" },
  { id: "dramatic", label: "Dramatique", css: "contrast(1.4) brightness(0.9) saturate(1.2)", emoji: "🔥" },
];

/**
 * Enregistrement caméra + filtres + choix de son.
 * onComplete({ blob, durationSec, sound, mimeType, filterId })
 */
export function VideoRecorder({ sounds = [], onComplete, onClose }) {
  const { showToast } = useToast();
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const chunksRef = useRef([]);
  const streamRef = useRef(null);
  const canvasStreamRef = useRef(null);
  const timerRef = useRef(null);
  const soundAudioRef = useRef(null);
  const rafRef = useRef(null);
  const filterIdRef = useRef("none");

  const [facingMode, setFacingMode] = useState("user");
  const [ready, setReady] = useState(false);
  const [recording, setRecording] = useState(false);
  const [countdown, setCountdown] = useState(null);
  const [elapsed, setElapsed] = useState(0);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [recordedBlob, setRecordedBlob] = useState(null);
  const [recordedDuration, setRecordedDuration] = useState(0);
  const [selectedSound, setSelectedSound] = useState(null);
  const [showSounds, setShowSounds] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [filterId, setFilterId] = useState("none");
  const [micEnabled, setMicEnabled] = useState(true);
  const [error, setError] = useState(null);

  const activeFilter = VIDEO_FILTERS.find((f) => f.id === filterId) || VIDEO_FILTERS[0];

  useEffect(() => {
    filterIdRef.current = filterId;
  }, [filterId]);

  const stopStream = useCallback(() => {
    if (rafRef.current) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (canvasStreamRef.current) {
      canvasStreamRef.current.getTracks().forEach((t) => t.stop());
      canvasStreamRef.current = null;
    }
  }, []);

  /** Boucle canvas : dessine la vidéo avec le filtre actif (pour preview + enregistrement) */
  const startCanvasLoop = useCallback(() => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;

    const ctx = canvas.getContext("2d", { alpha: false });

    const draw = () => {
      if (!videoRef.current || !canvasRef.current) return;
      const v = videoRef.current;
      const c = canvasRef.current;
      if (v.readyState >= 2) {
        if (c.width !== v.videoWidth || c.height !== v.videoHeight) {
          c.width = v.videoWidth || 720;
          c.height = v.videoHeight || 1280;
        }
        const f =
          VIDEO_FILTERS.find((x) => x.id === filterIdRef.current)?.css || "none";
        ctx.filter = f;
        // Miroir pour caméra frontale
        if (facingMode === "user") {
          ctx.save();
          ctx.translate(c.width, 0);
          ctx.scale(-1, 1);
          ctx.drawImage(v, 0, 0, c.width, c.height);
          ctx.restore();
        } else {
          ctx.drawImage(v, 0, 0, c.width, c.height);
        }
        ctx.filter = "none";
      }
      rafRef.current = requestAnimationFrame(draw);
    };

    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    rafRef.current = requestAnimationFrame(draw);
  }, [facingMode]);

  const startCamera = useCallback(async () => {
    setError(null);
    setReady(false);
    stopStream();
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode,
          width: { ideal: 1080 },
          height: { ideal: 1920 },
        },
        audio: micEnabled,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(() => {});
      }
      // Attendre les dimensions vidéo puis démarrer le canvas
      const onMeta = () => {
        startCanvasLoop();
        // Stream canvas pour l’enregistrement (filtre inclus)
        if (canvasRef.current) {
          const fps = 30;
          const canvasStream = canvasRef.current.captureStream(fps);
          // Ajouter la piste audio du micro si présente
          const audioTracks = stream.getAudioTracks();
          audioTracks.forEach((t) => canvasStream.addTrack(t));
          canvasStreamRef.current = canvasStream;
        }
        setReady(true);
      };
      if (videoRef.current) {
        if (videoRef.current.readyState >= 1) onMeta();
        else videoRef.current.onloadedmetadata = onMeta;
      }
    } catch (e) {
      console.error(e);
      setError(
        e.name === "NotAllowedError"
          ? "Autorise l’accès à la caméra et au micro dans ton navigateur."
          : "Caméra indisponible sur cet appareil."
      );
    }
  }, [facingMode, micEnabled, stopStream, startCanvasLoop]);

  useEffect(() => {
    if (!previewUrl) startCamera();
    return () => {
      stopStream();
      if (timerRef.current) clearInterval(timerRef.current);
      if (soundAudioRef.current) {
        soundAudioRef.current.pause();
        soundAudioRef.current = null;
      }
      if (previewUrl) URL.revokeObjectURL(previewUrl);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [facingMode, micEnabled]);

  const playSoundPreview = (sound) => {
    if (soundAudioRef.current) {
      soundAudioRef.current.pause();
      soundAudioRef.current = null;
    }
    if (!sound?.audio_url) return;
    const audio = new Audio(sound.audio_url);
    audio.loop = true;
    audio.volume = 0.85;
    audio.play().catch(() => {});
    soundAudioRef.current = audio;
  };

  const stopSoundPreview = () => {
    if (soundAudioRef.current) {
      soundAudioRef.current.pause();
      soundAudioRef.current.currentTime = 0;
      soundAudioRef.current = null;
    }
  };

  const pickSound = (sound) => {
    setSelectedSound(sound);
    setShowSounds(false);
    if (!recording && !previewUrl) playSoundPreview(sound);
  };

  const startRecording = async () => {
    const recordStream = canvasStreamRef.current || streamRef.current;
    if (!recordStream || recording) return;

    for (let i = COUNTDOWN_FROM; i > 0; i--) {
      setCountdown(i);
      await new Promise((r) => setTimeout(r, 1000));
    }
    setCountdown(null);

    chunksRef.current = [];
    const mimeCandidates = [
      "video/webm;codecs=vp9,opus",
      "video/webm;codecs=vp8,opus",
      "video/webm",
      "video/mp4",
    ];
    const mimeType =
      mimeCandidates.find((m) => window.MediaRecorder?.isTypeSupported(m)) ||
      "";

    try {
      const recorder = new MediaRecorder(
        recordStream,
        mimeType ? { mimeType, videoBitsPerSecond: 2_500_000 } : undefined
      );
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) chunksRef.current.push(e.data);
      };

      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, {
          type: recorder.mimeType || "video/webm",
        });
        const url = URL.createObjectURL(blob);
        setRecordedBlob(blob);
        setPreviewUrl(url);
        setRecordedDuration(elapsed);
        stopStream();
        stopSoundPreview();
      };

      if (selectedSound?.audio_url) playSoundPreview(selectedSound);

      recorder.start(200);
      setRecording(true);
      setElapsed(0);

      timerRef.current = setInterval(() => {
        setElapsed((prev) => {
          const next = prev + 1;
          if (next >= MAX_DURATION_SEC) stopRecording();
          return next;
        });
      }, 1000);
    } catch (e) {
      console.error(e);
      showToast("Impossible de démarrer l’enregistrement", "error");
      setCountdown(null);
    }
  };

  const stopRecording = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (
      mediaRecorderRef.current &&
      mediaRecorderRef.current.state !== "inactive"
    ) {
      mediaRecorderRef.current.stop();
    }
    setRecording(false);
    stopSoundPreview();
  };

  const retake = () => {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(null);
    setRecordedBlob(null);
    setRecordedDuration(0);
    setElapsed(0);
    startCamera();
    if (selectedSound) playSoundPreview(selectedSound);
  };

  const confirm = () => {
    if (!recordedBlob) return;
    stopSoundPreview();
    onComplete?.({
      blob: recordedBlob,
      durationSec: recordedDuration || elapsed,
      sound: selectedSound,
      mimeType: recordedBlob.type || "video/webm",
      filterId,
    });
  };

  const flipCamera = () => {
    if (recording) return;
    setFacingMode((m) => (m === "user" ? "environment" : "user"));
  };

  const formatTime = (s) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
  };

  return (
    <div className="fixed inset-0 z-[70] bg-black flex flex-col">
      {/* Zone vidéo */}
      <div className="relative flex-1 bg-black overflow-hidden">
        {/* Vidéo source (cachée) — alimente le canvas */}
        <video
          ref={videoRef}
          playsInline
          muted
          autoPlay
          className="absolute opacity-0 pointer-events-none w-px h-px"
        />

        {/* Canvas = aperçu filtré (et source d’enregistrement) */}
        {!previewUrl ? (
          <canvas
            ref={canvasRef}
            className="absolute inset-0 w-full h-full object-cover"
            style={{ objectFit: "cover" }}
          />
        ) : (
          <video
            src={previewUrl}
            playsInline
            controls
            loop
            className="absolute inset-0 w-full h-full object-cover"
          />
        )}

        {countdown !== null && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/40 z-10">
            <span className="text-8xl font-black text-white drop-shadow-lg animate-pulse">
              {countdown}
            </span>
          </div>
        )}

        {error && (
          <div className="absolute inset-0 flex items-center justify-center p-6 z-10">
            <div
              className="rounded-2xl p-5 text-center max-w-sm border"
              style={{ background: COLORS.surface, borderColor: COLORS.border }}
            >
              <Camera size={36} className="mx-auto mb-3 text-red-400" />
              <p className="text-white text-sm mb-4">{error}</p>
              <button
                onClick={startCamera}
                className="px-4 py-2 rounded-xl text-sm font-bold"
                style={{ background: COLORS.gold, color: COLORS.bg }}
              >
                Réessayer
              </button>
            </div>
          </div>
        )}

        {/* Top bar */}
        <div className="absolute top-0 left-0 right-0 p-4 flex items-center justify-between z-20 bg-gradient-to-b from-black/60 to-transparent">
          <button
            onClick={() => {
              stopSoundPreview();
              stopStream();
              onClose?.();
            }}
            className="p-2 rounded-full bg-black/40 text-white"
          >
            <X size={22} />
          </button>

          {recording && (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-red-600/90 text-white text-sm font-mono font-bold">
              <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
              {formatTime(elapsed)} / {formatTime(MAX_DURATION_SEC)}
            </div>
          )}

          {!recording && !previewUrl && (
            <div className="flex gap-2">
              <button
                onClick={() => setMicEnabled((v) => !v)}
                className="p-2 rounded-full bg-black/40 text-white"
                title={micEnabled ? "Micro activé" : "Micro coupé"}
              >
                {micEnabled ? <Mic size={20} /> : <MicOff size={20} />}
              </button>
              <button
                onClick={flipCamera}
                className="p-2 rounded-full bg-black/40 text-white"
                title="Changer de caméra"
              >
                <SwitchCamera size={20} />
              </button>
            </div>
          )}
        </div>

        {/* Badges son + filtre */}
        {!previewUrl && (
          <div className="absolute top-16 left-4 right-4 z-20 flex flex-wrap gap-2">
            {selectedSound && (
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-black/50 text-white text-xs max-w-full">
                <Music size={14} className="text-yellow-400 shrink-0" />
                <span className="truncate">
                  {selectedSound.title}
                  {selectedSound.artist ? ` — ${selectedSound.artist}` : ""}
                </span>
              </div>
            )}
            {filterId !== "none" && (
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-black/50 text-white text-xs">
                <Sparkles size={14} className="text-purple-300 shrink-0" />
                <span>{activeFilter.label}</span>
              </div>
            )}
          </div>
        )}

        {/* Barre de filtres horizontale */}
        {!previewUrl && !recording && (
          <div className="absolute bottom-0 left-0 right-0 z-20 pb-2">
            <div className="flex gap-2 overflow-x-auto px-3 py-2 scrollbar-hide">
              {VIDEO_FILTERS.map((f) => {
                const active = filterId === f.id;
                return (
                  <button
                    key={f.id}
                    onClick={() => setFilterId(f.id)}
                    className="flex flex-col items-center gap-1 shrink-0"
                  >
                    <div
                      className="w-14 h-14 rounded-xl overflow-hidden border-2 flex items-center justify-center text-lg"
                      style={{
                        borderColor: active ? COLORS.gold : "rgba(255,255,255,0.25)",
                        background: "rgba(0,0,0,0.45)",
                        filter: f.css === "none" ? "none" : f.css,
                        boxShadow: active
                          ? `0 0 0 2px ${COLORS.gold}`
                          : "none",
                      }}
                    >
                      <span style={{ filter: "none" }}>{f.emoji}</span>
                    </div>
                    <span
                      className="text-[10px] font-medium"
                      style={{
                        color: active ? COLORS.gold : "rgba(255,255,255,0.75)",
                      }}
                    >
                      {f.label}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Bottom controls */}
      <div
        className="p-5 pb-8 flex flex-col gap-4 border-t"
        style={{ background: "#0a0a0a", borderColor: "rgba(255,255,255,0.08)" }}
      >
        {!previewUrl ? (
          <>
            <div className="flex gap-2">
              <button
                onClick={() => setShowSounds(true)}
                disabled={recording}
                className="flex items-center gap-3 flex-1 p-3 rounded-xl border text-left disabled:opacity-50"
                style={{
                  background: "rgba(255,255,255,0.04)",
                  borderColor: selectedSound
                    ? COLORS.borderGold
                    : COLORS.border,
                }}
              >
                <Music size={18} style={{ color: COLORS.gold }} />
                <div className="min-w-0 flex-1">
                  <p className="text-white text-sm font-medium truncate">
                    {selectedSound ? selectedSound.title : "Choisir un son"}
                  </p>
                  <p className="text-xs truncate" style={{ color: COLORS.muted }}>
                    {selectedSound
                      ? selectedSound.artist || "Son BAARO"
                      : "Optionnel"}
                  </p>
                </div>
              </button>
              <button
                onClick={() => setShowFilters((v) => !v)}
                disabled={recording}
                className="flex flex-col items-center justify-center px-4 rounded-xl border disabled:opacity-50"
                style={{
                  background:
                    filterId !== "none"
                      ? "rgba(139,92,246,0.2)"
                      : "rgba(255,255,255,0.04)",
                  borderColor:
                    filterId !== "none"
                      ? "rgba(139,92,246,0.5)"
                      : COLORS.border,
                }}
                title="Filtres"
              >
                <Sparkles size={18} className="text-purple-300" />
                <span className="text-[10px] text-white mt-0.5">Filtres</span>
              </button>
            </div>

            <div className="flex items-center justify-center gap-8">
              <div className="w-12" />
              {!recording ? (
                <button
                  onClick={startRecording}
                  disabled={!ready || countdown !== null}
                  className="w-20 h-20 rounded-full border-4 border-white flex items-center justify-center disabled:opacity-40 transition active:scale-95"
                >
                  <div className="w-14 h-14 rounded-full bg-red-500" />
                </button>
              ) : (
                <button
                  onClick={stopRecording}
                  className="w-20 h-20 rounded-full border-4 border-white flex items-center justify-center transition active:scale-95"
                >
                  <Square size={28} className="text-red-500 fill-red-500" />
                </button>
              )}
              <div
                className="w-12 text-center text-xs"
                style={{ color: COLORS.muted }}
              >
                {ready ? "Prêt" : "…"}
              </div>
            </div>
            <p className="text-center text-xs" style={{ color: COLORS.muted }}>
              Max {MAX_DURATION_SEC}s • Filtre gravé dans la vidéo • Son lié à la
              lecture
            </p>
          </>
        ) : (
          <div className="flex items-center justify-center gap-6">
            <button
              onClick={retake}
              className="flex flex-col items-center gap-1 text-white"
            >
              <div className="w-14 h-14 rounded-full border border-white/20 flex items-center justify-center">
                <RotateCcw size={22} />
              </div>
              <span className="text-xs">Reprendre</span>
            </button>
            <button
              onClick={confirm}
              className="flex flex-col items-center gap-1"
            >
              <div
                className="w-16 h-16 rounded-full flex items-center justify-center"
                style={{ background: COLORS.gold }}
              >
                <Check size={28} style={{ color: COLORS.bg }} />
              </div>
              <span className="text-xs text-white font-medium">Utiliser</span>
            </button>
          </div>
        )}
      </div>

      {/* Picker sons */}
      {showSounds && (
        <div className="absolute inset-0 z-30 flex items-end bg-black/80">
          <div
            className="w-full max-h-[55vh] rounded-t-3xl p-4 overflow-y-auto"
            style={{ background: COLORS.surface }}
          >
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-white">Choisir un son</h3>
              <button
                onClick={() => setShowSounds(false)}
                className="text-gray-400"
              >
                <X size={22} />
              </button>
            </div>

            <button
              onClick={() => {
                setSelectedSound(null);
                stopSoundPreview();
                setShowSounds(false);
              }}
              className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 text-left mb-1"
            >
              <div className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center">
                <Mic size={16} className="text-white" />
              </div>
              <div>
                <p className="text-white text-sm font-medium">
                  Sans son (audio original)
                </p>
                <p className="text-xs text-gray-400">Micro uniquement</p>
              </div>
            </button>

            {sounds.length === 0 ? (
              <p className="text-gray-500 text-center py-8 text-sm">
                Aucun son en base. Exécute{" "}
                <code className="text-yellow-400">
                  supabase-add-videos-sounds.sql
                </code>
              </p>
            ) : (
              sounds.map((s) => (
                <button
                  key={s.id}
                  onClick={() => pickSound(s)}
                  className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 text-left"
                >
                  <div
                    className="w-9 h-9 rounded-full flex items-center justify-center"
                    style={{
                      background:
                        selectedSound?.id === s.id
                          ? "rgba(217,174,82,0.3)"
                          : "rgba(255,255,255,0.08)",
                    }}
                  >
                    <Music
                      size={16}
                      style={{
                        color:
                          selectedSound?.id === s.id ? COLORS.gold : "#fff",
                      }}
                    />
                  </div>
                  <div className="min-w-0">
                    <p className="text-white text-sm font-medium truncate">
                      {s.title}
                    </p>
                    <p className="text-xs text-gray-400 truncate">
                      {s.artist || "Son BAARO"}
                      {s.duration_sec ? ` • ${s.duration_sec}s` : ""}
                    </p>
                  </div>
                  {selectedSound?.id === s.id && (
                    <Check size={16} className="ml-auto text-yellow-400" />
                  )}
                </button>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
