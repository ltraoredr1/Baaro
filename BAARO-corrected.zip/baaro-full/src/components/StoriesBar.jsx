import { useState, useEffect, useCallback } from "react";
import { supabase } from "../supabaseClient";
import { Plus } from "lucide-react";
import { COLORS } from "../theme.js";

export function StoriesBar({ onOpenStory, onCreateStory, refreshKey = 0 }) {
  const [groups, setGroups] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadStories = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const { data, error: qErr } = await supabase
        .from("stories")
        .select(`
          id, media_url, media_type, text_overlay, filter_used, created_at, author_id, expires_at,
          profiles:author_id (display_name, handle, flag, avatar_url)
        `)
        .gt("expires_at", new Date().toISOString())
        .order("created_at", { ascending: false })
        .limit(100);

      if (qErr) {
        // Fallback si colonnes manquantes (schéma ancien)
        console.warn("stories query error, fallback:", qErr.message);
        const { data: fallback, error: fbErr } = await supabase
          .from("stories")
          .select("id, author_id, created_at, text")
          .order("created_at", { ascending: false })
          .limit(50);

        if (fbErr) throw fbErr;

        const map = {};
        (fallback || []).forEach((s) => {
          if (!map[s.author_id]) {
            map[s.author_id] = {
              authorId: s.author_id,
              author: null,
              stories: [],
            };
          }
          map[s.author_id].stories.push({
            ...s,
            media_url: null,
            media_type: "text",
            text_overlay: s.text,
          });
        });
        setGroups(Object.values(map));
        setError(
          "Schéma stories incomplet — exécute supabase-fix-stories.sql"
        );
        return;
      }

      const map = {};
      (data || []).forEach((s) => {
        if (!s.media_url && !s.text_overlay) return;
        if (!map[s.author_id]) {
          map[s.author_id] = {
            authorId: s.author_id,
            author: s.profiles,
            stories: [],
          };
        }
        map[s.author_id].stories.push(s);
      });
      setGroups(Object.values(map));
    } catch (e) {
      console.error(e);
      setError(e.message || "Impossible de charger les stories");
      setGroups([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadStories();
  }, [loadStories, refreshKey]);

  if (loading) {
    return (
      <div className="flex gap-3 px-3 py-3 overflow-x-auto">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="flex flex-col items-center gap-1.5 shrink-0">
            <div className="w-16 h-16 rounded-full bg-white/10 animate-pulse" />
            <div className="w-10 h-2 rounded bg-white/10 animate-pulse" />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="border-b border-white/5">
      {error && (
        <p className="px-3 pt-2 text-[10px] text-amber-400/90 truncate">
          ⚠️ {error}
        </p>
      )}
      <div className="flex gap-3 overflow-x-auto px-3 py-3 no-scrollbar min-h-[100px]">
        {/* Créer sa story */}
        <button
          onClick={onCreateStory}
          className="flex-shrink-0 flex flex-col items-center gap-1.5"
        >
          <div
            className="w-16 h-16 rounded-full border-2 border-dashed flex items-center justify-center"
            style={{ borderColor: COLORS.gold }}
          >
            <Plus size={22} style={{ color: COLORS.gold }} />
          </div>
          <span className="text-[11px] font-semibold text-yellow-400">Ta story</span>
        </button>

        {groups.length === 0 && !error && (
          <div className="flex items-center text-xs text-gray-500 px-2">
            Aucune story active — sois le premier !
          </div>
        )}

        {groups.map((g) => (
          <button
            key={g.authorId}
            onClick={() => onOpenStory?.(g)}
            className="flex-shrink-0 flex flex-col items-center gap-1.5"
          >
            <div className="w-16 h-16 rounded-full p-[2px] bg-gradient-to-tr from-yellow-400 via-pink-500 to-purple-500">
              <div className="w-full h-full rounded-full overflow-hidden border-2 border-black bg-gray-800 flex items-center justify-center">
                {g.author?.avatar_url ? (
                  <img
                    src={g.author.avatar_url}
                    className="w-full h-full object-cover"
                    alt=""
                  />
                ) : (
                  <span className="text-xl">{g.author?.flag || "🌍"}</span>
                )}
              </div>
            </div>
            <span className="text-[10px] text-gray-300 max-w-[64px] truncate">
              {g.author?.handle || "membre"}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}
