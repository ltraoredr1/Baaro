// Fallback mock — ne plus utiliser pour de la vraie logique.
// Conservé uniquement pour compatibilité temporaire avec d'éventuels imports.

export const STABLE_USERS = [];

export function getUserById(id) {
  return null;
}
