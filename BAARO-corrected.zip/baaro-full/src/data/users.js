// Fallback vide — les vrais utilisateurs viennent de la table profiles (Supabase).
export const STABLE_USERS = [];
