import { useState, useEffect } from "react";
import {
  Bell,
  CheckCheck,
  Trash2,
  X,
  Coins,
  Heart,
  MessageSquare,
  Award,
  Sparkles,
  UserPlus,
} from "lucide-react";
import { COLORS } from "../theme.js";
import { supabase } from "../supabaseClient.js";

function iconFor(message = "") {
  const m = message.toLowerCase();
  if (m.includes("abonné") || m.includes("abonne")) return UserPlus;
  if (m.includes("aime") || m.includes("like")) return Heart;
  if (m.includes("message")) return MessageSquare;
  if (m.includes("point") || m.includes("pts") || m.includes("baro")) return Coins;
  if (m.includes("badge")) return Award;
  return Sparkles;
}

function timeAgo(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  const sec = Math.floor((Date.now() - d.getTime()) / 1000);
  if (sec < 60) return "À l'instant";
  if (sec < 3600) return `Il y a ${Math.floor(sec / 60)} min`;
  if (sec < 86400) return `Il y a ${Math.floor(sec / 3600)} h`;
  if (sec < 172800) return "Hier";
  return d.toLocaleDateString("fr-FR");
}

export function NotificationDrawer({ isOpen, onClose, userId }) {
  const [notifs, setNotifs] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!isOpen || !userId) return;
    let cancelled = false;

    (async () => {
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from("notifications")
          .select("id, message, read, created_at")
          .eq("user_id", userId)
          .order("created_at", { ascending: false })
          .limit(40);
        if (!cancelled) {
          if (error) {
            console.warn("notifications:", error.message);
            setNotifs([]);
          } else {
            setNotifs(data || []);
          }
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [isOpen, userId]);

  if (!isOpen) return null;

  const markAllRead = async () => {
    setNotifs((prev) => prev.map((n) => ({ ...n, read: true })));
    if (!userId) return;
    await supabase
      .from("notifications")
      .update({ read: true })
      .eq("user_id", userId)
      .eq("read", false);
  };

  const clearAll = async () => {
    setNotifs([]);
    if (!userId) return;
    await supabase.from("notifications").delete().eq("user_id", userId);
  };

  const unreadCount = notifs.filter((n) => !n.read).length;

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-sm h-full border-l shadow-2xl p-5 flex flex-col"
        style={{ borderColor: COLORS.borderGold, background: COLORS.surface }}
      >
        <div className="flex items-center justify-between pb-4 border-b" style={{ borderColor: COLORS.border }}>
          <div className="flex items-center gap-2">
            <Bell size={20} style={{ color: COLORS.gold }} />
            <h3 className="text-base font-bold" style={{ color: COLORS.ivory }}>
              Notifications
            </h3>
            {unreadCount > 0 && (
              <span
                className="text-[10px] px-2 py-0.5 rounded-full font-bold"
                style={{ background: COLORS.teal, color: COLORS.bg }}
              >
                {unreadCount}
              </span>
            )}
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg border"
            style={{ borderColor: COLORS.border, color: COLORS.ivory }}
          >
            <X size={16} />
          </button>
        </div>

        <div className="flex gap-2 py-3">
          <button
            onClick={markAllRead}
            className="flex-1 text-[11px] py-2 rounded-lg font-bold flex items-center justify-center gap-1 border"
            style={{ borderColor: COLORS.border, color: COLORS.muted }}
          >
            <CheckCheck size={14} /> Tout lu
          </button>
          <button
            onClick={clearAll}
            className="flex-1 text-[11px] py-2 rounded-lg font-bold flex items-center justify-center gap-1 border"
            style={{ borderColor: COLORS.border, color: "#F87171" }}
          >
            <Trash2 size={14} /> Vider
          </button>
        </div>

        <div className="flex-1 overflow-y-auto space-y-2">
          {loading && (
            <p className="text-center text-xs py-8" style={{ color: COLORS.muted }}>
              Chargement…
            </p>
          )}
          {!loading && notifs.length === 0 && (
            <p className="text-center text-xs py-8" style={{ color: COLORS.muted }}>
              Aucune notification
            </p>
          )}
          {notifs.map((n) => {
            const Icon = iconFor(n.message);
            return (
              <div
                key={n.id}
                className="p-3 rounded-xl border flex gap-3"
                style={{
                  background: n.read ? COLORS.surface2 : `${COLORS.gold}12`,
                  borderColor: COLORS.border,
                }}
              >
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center shrink-0"
                  style={{ background: `${COLORS.gold}22`, color: COLORS.gold }}
                >
                  <Icon size={16} />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-medium" style={{ color: COLORS.ivory }}>
                    {n.message}
                  </p>
                  <p className="text-[10px] mt-1" style={{ color: COLORS.muted }}>
                    {timeAgo(n.created_at)}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export default NotificationDrawer;
