BAARO - Correctif système d'abonnements (follows)
=================================================

Date : 09 août 2026

STRUCTURE RÉELLE UTILISÉE (vérifiée dans ta base Supabase) :
-----------------------------------------------------------
id           uuid
follower_id  uuid   → celui qui suit
following_id uuid   → celui qui est suivi
status       text   ('accepted' | 'pending' | 'rejected')
is_friend    boolean
created_at   timestamptz

FICHIERS CORRIGÉS
-----------------
1. supabaseClient.js     → à placer dans src/
2. ProfileModal.jsx      → à placer dans src/components/
3. FollowButton.jsx      → à placer dans src/components/

Ces fichiers utilisent correctement :
- following_id (et non followed_id)
- status = 'accepted'
- is_friend

INSTALLATION
------------
cp BAARO-FIX-FOLLOWS/supabaseClient.js   src/
cp BAARO-FIX-FOLLOWS/ProfileModal.jsx    src/components/
cp BAARO-FIX-FOLLOWS/FollowButton.jsx    src/components/

Ensuite teste le bouton "S'abonner".
