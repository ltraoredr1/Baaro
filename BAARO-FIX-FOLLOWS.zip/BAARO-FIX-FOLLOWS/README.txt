BAARO - Correctif critique système d'abonnements (follows)
=========================================================

Date : 09 août 2026

PROBLÈME CORRIGÉ
----------------
Incohérence de colonnes dans la table "follows" :
- Schéma officiel (supabase-schema.sql) : followed_id
- Certains fichiers utilisaient following_id + des colonnes inexistantes (status, is_friend)

FICHIERS CORRIGÉS
-----------------
1. supabaseClient.js     → à placer dans src/
2. ProfileModal.jsx      → à placer dans src/components/
3. FollowButton.jsx      → à placer dans src/components/

INSTALLATION
------------
1. Remplace les fichiers existants par ceux de ce dossier
2. Vérifie dans Supabase que la table follows a bien les colonnes :
   follower_id | followed_id | created_at

3. Teste le bouton "S'abonner" sur un profil

NOTES
-----
- Les fonctions d'amis (sendFriendRequest, is_friend, status) ont été retirées
  car ces colonnes n'existent pas dans le schéma actuel.
- On pourra les réintroduire proprement avec une migration SQL dédiée plus tard.
