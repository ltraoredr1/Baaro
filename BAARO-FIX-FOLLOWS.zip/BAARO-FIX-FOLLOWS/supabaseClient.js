import { createClient } from "@supabase/supabase-js";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || "https://placeholder-project.supabase.co";
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || "placeholder-anon-key";

if (!import.meta.env.VITE_SUPABASE_URL || !import.meta.env.VITE_SUPABASE_ANON_KEY) {
  console.warn(
    "Variables Supabase manquantes : VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY. Mode démonstration actif."
  );
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// ========== ABONNÉS / ABONNEMENTS ==========
// Schéma officiel (supabase-schema.sql) :
//   follower_id  → celui qui suit
//   followed_id  → celui qui est suivi
//   primary key (follower_id, followed_id)
// Pas de colonnes status / is_friend dans le schéma de base.

/**
 * Suivre un utilisateur
 * @param {string} targetUserId - ID de l'utilisateur à suivre (followed_id)
 */
export const followUser = async (targetUserId) => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error("Non connecté");
  if (!targetUserId) throw new Error("targetUserId manquant");
  if (user.id === targetUserId) throw new Error("Impossible de se suivre soi-même");

  const { data, error } = await supabase
    .from("follows")
    .insert({
      follower_id: user.id,
      followed_id: targetUserId,
    })
    .select()
    .maybeSingle();

  return { data, error };
};

/**
 * Se désabonner d'un utilisateur
 */
export const unfollowUser = async (targetUserId) => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error("Non connecté");

  const { error } = await supabase
    .from("follows")
    .delete()
    .eq("follower_id", user.id)
    .eq("followed_id", targetUserId);

  return { error };
};

/**
 * Vérifier si l'utilisateur connecté suit targetUserId
 */
export const isFollowing = async (targetUserId) => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user || !targetUserId) return false;

  const { count, error } = await supabase
    .from("follows")
    .select("*", { count: "exact", head: true })
    .eq("follower_id", user.id)
    .eq("followed_id", targetUserId);

  if (error) {
    console.error("isFollowing error:", error);
    return false;
  }

  return (count || 0) > 0;
};

/**
 * Liste des utilisateurs que je suis (mes abonnements)
 * Retourne un tableau d'IDs (followed_id)
 */
export const getFollowing = async () => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { data: [], error: null };

  const { data, error } = await supabase
    .from("follows")
    .select("followed_id")
    .eq("follower_id", user.id);

  return {
    data: (data || []).map((f) => f.followed_id),
    error,
  };
};

/**
 * Liste de mes abonnés
 * Retourne un tableau d'IDs (follower_id)
 */
export const getFollowers = async () => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { data: [], error: null };

  const { data, error } = await supabase
    .from("follows")
    .select("follower_id")
    .eq("followed_id", user.id);

  return {
    data: (data || []).map((f) => f.follower_id),
    error,
  };
};

/**
 * Compter les abonnés d'un utilisateur
 */
export const getFollowersCount = async (userId) => {
  if (!userId) return 0;
  const { count, error } = await supabase
    .from("follows")
    .select("*", { count: "exact", head: true })
    .eq("followed_id", userId);

  if (error) return 0;
  return count || 0;
};

/**
 * Compter les abonnements d'un utilisateur
 */
export const getFollowingCount = async (userId) => {
  if (!userId) return 0;
  const { count, error } = await supabase
    .from("follows")
    .select("*", { count: "exact", head: true })
    .eq("follower_id", userId);

  if (error) return 0;
  return count || 0;
};

// ========== PROFILS ==========

export const getAllUsers = async () => {
  const { data, error } = await supabase
    .from("profiles")
    .select("*")
    .order("created_at", { ascending: false });

  return { data, error };
};

export const getUserById = async (userId) => {
  const { data, error } = await supabase
    .from("profiles")
    .select("*")
    .eq("user_id", userId)
    .maybeSingle();

  return { data, error };
};
