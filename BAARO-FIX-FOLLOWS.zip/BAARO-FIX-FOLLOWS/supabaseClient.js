import { createClient } from "@supabase/supabase-js";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || "https://placeholder-project.supabase.co";
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || "placeholder-anon-key";

if (!import.meta.env.VITE_SUPABASE_URL || !import.meta.env.VITE_SUPABASE_ANON_KEY) {
  console.warn(
    "Variables Supabase manquantes : VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY. Mode démonstration actif."
  );
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// ========== ABONNÉS / ABONNEMENTS / AMIS ==========
// Structure RÉELLE de la table "follows" (vérifiée en base) :
//   id           uuid (PK)
//   follower_id  uuid  → celui qui suit
//   following_id uuid  → celui qui est suivi
//   status       text  ('accepted' | 'pending' | 'rejected')
//   is_friend    boolean
//   created_at   timestamptz

/**
 * Suivre un utilisateur
 * @param {string} targetUserId - ID de l'utilisateur à suivre (following_id)
 */
export const followUser = async (targetUserId) => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error("Non connecté");
  if (!targetUserId) throw new Error("targetUserId manquant");
  if (user.id === targetUserId) throw new Error("Impossible de se suivre soi-même");

  const { data, error } = await supabase
    .from("follows")
    .insert({
      follower_id: user.id,
      following_id: targetUserId,
      status: "accepted",
      is_friend: false,
    })
    .select()
    .maybeSingle();

  return { data, error };
};

/**
 * Se désabonner d'un utilisateur
 */
export const unfollowUser = async (targetUserId) => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error("Non connecté");

  const { error } = await supabase
    .from("follows")
    .delete()
    .eq("follower_id", user.id)
    .eq("following_id", targetUserId);

  return { error };
};

/**
 * Vérifier si l'utilisateur connecté suit targetUserId
 */
export const isFollowing = async (targetUserId) => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user || !targetUserId) return false;

  const { count, error } = await supabase
    .from("follows")
    .select("*", { count: "exact", head: true })
    .eq("follower_id", user.id)
    .eq("following_id", targetUserId)
    .eq("status", "accepted");

  if (error) {
    console.error("isFollowing error:", error);
    return false;
  }

  return (count || 0) > 0;
};

/**
 * Demander en ami
 */
export const sendFriendRequest = async (targetUserId) => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error("Non connecté");

  // Vérifie s'il existe déjà une relation dans l'autre sens
  const { data: existing } = await supabase
    .from("follows")
    .select("id, status")
    .eq("follower_id", targetUserId)
    .eq("following_id", user.id)
    .maybeSingle();

  if (existing) {
    const { data, error } = await supabase
      .from("follows")
      .update({ is_friend: true, status: "pending" })
      .eq("id", existing.id)
      .select()
      .single();
    return { data, error };
  }

  // Sinon on crée une nouvelle demande
  const { data, error } = await supabase
    .from("follows")
    .insert({
      follower_id: user.id,
      following_id: targetUserId,
      status: "pending",
      is_friend: true,
    })
    .select()
    .single();

  return { data, error };
};

/**
 * Accepter une demande d'ami
 */
export const acceptFriendRequest = async (followId) => {
  const { data, error } = await supabase
    .from("follows")
    .update({ status: "accepted", is_friend: true })
    .eq("id", followId)
    .select()
    .single();

  return { data, error };
};

/**
 * Refuser une demande d'ami
 */
export const rejectFriendRequest = async (followId) => {
  const { data, error } = await supabase
    .from("follows")
    .update({ status: "rejected", is_friend: false })
    .eq("id", followId)
    .select()
    .single();

  return { data, error };
};

/**
 * Liste des utilisateurs que je suis (mes abonnements)
 * Retourne un tableau d'IDs (following_id)
 */
export const getFollowing = async () => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { data: [], error: null };

  const { data, error } = await supabase
    .from("follows")
    .select("following_id")
    .eq("follower_id", user.id)
    .eq("status", "accepted");

  return {
    data: (data || []).map((f) => f.following_id),
    error,
  };
};

/**
 * Liste de mes abonnés
 * Retourne un tableau d'IDs (follower_id)
 */
export const getFollowers = async () => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { data: [], error: null };

  const { data, error } = await supabase
    .from("follows")
    .select("follower_id")
    .eq("following_id", user.id)
    .eq("status", "accepted");

  return {
    data: (data || []).map((f) => f.follower_id),
    error,
  };
};

/**
 * Liste de mes amis
 */
export const getFriends = async () => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { data: [], error: null };

  const { data, error } = await supabase
    .from("follows")
    .select("following_id")
    .eq("follower_id", user.id)
    .eq("is_friend", true)
    .eq("status", "accepted");

  return {
    data: (data || []).map((f) => f.following_id),
    error,
  };
};

/**
 * Demandes d'ami en attente (reçues)
 */
export const getPendingRequests = async () => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { data: [], error: null };

  const { data, error } = await supabase
    .from("follows")
    .select("id, follower_id")
    .eq("following_id", user.id)
    .eq("is_friend", true)
    .eq("status", "pending");

  return { data: data || [], error };
};

/**
 * Compter les abonnés d'un utilisateur
 */
export const getFollowersCount = async (userId) => {
  if (!userId) return 0;
  const { count, error } = await supabase
    .from("follows")
    .select("*", { count: "exact", head: true })
    .eq("following_id", userId)
    .eq("status", "accepted");

  if (error) return 0;
  return count || 0;
};

/**
 * Compter les abonnements d'un utilisateur
 */
export const getFollowingCount = async (userId) => {
  if (!userId) return 0;
  const { count, error } = await supabase
    .from("follows")
    .select("*", { count: "exact", head: true })
    .eq("follower_id", userId)
    .eq("status", "accepted");

  if (error) return 0;
  return count || 0;
};

// ========== PROFILS ==========

export const getAllUsers = async () => {
  const { data, error } = await supabase
    .from("profiles")
    .select("*")
    .order("created_at", { ascending: false });

  return { data, error };
};

export const getUserById = async (userId) => {
  const { data, error } = await supabase
    .from("profiles")
    .select("*")
    .eq("user_id", userId)
    .maybeSingle();

  return { data, error };
};
