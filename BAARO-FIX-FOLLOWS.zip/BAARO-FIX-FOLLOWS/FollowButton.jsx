import { useState, useEffect } from "react";
import { supabase } from "../supabaseClient";
import { useToast } from "./ToastContext";

/**
 * FollowButton — Aligné sur la structure RÉELLE de la table follows
 * Colonnes : id, follower_id, following_id, status, is_friend, created_at
 */
export default function FollowButton({ targetUserId, currentUserId }) {
  const [isFollowing, setIsFollowing] = useState(false);
  const [loading, setLoading] = useState(false);
  const { showToast } = useToast();

  useEffect(() => {
    if (!currentUserId || !targetUserId) return;

    const checkFollow = async () => {
      const { data, error } = await supabase
        .from("follows")
        .select("follower_id")
        .eq("follower_id", currentUserId)
        .eq("following_id", targetUserId)
        .eq("status", "accepted")
        .maybeSingle();

      if (!error) {
        setIsFollowing(!!data);
      }
    };

    checkFollow();

    // Temps réel
    const channel = supabase
      .channel(`follows:${targetUserId}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "follows",
          filter: `following_id=eq.${targetUserId}`,
        },
        () => {
          checkFollow();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [currentUserId, targetUserId]);

  const handleToggle = async () => {
    if (!currentUserId || !targetUserId || loading) return;
    setLoading(true);

    try {
      if (isFollowing) {
        const { error } = await supabase
          .from("follows")
          .delete()
          .eq("follower_id", currentUserId)
          .eq("following_id", targetUserId);

        if (error) throw error;

        setIsFollowing(false);
        showToast("Désabonné", "info");
      } else {
        const { error } = await supabase.from("follows").insert({
          follower_id: currentUserId,
          following_id: targetUserId,
          status: "accepted",
          is_friend: false,
        });

        if (error) throw error;

        setIsFollowing(true);
        showToast("Abonnement réussi !", "success");
      }
    } catch (error) {
      console.error("Erreur follow:", error);
      showToast("Erreur lors de l'action", "error");
    } finally {
      setLoading(false);
    }
  };

  // Ne pas afficher le bouton sur son propre profil
  if (currentUserId === targetUserId) return null;

  return (
    <button
      onClick={handleToggle}
      disabled={loading}
      className={`px-4 py-2 rounded-full font-medium transition-all duration-200 flex items-center gap-2 ${
        isFollowing
          ? "bg-gray-200 text-gray-800 hover:bg-red-100 hover:text-red-600"
          : "bg-blue-600 text-white hover:bg-blue-700"
      } ${loading ? "opacity-70 cursor-not-allowed" : ""}`}
    >
      {loading ? (
        <span className="animate-pulse">...</span>
      ) : isFollowing ? (
        <>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-4 w-4"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M5 13l4 4L19 7"
            />
          </svg>
          Abonné
        </>
      ) : (
        <>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-4 w-4"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M12 4v16m8-8H4"
            />
          </svg>
          S'abonner
        </>
      )}
    </button>
  );
}
