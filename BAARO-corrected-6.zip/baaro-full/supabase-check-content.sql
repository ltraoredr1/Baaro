-- Diagnostic BAARO : vidéos & stories
-- Exécute dans SQL Editor et regarde les résultats

-- 1) Colonnes de la table videos
select column_name, data_type
from information_schema.columns
where table_name = 'videos'
order by ordinal_position;

-- 2) Dernières vidéos (est-ce que tes 3 y sont ?)
select id, author_id, title, video_url, created_at
from videos
order by created_at desc
limit 10;

-- 3) Vidéos SANS url (ne s'affichent pas dans l'app)
select count(*) as videos_sans_url
from videos
where video_url is null or video_url = '';

-- 4) Dernières stories
select id, author_id, media_url, media_type, expires_at, created_at
from stories
order by created_at desc
limit 10;

-- 5) Stories encore valides
select count(*) as stories_actives
from stories
where expires_at > now();
