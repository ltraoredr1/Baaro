-- ============================================================
-- BAARO — Schéma COMPLET et CORRIGÉ (à exécuter en premier)
-- Compatible avec le code React actuel (following_id, status, is_friend)
-- ============================================================

-- 1. Wallets & Crypto
create table if not exists wallets (
  user_id uuid primary key references auth.users(id) on delete cascade,
  balance numeric not null default 1284,
  updated_at timestamptz not null default now()
);

create table if not exists transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  label text not null,
  pts numeric not null,
  created_at timestamptz not null default now()
);

create table if not exists crypto_holdings (
  user_id uuid primary key references auth.users(id) on delete cascade,
  holdings numeric not null default 0,
  updated_at timestamptz not null default now()
);

-- 2. Profiles
create table if not exists profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Nouveau membre',
  handle text,
  flag text default '🌍',
  bio text default '',
  restricted boolean not null default false,
  created_at timestamptz not null default now()
);

-- 3. Posts & Social
create table if not exists posts (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references auth.users(id) on delete cascade,
  text text not null,
  media_url text,
  media_type text,
  mood text,
  created_at timestamptz not null default now()
);

create table if not exists post_likes (
  post_id uuid not null references posts(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (post_id, user_id)
);

create table if not exists comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references posts(id) on delete cascade,
  author_id uuid not null references auth.users(id) on delete cascade,
  text text not null,
  created_at timestamptz not null default now()
);

-- 4. FOLLOWS (CORRIGÉ : following_id + status + is_friend)
create table if not exists follows (
  id uuid primary key default gen_random_uuid(),
  follower_id uuid not null references auth.users(id) on delete cascade,
  following_id uuid not null references auth.users(id) on delete cascade,
  status text not null default 'accepted' check (status in ('pending', 'accepted', 'rejected')),
  is_friend boolean not null default false,
  created_at timestamptz not null default now(),
  unique (follower_id, following_id)
);

-- 5. Messages
create table if not exists messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null,
  sender_id uuid not null references auth.users(id) on delete cascade,
  recipient_id uuid not null references auth.users(id) on delete cascade,
  text text not null,
  created_at timestamptz not null default now()
);

-- 6. Videos
create table if not exists videos (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  description text,
  media_url text,
  duration text,
  views int not null default 0,
  created_at timestamptz not null default now()
);

-- 7. Stories (complet)
create table if not exists stories (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references auth.users(id) on delete cascade,
  media_url text,
  media_type text default 'image',
  text_overlay text,
  filter_used text,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '24 hours')
);

-- 8. Notifications, Blocks, Reports
create table if not exists notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  message text not null,
  type text default 'info',
  read boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists blocks (
  blocker_id uuid not null references auth.users(id) on delete cascade,
  blocked_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id)
);

create table if not exists reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references auth.users(id) on delete cascade,
  target_type text not null,
  target_id text not null,
  reason text,
  created_at timestamptz not null default now()
);

-- 9. Device accounts (anti-abus)
create table if not exists device_accounts (
  device_id text not null,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (device_id, user_id)
);

-- 10. Votes (gouvernance)
create table if not exists votes (
  proposal_id text not null,
  user_id uuid not null references auth.users(id) on delete cascade,
  choice text not null,
  created_at timestamptz not null default now(),
  primary key (proposal_id, user_id)
);

-- ============================================================
-- RLS
-- ============================================================
alter table wallets enable row level security;
alter table transactions enable row level security;
alter table crypto_holdings enable row level security;
alter table profiles enable row level security;
alter table posts enable row level security;
alter table post_likes enable row level security;
alter table comments enable row level security;
alter table follows enable row level security;
alter table messages enable row level security;
alter table videos enable row level security;
alter table stories enable row level security;
alter table notifications enable row level security;
alter table blocks enable row level security;
alter table reports enable row level security;
alter table device_accounts enable row level security;
alter table votes enable row level security;

-- Wallets / Crypto / Transactions : LECTURE SEULE côté client
create policy "wallet_read_own" on wallets for select using (auth.uid() = user_id);
create policy "crypto_read_own" on crypto_holdings for select using (auth.uid() = user_id);
create policy "tx_read_own" on transactions for select using (auth.uid() = user_id);

-- Profiles
create policy "profiles_read" on profiles for select using (true);
create policy "profiles_insert" on profiles for insert with check (auth.uid() = user_id);
create policy "profiles_update" on profiles for update using (auth.uid() = user_id);

-- Posts
create policy "posts_read" on posts for select using (true);
create policy "posts_insert" on posts for insert with check (auth.uid() = author_id);
create policy "posts_update" on posts for update using (auth.uid() = author_id);
create policy "posts_delete" on posts for delete using (auth.uid() = author_id);

-- Likes
create policy "likes_read" on post_likes for select using (true);
create policy "likes_own" on post_likes for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Comments
create policy "comments_read" on comments for select using (true);
create policy "comments_insert" on comments for insert with check (auth.uid() = author_id);
create policy "comments_delete" on comments for delete using (auth.uid() = author_id);

-- Follows
create policy "follows_read" on follows for select using (true);
create policy "follows_own" on follows for all using (auth.uid() = follower_id) with check (auth.uid() = follower_id);

-- Messages
create policy "messages_read" on messages for select using (auth.uid() = sender_id or auth.uid() = recipient_id);
create policy "messages_insert" on messages for insert with check (auth.uid() = sender_id);

-- Videos
create policy "videos_read" on videos for select using (true);
create policy "videos_insert" on videos for insert with check (auth.uid() = author_id);

-- Stories
create policy "stories_read" on stories for select using (true);
create policy "stories_insert" on stories for insert with check (auth.uid() = author_id);
create policy "stories_delete" on stories for delete using (auth.uid() = author_id);

-- Notifications
create policy "notif_own" on notifications for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Blocks
create policy "blocks_own" on blocks for all using (auth.uid() = blocker_id) with check (auth.uid() = blocker_id);

-- Reports
create policy "reports_insert" on reports for insert with check (auth.uid() = reporter_id);
create policy "reports_own_read" on reports for select using (auth.uid() = reporter_id);

-- Votes
create policy "votes_read" on votes for select using (true);
create policy "votes_own" on votes for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- device_accounts : aucune policy → seul service_role y accède
