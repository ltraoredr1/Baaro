-- ============================================================
-- BAARO — Migration CORRECTIVE (pour bases déjà créées)
-- Exécutez ce script SI vous avez déjà appliqué l'ancien schéma
-- ============================================================

-- 1. Corriger la table follows (si elle existe avec followed_id)
DO $$
BEGIN
  -- Renommer la colonne si elle existe encore sous l'ancien nom
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'follows' AND column_name = 'followed_id'
  ) THEN
    ALTER TABLE follows RENAME COLUMN followed_id TO following_id;
  END IF;
END $$;

-- Ajouter les colonnes manquantes
ALTER TABLE follows 
  ADD COLUMN IF NOT EXISTS id uuid DEFAULT gen_random_uuid(),
  ADD COLUMN IF NOT EXISTS status text DEFAULT 'accepted',
  ADD COLUMN IF NOT EXISTS is_friend boolean DEFAULT false;

-- Contrainte de statut (si pas déjà présente)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.check_constraints 
    WHERE constraint_name LIKE '%status%' AND table_name = 'follows'
  ) THEN
    ALTER TABLE follows 
      ADD CONSTRAINT follows_status_check 
      CHECK (status IN ('pending', 'accepted', 'rejected'));
  END IF;
EXCEPTION WHEN others THEN
  NULL; -- ignore si déjà existante
END $$;

-- Rendre id PRIMARY KEY si possible (seulement si pas déjà de PK sur id)
DO $$
BEGIN
  -- Supprimer l'ancienne PK composite si elle existe
  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE table_name = 'follows' AND constraint_type = 'PRIMARY KEY'
  ) THEN
    ALTER TABLE follows DROP CONSTRAINT follows_pkey;
  END IF;
  
  -- Ajouter unique sur le couple
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE table_name = 'follows' AND constraint_name = 'follows_follower_following_unique'
  ) THEN
    ALTER TABLE follows ADD CONSTRAINT follows_follower_following_unique UNIQUE (follower_id, following_id);
  END IF;

  -- Mettre id en PK
  ALTER TABLE follows ALTER COLUMN id SET NOT NULL;
  ALTER TABLE follows ADD PRIMARY KEY (id);
EXCEPTION WHEN others THEN
  RAISE NOTICE 'PK follows déjà correcte ou conflit: %', SQLERRM;
END $$;

-- 2. Enrichir la table stories
ALTER TABLE stories 
  ADD COLUMN IF NOT EXISTS media_url text,
  ADD COLUMN IF NOT EXISTS media_type text DEFAULT 'image',
  ADD COLUMN IF NOT EXISTS text_overlay text,
  ADD COLUMN IF NOT EXISTS filter_used text;

-- 3. Enrichir profiles si besoin
ALTER TABLE profiles 
  ADD COLUMN IF NOT EXISTS bio text DEFAULT '',
  ADD COLUMN IF NOT EXISTS restricted boolean NOT NULL DEFAULT false;

-- 4. Enrichir posts
ALTER TABLE posts 
  ADD COLUMN IF NOT EXISTS media_url text,
  ADD COLUMN IF NOT EXISTS media_type text,
  ADD COLUMN IF NOT EXISTS mood text;

-- 5. Recréer les policies follows (propre)
DROP POLICY IF EXISTS "follows_own" ON follows;
DROP POLICY IF EXISTS "follows_read" ON follows;

CREATE POLICY "follows_read" ON follows FOR SELECT USING (true);
CREATE POLICY "follows_own" ON follows FOR ALL 
  USING (auth.uid() = follower_id) 
  WITH CHECK (auth.uid() = follower_id);

-- 6. Sécurité wallet (si pas déjà fait)
DROP POLICY IF EXISTS "wallet_own" ON wallets;
DROP POLICY IF EXISTS "crypto_own" ON crypto_holdings;
DROP POLICY IF EXISTS "tx_own" ON transactions;

DROP POLICY IF EXISTS "wallet_read_own" ON wallets;
DROP POLICY IF EXISTS "crypto_read_own" ON crypto_holdings;
DROP POLICY IF EXISTS "tx_read_own" ON transactions;

CREATE POLICY "wallet_read_own" ON wallets FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "crypto_read_own" ON crypto_holdings FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "tx_read_own" ON transactions FOR SELECT USING (auth.uid() = user_id);

-- 7. device_accounts
CREATE TABLE IF NOT EXISTS device_accounts (
  device_id text NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (device_id, user_id)
);
ALTER TABLE device_accounts ENABLE ROW LEVEL SECURITY;
