# Instructions SQL BAARO (corrigé)

## Option A — Nouvelle base (recommandé)

1. Créez un nouveau projet Supabase
2. Activez **Anonymous** dans Authentication > Providers
3. Dans SQL Editor, exécutez **dans l'ordre** :
   - `00-schema-complete.sql`  ← schéma complet déjà corrigé (following_id, etc.)

## Option B — Base déjà existante (vous avez déjà le vieux schéma)

1. Exécutez **uniquement** :
   - `01-fix-follows-and-stories.sql`

Ce script :
- Renomme `followed_id` → `following_id`
- Ajoute `id`, `status`, `is_friend`
- Enrichit `stories` et `profiles`
- Met les policies wallet en lecture seule

## Vérification rapide

Après migration, lancez dans SQL Editor :

```sql
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'follows' 
ORDER BY ordinal_position;
```

Vous devez voir : `id`, `follower_id`, `following_id`, `status`, `is_friend`, `created_at`.
