# BAARO — Correctifs appliqués (06 août 2026)

## Problèmes corrigés

### 1. Crash AppProvider / useApp
- `main.jsx` wrappe maintenant correctement avec `<AppProvider>` + `<ToastProvider>`
- `App.jsx` utilise `useApp()` au lieu de gérer un state local dupliqué
- `WalletTab` et `CryptoTab` fonctionnent sans erreur

### 2. Schéma follows cassé
Ancien schéma : `followed_id`
Code React : `following_id` + `status` + `is_friend`

→ Fichier `sql/00-schema-complete.sql` (nouvelle base)
→ Fichier `sql/01-fix-follows-and-stories.sql` (base existante)

### 3. Écritures wallet interdites côté client
Suppression de l'upsert direct dans `AppContext.jsx` (RLS lecture seule).

### 4. Stories incomplet
Ajout des colonnes `media_url`, `media_type`, `text_overlay`, `filter_used`.

## Comment appliquer

### Base de données
Voir `sql/README-SQL.md`

### Code
Remplacez simplement les fichiers suivants dans votre projet :
- `src/main.jsx`
- `src/App.jsx`
- `src/contexts/AppContext.jsx` (écriture wallet retirée)

Puis :
```bash
npm install
npm run dev
```

## Variables d'environnement nécessaires (.env.local)

```
VITE_SUPABASE_URL=https://xxxx.supabase.co
VITE_SUPABASE_ANON_KEY=eyJ...
SUPABASE_SERVICE_ROLE_KEY=eyJ...   # côté serveur uniquement
ANTHROPIC_API_KEY=sk-ant-...       # ou N8N_BAARO_WEBHOOK_URL
VITE_API_BASE_URL=                 # vide en local / Vercel, URL complète en Capacitor
VITE_TURNSTILE_SITE_KEY=...        # optionnel
DAILY_API_KEY=...                  # pour les lives
DAILY_DOMAIN=baaro
```

## Structure du zip

```
Baaro-fixed/
├── src/                  ← code React corrigé
├── api/                  ← fonctions serverless
├── sql/                  ← migrations SQL propres
│   ├── 00-schema-complete.sql
│   ├── 01-fix-follows-and-stories.sql
│   └── README-SQL.md
├── public/
├── package.json
├── vite.config.js
└── README-FIXES.md
```
