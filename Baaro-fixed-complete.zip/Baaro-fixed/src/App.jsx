import { useState } from "react";
import { useApp } from "./contexts/AppContext.jsx";
import { Header } from "./components/Header.jsx";
import { Navigation } from "./components/Navigation.jsx";
import { FeedTab } from "./components/FeedTab.jsx";
import { VideosTab } from "./components/VideosTab.jsx";
import { MessagesTab } from "./components/MessagesTab.jsx";
import { WalletTab } from "./components/WalletTab.jsx";
import { CryptoTab } from "./components/CryptoTab.jsx";
import DebatesTab from "./components/DebatesTab.jsx";
import { OfflineTab } from "./components/OfflineTab.jsx";
import { AiAssistantTab } from "./components/AiAssistantTab.jsx";
import { SettingsTab } from "./components/SettingsTab.jsx";
import { ProfileModal } from "./components/ProfileModal.jsx";
import { NotificationDrawer } from "./components/NotificationDrawer.jsx";
import { GlobalSearchModal } from "./components/GlobalSearchModal.jsx";
import { FriendsTab } from "./components/FriendsTab.jsx";
import { COLORS } from "./theme.js";
import AuthScreen from "./components/AuthScreen.jsx";

const THEME_BG_MAP = {
  midnight: "#0B1220",
  oled: "#000000",
  emerald: "#061A14",
};

function MainAppContent() {
  const {
    session,
    userId,
    userProfile,
    setUserProfile,
    pointsBalance,
    baroBalance,
    setPointsBalance,
    setBaroBalance,
    loading,
    earnPoints,
  } = useApp();

  const [activeTab, setActiveTab] = useState("feed");
  const [lang, setLang] = useState("fr");
  const [inspectingProfileId, setInspectingProfileId] = useState(null);
  const [notifDrawerOpen, setNotifDrawerOpen] = useState(false);
  const [searchModalOpen, setSearchModalOpen] = useState(false);
  const [currentTheme, setCurrentTheme] = useState("midnight");

  // Callback compatible avec les tabs qui appellent encore onRewardPoints(pts)
  const handleRewardPoints = async (ptsOrBalance) => {
    if (typeof ptsOrBalance !== "number") return;
    // Si c'est un gros nombre (> 50) on considère que c'est le nouveau solde
    if (ptsOrBalance > 50) {
      setPointsBalance(ptsOrBalance);
      return;
    }
    // Sinon on tente un earn générique (les tabs modernes utilisent déjà earnPoints)
    // On met juste à jour localement en attendant
    setPointsBalance((prev) => prev + ptsOrBalance);
  };

  const themeBg = THEME_BG_MAP[currentTheme] || THEME_BG_MAP.midnight;

  if (loading) {
    return (
      <div
        className="min-h-screen flex items-center justify-center"
        style={{ background: themeBg, color: "white" }}
      >
        <div className="text-center">
          <div className="text-4xl mb-4 animate-pulse">⏳</div>
          <p>Chargement de votre espace BAARO...</p>
        </div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen flex flex-col transition-colors duration-500"
      style={{ background: themeBg, color: COLORS.ivory }}
    >
      <Header
        lang={lang}
        setLang={setLang}
        pointsBalance={pointsBalance}
        baroBalance={baroBalance}
        userProfile={userProfile}
        onOpenProfile={() => setInspectingProfileId(userId)}
        onOpenNotifications={() => setNotifDrawerOpen(true)}
        onOpenSearch={() => setSearchModalOpen(true)}
      />

      <div className="max-w-7xl mx-auto w-full px-3 sm:px-6 pt-4 sm:pt-6 flex-1 grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="md:col-span-1">
          <Navigation activeTab={activeTab} setActiveTab={setActiveTab} />
        </div>

        <main className="md:col-span-3">
          {activeTab === "feed" && (
            <FeedTab
              userId={userId}
              onOpenProfile={(authorId) => setInspectingProfileId(authorId)}
              onRewardPoints={handleRewardPoints}
            />
          )}

          {activeTab === "friends" && <FriendsTab currentUserId={userId} />}

          {activeTab === "videos" && (
            <VideosTab userId={userId} onRewardPoints={handleRewardPoints} />
          )}

          {activeTab === "messages" && (
            <MessagesTab userId={userId} onRewardPoints={handleRewardPoints} />
          )}

          {activeTab === "wallet" && (
            <WalletTab onNavigateToCrypto={() => setActiveTab("crypto")} />
          )}

          {activeTab === "crypto" && <CryptoTab />}

          {activeTab === "debates" && (
            <DebatesTab
              currentUserId={userId}
              onRewardPoints={handleRewardPoints}
            />
          )}

          {activeTab === "offline" && (
            <OfflineTab onRewardPoints={handleRewardPoints} />
          )}

          {activeTab === "assistant" && (
            <AiAssistantTab
              userId={userId}
              userProfile={userProfile}
              pointsBalance={pointsBalance}
              baroBalance={baroBalance}
              onRewardPoints={handleRewardPoints}
            />
          )}

          {activeTab === "settings" && (
            <SettingsTab
              userId={userId}
              userProfile={userProfile}
              setUserProfile={setUserProfile}
              currentTheme={currentTheme}
              onSelectTheme={setCurrentTheme}
            />
          )}
        </main>
      </div>

      {inspectingProfileId && (
        <ProfileModal
          authorId={inspectingProfileId}
          currentUserId={userId}
          onClose={() => setInspectingProfileId(null)}
          onNavigateToMessages={() => setActiveTab("messages")}
        />
      )}

      <NotificationDrawer
        isOpen={notifDrawerOpen}
        onClose={() => setNotifDrawerOpen(false)}
        userId={userId}
      />

      <GlobalSearchModal
        isOpen={searchModalOpen}
        onClose={() => setSearchModalOpen(false)}
        onSelectUser={(id) => setInspectingProfileId(id)}
        onSelectTab={(tabId) => setActiveTab(tabId)}
      />
    </div>
  );
}

export default function App() {
  const { session, loading } = useApp();

  if (loading) {
    return (
      <div
        className="min-h-screen flex items-center justify-center"
        style={{ background: "#0B1220", color: "white" }}
      >
        <div className="text-center">
          <div className="text-4xl mb-4">⏳</div>
          <p>Chargement de BAARO...</p>
        </div>
      </div>
    );
  }

  if (!session) {
    return <AuthScreen />;
  }

  return <MainAppContent />;
}
